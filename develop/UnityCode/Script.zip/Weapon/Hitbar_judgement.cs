using UnityEngine;

public class Hitbar_judgement : MonoBehaviour
{
    Transform hitbox;
    Transform hitarea;

    [SerializeField]
    Transform[] hitbox_vertexAry = new Transform[4];

    [SerializeField]
    Transform[] hitarea_vertexAry = new Transform[4];

    float judgement_area;

    float excellent = 90.00f;
    float great = 70.00f;
    float good = 40.00f;
    float bad = 10.00f;
    int cnt;

    // Start is called before the first frame update
    void Start()
    {
        
        hitbox = transform.Find("Hitbox");
        hitarea = transform.Find("Hitarea");

        

        if(hitbox == null || hitarea == null)
        {
            Debug.LogError("Can't find named objects");
        }
        else
        {
            Debug.Log(hitbox.name);
            Debug.Log(hitarea.name);
        }

        judgement_area = Mathf.Abs(hitarea_vertexAry[0].position.x - hitarea_vertexAry[1].position.x) *
            Mathf.Abs(hitarea_vertexAry[0].position.y - hitarea_vertexAry[2].position.y);
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            AreaJudgement();
        }
    }

    void AreaJudgement()
    {
        float overlaparea;
        float veritcal = Mathf.Abs(hitarea_vertexAry[0].position.y - hitarea_vertexAry[2].position.y);
        
        if(hitbox_vertexAry[0].position.x >= hitarea_vertexAry[0].position.x)
        {
            overlaparea = (hitarea_vertexAry[1].position.x - hitbox_vertexAry[0].position.x)
                * veritcal;
        }
        else
        {
            overlaparea = (hitbox_vertexAry[1].position.x - hitarea_vertexAry[0].position.x)
                * veritcal;
        }

        float accuracy = (overlaparea / judgement_area) * 100.00f;
        

        if(accuracy >= excellent)
        {
            Debug.Log("Excellent!!");
        }
        else if(accuracy < excellent && accuracy >= great)
        {
            Debug.Log("Great!");
        }
        else if (accuracy < great && accuracy >= good)
        {
            Debug.Log("Good");
        }
        else if (accuracy < good && accuracy >= bad)
        {
            Debug.Log("Bad");
        }
        else if(accuracy < bad)
        {
            Debug.Log("Miss");
        }
        else
        {
            Debug.Log("??");
        }
        cnt++;
        Debug.Log("cnt:" + cnt);


    }
}
