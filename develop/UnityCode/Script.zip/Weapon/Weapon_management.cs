using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon_management : MonoBehaviour
{
    float length_of_hitbox;
    float max_damage;
    float min_damage;
    float speed_hitbar;

    Transform hitbar_type;
    Transform location_weapon;
    Transform location_hitbar;

   

}
