using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sword_manager : MonoBehaviour
{
    [SerializeField]
    GameObject sword_slasheffect;

    public Vector3 effectlocation;
    public float destroydelay;

    Vector3 playerpos;

    [SerializeField]
    Transform hitbar;

    public Transform excellent;
    public Transform great;
    public Transform nice;
    public Transform bad;

    [SerializeField]
    WeaponUse wu;
    /* This value should larger than Total Animation Play time(waitforattack + repeat_num * sword_playinterval
     * denominator * sword_playinterval within Player_ScriptAnime.cs)
    */
    public float sword_waittime = 2.0f;
    bool key = true;

    // Start is called before the first frame update
    void Start()
    {
        if(excellent == null && great == null && nice == null && bad == null)
        {
            Debug.LogError("reference missing");
        }

        if (sword_slasheffect == null)
        {
            Debug.Log("reference missing");
        }

        UpdateReference();
        

       
        


    }

    // Update is called once per frame
    void Update()
    {
        UpdateReference();

        if (Input.GetMouseButtonDown(0))
        {
            StartCoroutine("Judgement");
            
        }
    }

    IEnumerator Judgement()
    {
        
        if (key)
        {
            Debug.Log("HI!");
            key = false;
            float xpos = Mathf.Abs(hitbar.localPosition.x);
            float _excellent = excellent.localPosition.x;
            float _great = great.localPosition.x;
            float _nice = nice.localPosition.x;
            float _bad = bad.localPosition.x;
            

            if (xpos < _excellent)  //Excellent
            {
                Debug.Log("120");
                wu.SwordSlash(120f);
               
                

            }
            if (_excellent < xpos && xpos < _great)  //Great
            {
                Debug.Log("90");
                wu.SwordSlash(90f);
            }
            if (_great < xpos && xpos < _nice)   //Nice
            {
                Debug.Log("50");
                wu.SwordSlash(50f);
            }
            if (_nice < xpos && xpos < _bad)     //Bad
            {
                Debug.Log("20 1");
                wu.SwordSlash(20f);
            }
            if (_bad < xpos)  //Miss
            {
                Debug.Log("bad position" + bad.position.x);
                Debug.Log("xpos" + Mathf.Abs(xpos));
                wu.SwordSlash(20f);
            }
            Invoke("SpawnSlashEffect", wu.waitforattack);
            yield return new WaitForSeconds(sword_waittime);

            key = true;
        }
        


    }

    void UpdateReference()
    {
        if (wu == null)
        {
            Debug.Log("Target missing");
            GameObject go = GameObject.FindGameObjectWithTag("Player");
            wu = go.GetComponent<WeaponUse>();
        }

            GameObject player = GameObject.FindGameObjectWithTag("Player");
            playerpos = player.transform.position;
    }

    void SpawnSlashEffect()
    {
        GameObject swdeff;
        if (GameMaster.gm.IsFlipPlayer())
        {
            swdeff = Instantiate(sword_slasheffect,  playerpos - effectlocation, Quaternion.Euler(0f,0f,0f));
            Vector3 scale = swdeff.transform.localScale;
            swdeff.transform.localScale = new Vector3(-scale.x, scale.y, scale.z);
        }
        else
        {
            swdeff = Instantiate(sword_slasheffect, playerpos + effectlocation, Quaternion.Euler(0f, 0f, 0f));
            
        }
        Destroy(swdeff, destroydelay);
    }
}
