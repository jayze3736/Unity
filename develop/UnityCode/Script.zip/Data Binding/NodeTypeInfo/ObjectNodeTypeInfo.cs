using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectNodeTypeInfo : NodeTypeInfo
{
    #region Field
    readonly Type type;
    
    #endregion

    

    #region Properties
    

    public override bool CanValueChange => throw new NotImplementedException();
    #endregion

    #region Constructor
    public ObjectNodeTypeInfo(object obj)
    {
        type = obj.GetType();
        
    }


    #endregion



    public override void GetValue()
    {
        throw new NotImplementedException();
    }

    public override void SetValue()
    {
        throw new NotImplementedException();
    }
}
