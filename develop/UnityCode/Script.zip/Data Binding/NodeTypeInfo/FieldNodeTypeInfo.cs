﻿using System;
using System.Collections;
using UnityEngine;


public class FieldNodeTypeInfo : NodeTypeInfo
{
    
    
    

    public override bool CanValueChange => throw new NotImplementedException();

    public override void GetValue()
    {
        throw new NotImplementedException();
        
    }

    public override void SetValue()
    {
        throw new NotImplementedException();
    }
}
