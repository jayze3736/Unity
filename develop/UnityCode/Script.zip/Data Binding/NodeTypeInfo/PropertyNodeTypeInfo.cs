﻿using System;
using System.Collections;
using UnityEngine;


public class PropertyNodeTypeInfo : NodeTypeInfo
{
    

    public override bool CanValueChange => throw new NotImplementedException();

    public override void GetValue()
    {
        throw new NotImplementedException();
    }

    public override void SetValue()
    {
        throw new NotImplementedException();
    }
}
