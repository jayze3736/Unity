using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace jsh {
    public abstract class DataNode : IDataNode
    {

        #region Field

        readonly string name;
        readonly object value;
        object parentnode;
        readonly NodeTypeInfo typeinfo;

        public string Name
        {
            get { return name; }
        }

        public object Value { get { return value; } }

        public Type DataType { get { return typeinfo.Type; } }


        //public Type DataType => nodeTypeInfo;
        #endregion

        #region Constructor
        public DataNode(string name, object parentnode, NodeTypeInfo typeInfo)
        {
            this.name = name;
            this.parentnode = parentnode;

        }

        public DataNode()
        {

        }

        #endregion
        //public delegate void ValueChangedDelegate();
        //public event ValueChangedDelegate OnValueChanged;
        #region EventHandler
        public event Action<object> ValueChanged;
        #endregion

        public void Destroy()
        {
            throw new NotImplementedException();
        }

        public abstract IDataNode FindDescendant(string path);


        public bool RemoveDescendant(string path)
        {
            throw new NotImplementedException();
        }

        public void SetValue(object newValue)
        {

        }
    }
}
