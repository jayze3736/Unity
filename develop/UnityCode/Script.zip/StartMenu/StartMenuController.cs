using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StartMenuController : MonoBehaviour
{
    [SerializeField]
    Button newbutton;
    [SerializeField]
    Button loadbutton;
    [SerializeField]
    Button quitbutton;


    [SerializeField]
    Transform menu_saveload;

    // Start is called before the first frame update
    void Start()
    {
        Nullcheck();
        AddListener();



    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Nullcheck()
    {
        if (newbutton == null)
        {
            newbutton = transform.Find("NewButton").GetComponent<Button>();
        }
        if (loadbutton == null)
        {
            loadbutton = transform.Find("LoadButton").GetComponent<Button>();
        }
        if (quitbutton == null)
        {
            quitbutton = transform.Find("QuitButton").GetComponent<Button>();
        }
        if(menu_saveload == null)
        {
            menu_saveload = GameObject.Find("menu_saveload").transform;
            menu_saveload.gameObject.SetActive(false);
        }
    }

    void AddListener()
    {
        newbutton.onClick.AddListener(StartNewGame);
        loadbutton.onClick.AddListener(Load);
        quitbutton.onClick.AddListener(Quit);

    }

    void Load()
    {
        menu_saveload.gameObject.SetActive(true);
        // Load Scene   - by clicking save file in load mode
        // Load savedata
        // Update spawn point(subscribe event)
        // Spawn Player **(needs updating spawn point!!! before spawn player)
        // match savedata into player info
    }

    void StartNewGame()
    {
        //SceneEventManager.eventmanager.LoadNextScene(true);
        SceneUtils.instance.StartNewGame();
        

        //load new scene
    }

    

    void Quit()
    {
        Debug.Log("Quit!");
        Application.Quit();
        
    }


}
