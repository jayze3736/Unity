using UnityEngine;
using LanguageExt;

public class WeaponManager : MonoBehaviour
{

    public static WeaponManager wm;

    [System.Serializable]
    public class WeaponComponent
    {
        public GameObject _weapon;
        public GameObject _hitbar;

    }
    
    public WeaponComponent[] wc;
   

    public static Option<WeaponComponent> GetweaponSet(string _weaponName)
    {
        var result = Option<WeaponComponent>.None;
        for(int i = 0; i< wm.wc.Length; i++)
        {    
            if(wm.wc[i]._weapon.name == _weaponName)
            {
                result = wm.wc[i];
                return result;
            }
            
        }
        return result;


    }


    // Start is called before the first frame update
    void Start()
    {
       
    }

    private void Awake()
    {
        wm = GetComponent<WeaponManager>();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
