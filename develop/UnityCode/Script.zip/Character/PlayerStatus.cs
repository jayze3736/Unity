using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// �÷��̾��� ����, ���¸� ��Ÿ���� ���� ������ Ŭ����(Logic)
/// </summary>
[System.Serializable]
public class PlayerStatus : SaveDataElement
{

    #region Serialized Field
    [SerializeField] int maxhp = 5;
    [SerializeField] float max_stamina = 100.0f;
    [SerializeField] float hp;

    [SerializeField] string nickname;
    [SerializeField] int LV;
    #endregion

    #region Non-Serialized Field
    
    private bool isinvincible = false;
    float stamina;

    float atk;
    float def;
    float sp;

    /// <summary>
    /// �ʴ� ���¹̳� ȸ����(Vitality)
    /// </summary>
    float vit_stm_per_sec;

    [System.NonSerialized]
    public GameObject curweapon;

    /// <summary>
    /// hp�� �ּ� ������, �� ������ �������� ������ �ش� �������� ����� �������� ���� ����� ������ �������� ȯ��ȴ�. 
    /// </summary>
    /// ���� ������� hp element�� full(1), half(0.5), empty(0) ������ ���¸� ����ϱ⶧���� unit_hp�� 0.5�����Ѵ�.
    [System.NonSerialized]
    float unit_hp = 0.5f;


    #endregion


    #region EventHandler
    
    public Action<float> PlayerDamaged;
    public Action<float> PlayerHealed;
    public Action<float> StaminaChanged;
    public Action NotEnoughStaminaUsed;
    public Action<int> MaxHPIncreased;
    public Action<int> MaxHPDecreased;

    #endregion






    #region Constructor
    public PlayerStatus()
    {
        
        this.LV = 0;
        this.ATK = 0;
        this.DEF = 0;
        this.SP = 0;
        this.nickname = "";
        Init();
        AddSLEventListener();
    }

    public PlayerStatus(string nickname)
    {
        this.LV = 0;
        this.ATK = 0;
        this.DEF = 0;
        this.SP = 0;
        this.nickname = nickname;
        Init();
        AddSLEventListener();

    }

    //���̺� �����Ϳ��� �о���� 
    public PlayerStatus(int max_hp, float max_stamina, string nickname, int lv, float ATK, float DEF, float SP)
    {

        this.MaxHP = max_hp;
        this.MaxStamina = max_stamina;
        this.nickname = nickname;
        this.LV = lv;
        this.ATK = ATK;
        this.DEF = DEF;
        this.SP = SP;
        Init();
        AddSLEventListener();

    }

    //�ܺο��� ������ �Ǵ� �ҷ��� PlayerStatus�� �ʱ�ȭ �Ұ��(Ư��, save���Ͽ��� PlayerStatus�� �����ͼ� �����͸� �����ϴ� ���)
    public PlayerStatus (PlayerStatus status)
    {
        hp = status.hp;
        LV = status.LV;
        stamina = status.stamina;
        nickname = status.nickname;
        ATK = status.ATK;
        DEF = status.DEF;
        SP = status.SP;
        VIT_STM_per_sec = status.VIT_STM_per_sec;
        AddSLEventListener();


    }


    #endregion

    #region Property
    public float HP
    {
        get { return hp; }
        set
        { 
          
            float change = value - this.hp;
            this.hp = Mathf.Clamp(value, 0, MaxHP);
            if (change > 0)
            {
                //HealPlayer
                OnPlayerHealed(change);
            }

            if(change < 0)
            {
                float damage = Mathf.Abs(change);
                OnPlayerDamaged(damage);
                //DamagePlayer
            }
            
        
        }
    }

    public int MaxHP
    {
        get { return maxhp; }
        set
        {
            
            if(value < 1)
            {
                Debug.LogError("Max HP should have value more than 1");
                return;
            }

            //����
            if(value > maxhp)
            {

                
                int change = value - maxhp;

                //maxhp ���� ���� ����
                maxhp = value;

                //������ ����ŭ hp�� ���� ����
                
                OnMaxHPIncreased(change);

                hp += change;
                
                
            }
            //����
            if(value < maxhp)
            {
                int change = maxhp - value;

                //maxhp�� �ٲ�
                maxhp = value;
                
                

                //value(�ٲ�� Max hp) ���� hp���� �������, new max hp = 3, hp = 3.5, cur max hp = 5
                if (value < hp)
                {
                    //1.�ݿø��� �Ѵ�.
                    hp = value;
                    //HP = Mathf.Round(HP); // ���� ���� 5�̳�, hp�� clamp�� ���� 4���Ǹ� ���⼭ call�� ��������


                    //2. maxhp - value��ŭ ����.
                    //hp -= change;
                    //LifeDecrease(change); // hp = 3 ���⼭ call
                    //hp -= change;
                    
                    

                }

                OnMaxHPDecreased(change);

                //MAX HP �� �ٿ��ߵ�
                //OnMaxHPChanged(change);


            }

        }
    }

    public float MaxStamina
    {
        get { return max_stamina; }
        set
        {
            if(value < 100)
            {
                Debug.Log("Max Stamina should have value more than 100");
                return;
            }
            else
            {
                max_stamina = value;
            }

        }
        
       
    }

    public string Nickname
    {
        get { return nickname; }
        
    }

    public float Stamina
    {
        get { return stamina; }
        set
        { 
            float stamina = Mathf.Clamp(value, 0, MaxStamina);
            if (!Equals(stamina, this.stamina))
            {
                this.stamina = stamina;
                OnStaminaChanged(this.stamina); 
            }
        }
    }
    
    public float VIT_STM_per_sec
    {
        get { return vit_stm_per_sec; }
        set { vit_stm_per_sec = value; }
    }


    float ATK
    {
        get { return atk; }
        set
        {
            atk = value;
            if (atk < 0)
            {
                atk = 0;
            }
        }

    }
    float DEF
    {
        get { return def; }
        set
        {
            def = value;
            if (def < 0)
            {
                def = 0;
            }
        }

    }
    float SP
    {
        get { return sp; }
        set
        {
            sp = value;
            if (sp < 0)
            {
                sp = 0;
            }
        }
    }

    #endregion


    #region Methods


    void OnMaxHPIncreased(int up)
    {
        var handler = MaxHPIncreased;
        if (handler != null)
        {
            handler(up);
        }
    }

    void OnMaxHPDecreased(int down)
    {
        var handler = MaxHPDecreased;
        if (handler != null)
        {
            handler(down);
        }
    }


    void OnPlayerDamaged(float damage)
    {
        var handler = PlayerDamaged;
        if (handler != null)
        {
            handler(damage);
        }


    }


    void OnPlayerHealed(float heal)
    {
        var handler = PlayerHealed;
        if (handler != null)
        {
            handler(heal);
        }


    }


    void OnStaminaChanged(float stamina)
    {
        var handler = StaminaChanged;
        if (handler != null)
        {
            handler(stamina);
        }


    }


    void OnNotEnoughStaminaUsed()
    {
        var handler = NotEnoughStaminaUsed;
        if(handler != null){
            handler();
        }
    }

    public void Init()
    {
        hp = MaxHP;
        stamina = MaxStamina;
    }


    public void InheritStatusData(PlayerStatus status)
    {
        //hp = status.hp;
        LV = status.LV;
        //stamina = status.stamina;
        MaxStamina = status.MaxStamina;
        MaxHP = status.MaxHP;
        nickname = status.Nickname;
        ATK = status.ATK;
        DEF = status.DEF;
        SP = status.SP;
        Init();

    }
    public bool IsDead()
    {
        return (HP <= 0);
    }

    public void Kill()
    {
        HP = -1;
    }

    public void DamageHP()
    {
        HP--;
    }

    public void HealHP()
    {
        HP++;
    }

    public void DamageHP(float damage)
    {
        
        int div = (int)(damage / unit_hp);
        float trueDamage = div * unit_hp;
        HP -= trueDamage;
    }

    public void HealHP(float heal)
    {
        int div = (int)(heal / unit_hp);
        float trueHeal = div * unit_hp;
        HP += trueHeal;
        
    }

    public void LVup()
    {
        LV++;
    }

    public void LVdown()
    {
        LV--;
    }

    public void MaxHPup()
    {
        MaxHP++;
    }

    public void MaxHPdown()
    {
        MaxHP--;
    }


    public void ATKup(float increase)
    {
        ATK += increase;
    }

    public void ATKdown(float decrease)
    {
        ATK -= decrease;
    }

    public void DEFup(float increase)
    {
        DEF += increase;
    }

    public void DEFdown(float decrease)
    {
        DEF -= decrease;
    }

    public void SPup(float increase)
    {
        SP += increase;
    }

    public void SPdown(float decrease)
    {
        SP -= decrease;
    }

    public void ChangeName(string name)
    {
        nickname = name;
    }

    public void MaxHPup(int gain)
    {
       
        MaxHP += gain;
        
    }

    public void MaxHPdown(int loss)
    {
        MaxHP -= loss;
       
    }

    public bool UseStamina(float value)
    {
        if(value > MaxStamina)
        {
            Stamina -= MaxStamina;
        }
        else if(Stamina < value)
        {
            OnNotEnoughStaminaUsed();
            Debug.Log("Can't use Stamina");
            return false;
        }
        else
        {
            Debug.Log("Can Use Stamina: PlayerStatus");
            Stamina -= value;
            
        }

        return true;
       
    }

    public void RecoverStamina()
    {
        
        Stamina += Time.deltaTime * VIT_STM_per_sec;
        //���׹̳� ȸ�� ����
    }

    public PlayerStatus SetMaxLives(int lives)
    {
        maxhp = lives;
        return this;
    }

    public PlayerStatus SetMaxStamina(float stamina)
    {
        MaxStamina = stamina;
        return this;
    }

    public override void MappingSaveDataElement()
    {
        PlayerStatus status = SaveManager.GetSaveData().status;
        this.MaxHP = status.MaxHP;
        this.MaxStamina = status.MaxStamina;
        this.hp = status.hp;
        this.nickname = status.nickname;
        this.LV = status.LV;



}

    public override void RegisterSaveDataElement()
    {
        SaveManager.GetSaveData().status = this;
    }




    #endregion


}

