﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;


/* -Character Animator flow 
 * 
 * Walk -> Idle: V < 0.01
 * Walk -> Roll: R(t), G(t), V>0.01 
 * 
 * Idle -> Walk: V > 0.01
 * Idle -> Roll: R(t), V < 0.01
 * 
 * Roll -> Walk: V > 0.01, R(f), G(t)
 * Roll -> Idle: R(f)
 * 
 * Any -> Jump: J(t), G(f)
 * 
 * Jump -> Idle: J(f), G(t)
 * 
 * ** Velocity: V(float), Roll: R(bool), Jump: J(bool), GroundCheck: G(bool)
 */



public class Move_Character : MonoBehaviour
{
    [SerializeField]
    Animator anim;

    [SerializeField]
    LayerMask layer;

    [SerializeField]
    ForceMode2D fm2d;

    [SerializeField]
    Rigidbody2D rb2d;

    [SerializeField]
    CircleCollider2D circ2D;

   



    public float size_JForce = 8f;
    public float velocity = 10f;
    public float roll_duration = 0.51f;
    private float isfacing;
    public float jump_duration = 0.1f;
    private Vector3 v;
    
    

    private bool groundcheck;
    

    private void Awake()
    {
        //Animator
        
        //RigidBody Component
        
        v = rb2d.velocity;

        //Horizontal(Move), Vertical(Jump), Space(Roll) mapping key
       
        
         
       

    }

    // Start is called before the first frame update
    void Start()
    {
        if(anim == null)
        {
            Debug.LogError("No animator attached");
        }

        if(circ2D == null)
        {
            Debug.LogError("There is no circleCollider2D in" + transform.name);
        }

        
        StartCoroutine("Jump");
        


    }

    // Update is called once per frame
    void Update()
    {
        //Walk <- , ->
        
        //Jump

        //Idle
        
        //Roll
        

    }

    private void FixedUpdate()
    {
        
        Walk();
    }

   

    IEnumerator Jump()
    {
        bool GChk = GroundCheck();
        //float isjump = CrossPlatformInputManager.GetAxisRaw("Vertical"); // s, w(-1, 0 ,1)
        if (GChk)
        {   
            switch (CrossPlatformInputManager.GetAxisRaw("Vertical"))
            {
                case -1f:
                    anim.SetBool("Jump", false);
                    break;

                case 0f:
                    anim.SetBool("Jump", false);
                    break;

                case 1f:
                    anim.SetBool("Jump", true);
                    rb2d.AddForce(transform.up * size_JForce, fm2d);
                    yield return new WaitForSeconds(jump_duration);
                    break;



              }


        }
        yield return new WaitForSeconds(0.00001f);
        StartCoroutine("Jump");

    }

    

 

    IEnumerator Roll()
    {
        bool isroll = CrossPlatformInputManager.GetButtonDown("Jump"); //space
        if (isroll)
        {
            anim.SetBool("Roll", true);
            yield return new WaitForSeconds(roll_duration);
        }
        else
        {
            anim.SetBool("Roll", false);
            yield return new WaitForSeconds(0.00001f);
        }

        StartCoroutine("Roll");

    }
    
    void IsFlip(float _input)
    {
       
        if (_input * transform.localScale.x < 0)
        {
            transform.localScale = new Vector3(-transform.localScale.x
          , transform.localScale.y
          , transform.localScale.z);

        }
       
       
    }

    void Walk()
    {

        
        float move_input = CrossPlatformInputManager.GetAxis("Horizontal");
        IsFlip(move_input);
        v.x = Mathf.Abs( velocity * move_input) ;
        anim.SetFloat("Velocity", v.x);
        //transform.position += velocity * move_input * Vector3.right * Time.fixedDeltaTime;
        rb2d.velocity = new Vector2(move_input * velocity, rb2d.velocity.y);

    }

    bool GroundCheck()
    {
        
        //월드 좌표계의 원 중심 좌표
        Vector2 cir_center = circ2D.offset + (Vector2)transform.position;
        float radius = circ2D.radius;
        Collider2D colliderChk = Physics2D.OverlapCircle(cir_center, radius, layer);
        
        
        if(colliderChk != null)
        {
            groundcheck = true;
        }
        else
        {
            groundcheck = false;
        }
        anim.SetBool("GroundCheck", groundcheck);
        
        return groundcheck;

    }
   

}
