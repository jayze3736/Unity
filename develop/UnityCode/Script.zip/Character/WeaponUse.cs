using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponUse : MonoBehaviour
{
    [SerializeField]
    Player_ScriptAnime psa;

    public Vector3 boxpos;
    public Vector2 size;
    public LayerMask lm;
    public float waitforattack;
    Player player;

    // Start is called before the first frame update
    void Awake()
    {
        player = GetComponent<Player>();
        psa = GetComponent<Player_ScriptAnime>();
        UpdateTarget(); // �̺κ��� ���߿� ��������: 1. �Լ� -> ��������(�Լ� �ʿ� x), 2. Update ���� �Լ� ���� x
    }

    private void Start()
    {
        waitforattack = psa.waitforattack;
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    IEnumerator _SwordSlash(float _angle)
    {
        psa.AnimeSwordSlash(_angle);    //Play animation
        yield return new WaitForSeconds(psa.waitforattack);

        Collider2D[] c;
        c = GameMaster.gm.IsFlipPlayer() ? Physics2D.OverlapBoxAll(transform.position - boxpos, size, 0, lm) : Physics2D.OverlapBoxAll(transform.position + boxpos, size, 0, lm);

        for (int i = 0; i < c.Length; i++)
        {
            Enemy e = c[i].GetComponent<Enemy>();
            player.GiveDamage(e, 10f);
            Debug.Log(i);
        }

    }


    public void SwordSlash(float _angle)
    {
        StartCoroutine("_SwordSlash", _angle);

    }

    

    void UpdateTarget()
    {
        if (psa == null)
        {
            Debug.Log("Target missing");
            GameObject go = GameObject.FindGameObjectWithTag("Player");
            psa = go.GetComponent<Player_ScriptAnime>();
        }
    }
}
