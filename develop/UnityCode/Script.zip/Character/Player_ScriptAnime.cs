using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_ScriptAnime : MonoBehaviour
{
    public Transform playerarm;
    public float sword_playinterval;
    [Header("The number used for making angle per denominator")]
    public float denominator;   //�и�
    public float dest_angle;
    public float waitforattack = 1.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
      
            
    }


    public void AnimeSwordSlash(float ang)
    {
        StartCoroutine("_AnimeSwordSlash", ang);

    }

    IEnumerator _AnimeSwordSlash(float _angle)
    {
        float angle = _angle;
        playerarm.localRotation = Quaternion.Euler(0f, 0f, angle);
        yield return new WaitForSeconds(waitforattack);
        int repeat_num = (int)((_angle - dest_angle) * (denominator / _angle));

        //Animation for arm rotating down
        for(int i = 0; i < repeat_num; i++)
        {
            angle -= _angle / denominator;
            playerarm.localRotation = Quaternion.Euler(0f, 0f, angle);

            yield return new WaitForSeconds(sword_playinterval);
        }

        Debug.Log("angle: " + angle);

        float angle_ = angle;
        //back to former position
        for (int i = 0; i < (int)denominator; i++)
        {
            
            angle -= (angle_ / denominator);         
            playerarm.localRotation = Quaternion.Euler(0f, 0f, angle);

            yield return new WaitForSeconds(sword_playinterval);
        }

        //Debug.Log(waitforattack + repeat_num * sword_playinterval + denominator * sword_playinterval);

        // Total Animation Play time: waitforattack + repeat_num * sword_playinterval + denominator * sword_playinterval

    }
}
