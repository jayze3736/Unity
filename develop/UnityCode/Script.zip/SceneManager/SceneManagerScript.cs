using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class SceneManagerScript
{
    //public static SceneManagerScript scenemanager = null;
    
    //public Vector3 curScenespawnpoint;

    public delegate void EventAfterLoaded(Scene scene, LoadSceneMode mode);



    //scene�� �ε� �ɶ����� hierachy�� �����ϴ� spawnpoint�� �ٲ����

    //private void OnEnable()
    //{
        
    //}

    //public void Awake()
    //{
    //    if (scenemanager == null)
    //    {
    //        scenemanager = this;
    //    }
    //    else if (scenemanager != this)
    //    {
    //        Destroy(this);
    //    }
        
    //    //OnSceneLoaded(UpdateSpawnPoint);    //subscribe event   //3
        

    //}
    
   
    // Start is called before the first frame update
    //public void Start()
    //{
    //    Debug.Log(GameMaster.gm);

    //    DontDestroyOnLoad(this.gameObject);
    //}

    //// Update is called once per frame
    //void Update()
    //{
        
    //}

    

    public static void LoadNextScene()
    {

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        //SceneEventManager.eventmanager.OnSceneLoaded();
        Debug.Log("next Scene Loaded");

        
    }

    
    

    public static void LoadScene(string name, bool isadditive = false)
    {
        try
        {
            SceneManager.LoadScene(name, isadditive ? LoadSceneMode.Additive : LoadSceneMode.Single);   //Note: In most cases, to avoid pauses or performance hiccups while loading, you should use the asynchronous version of this command which is: LoadSceneAsync.
        }
        catch(Exception e)
        {

            Debug.Log(e);
        }
        
        
  
    }

    public static void LoadScene(int buildindex, bool isadditive = false)
    {
        try
        {
            SceneManager.LoadScene(buildindex, isadditive ? LoadSceneMode.Additive : LoadSceneMode.Single);   //Note: In most cases, to avoid pauses or performance hiccups while loading, you should use the asynchronous version of this command which is: LoadSceneAsync.
        }
        catch (Exception e)
        {

            Debug.Log(e);
        }



    }


    //public static void UpdateSpawnPoint()
    //{
    //    curScenespawnpoint = GameObject.FindGameObjectWithTag("spawnpoint").transform.position; //4
    //    Debug.Log("SpawnPoint Updated");
    //}
    

    
}
