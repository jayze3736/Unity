using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mushroom_move : MonoBehaviour
{
    
    Vector3[] _raydirection = new Vector3[4];   //������ ȸ������ �ٲ�ߵǴ� ray�� ������ ����Ǿ��ִ� �迭
    Vector3[] _raydirection_left = new Vector3[4];  //���� ȸ������ �ٲ�ߵǴ� ray�� ������ ����Ǿ��ִ� �迭
    public bool isrotate_left = false;

    int _index = 0;
    int index {
        get {
            return (_index % 4);    // 0,1,2,3 ������ �迭 �ε��� ����Ŭ
        }
        set {
            _index = value;
        }
    }
    bool ismove = true; //�ڷ�ƾ Rotate�� ����Ǵ� ���ȿ��� �������� �ʰ��ϱ����� ����ϴ� ������ ����
    string prev_pointName = " ";    // ray�� ������ TurningPoint�� �ٽ� �������� �ʱ� ���� ����ϴ� ����


    public int frameNum = 60;   // �ڷ�ƾ�� for���� �ֱ⸶�� �󸶳� ȸ���� ���ΰ�
    Vector3 center; //������Ʈ�� ȸ������ �߽� ��ġ
    public float radius = 0.8f;   //ȸ�� �ݰ�
    //Vector3[] center_dir = new Vector3[4];   center_dir == _raydirection�̹Ƿ� _raydirection ���
    

    public float v_lookahead = 0.5f;    // ray�� �󸶳� ���� ��ġ���� ����� ���ΰ�.
    Vector3 [] lookahead = new Vector3[4];   // +x -> -y -> -x -> +y ������ ȸ������ �ٲ�����
    Vector3[] lookahead_left = new Vector3[4];   // -x -> -y -> +x -> +y ������ ȸ������ �ٲ�����
    public float ray_distance = 0.7f;   //ray�� ������ ����ΰ�.
    public LayerMask turningPoint;  //turningPoint Layer ���� �����ϱ� ���� ���̾� ����

    public float velocity = 2.0f;   // ������Ʈ�� �ӵ�
    public float period = 0.03f;
    public int damage = 1;
    Animator anim;
    Enemy enemy;

    private void OnTriggerStay2D(Collider2D collision)
    {
        Player p = collision.GetComponent<Player>();
        bool detected_boxcollider = (collision.GetType() == typeof(BoxCollider2D)) ? true : false;
        Debug.Log(p.name);
        //Debug.Log(Player.player.playerstats.lives);
        Debug.Log(detected_boxcollider);
        if (p != null && detected_boxcollider)
        {
            enemy.GiveDamage(damage);
        }
    }

    

    private void Awake()
    {
         

        _raydirection[0] = Vector3.down;
        _raydirection[1] = Vector3.left;
        _raydirection[2] = Vector3.up;
        _raydirection[3] = Vector3.right;

        lookahead[0] = new Vector3(+v_lookahead , 0f, 0f);
        lookahead[1] = new Vector3(0f, -v_lookahead, 0f);
        lookahead[2] = new Vector3(-v_lookahead, 0f, 0f);
        lookahead[3] = new Vector3(0, +v_lookahead, 0f);

        _raydirection_left[0] = Vector3.down;
        _raydirection_left[1] = Vector3.right;
        _raydirection_left[2] = Vector3.up;
        _raydirection_left[3] = Vector3.left;

        lookahead_left[0] = new Vector3(-v_lookahead, 0f, 0f);
        lookahead_left[1] = new Vector3(0f, -v_lookahead, 0f);
        lookahead_left[2] = new Vector3(+v_lookahead, 0f, 0f);
        lookahead_left[3] = new Vector3(0, +v_lookahead, 0f);

        anim = GetComponent<Animator>();
        enemy = GetComponent<Enemy>();
        
    }
    // Start is called before the first frame update
    void Start()
    {

        if (isrotate_left)
        {
            anim.SetBool("ismoveleft", true);
        }
        if (enemy == null)
        {
            Debug.Log("No enemy script");

        }
    }

    // Update is called once per frame
    void Update()
    {
        DabbleInwater();

    }

    IEnumerator Rotate_right(int _index)
    {

        Vector3 a = transform.position;
        center = transform.position + _raydirection[_index] * radius;
        Vector3 _dir = (a - center).normalized;
        Vector3 _rotation = transform.rotation.eulerAngles;
        float ax = _rotation.x;
        float ay = _rotation.y;
        float az = _rotation.z;
        float theta = Mathf.Atan2(_dir.y, _dir.x);

        for(int i = 0; i < frameNum; i++)
        {
            theta -= (90.0f / frameNum) * Mathf.Deg2Rad;   //���������� ȸ��
            az -= 90.0f / frameNum;
            transform.rotation = Quaternion.Euler(ax,ay,az);
            float x =  radius * Mathf.Cos(theta);
            float y =  radius * Mathf.Sin(theta);
            transform.position = new Vector3(x, y, 0.0f) + center;
            yield return new WaitForSeconds(period);
            //yield return new WaitForEndOfFrame();
        }

        ismove = true;
    }

    IEnumerator Rotate_left(int _index)
    {

        Vector3 a = transform.position;
        center = transform.position + _raydirection_left[_index] * radius;
        Vector3 _dir = (a - center).normalized;
        Vector3 _rotation = transform.rotation.eulerAngles;
        float ax = _rotation.x;
        float ay = _rotation.y;
        float az = _rotation.z;
        float theta = Mathf.Atan2(_dir.y, _dir.x);

        for (int i = 0; i < frameNum; i++)
        {
            theta += (90.0f / frameNum) * Mathf.Deg2Rad;   //���������� ȸ��
            az += 90.0f / frameNum;
            transform.rotation = Quaternion.Euler(ax, ay, az);
            float x = radius * Mathf.Cos(theta);
            float y = radius * Mathf.Sin(theta);
            transform.position = new Vector3(x, y, 0.0f) + center;
            yield return new WaitForSeconds(period);
            //yield return new WaitForEndOfFrame();
        }

        ismove = true;
    }

    // �ڽź��� �� ��ġ���� ray�� �̿��Ͽ� Ư�� ����Ʈ�� �����Ͽ� ó���ϴ� �Լ�
    void DabbleInwater()
    {
        if (!isrotate_left)
        {
            Vector3 _dir = _raydirection[index];
            RaycastHit2D ray = Physics2D.Raycast(transform.position + lookahead[index], _dir, ray_distance, turningPoint);
            Debug.DrawRay(transform.position + lookahead[index], _dir * ray_distance);

            if (ray.collider != null && prev_pointName != ray.collider.name)
            {
                if (ray.collider.tag == "right_turning_point")
                {
                    prev_pointName = ray.collider.name;
                    ismove = false;
                    float _index = index; //1
                    index++; //2
                    StartCoroutine("Rotate_right", _index);
                }

            }

            if (ismove)
            {
                transform.Translate(velocity * Vector3.right * Time.deltaTime);

            }

        }

        if (isrotate_left)
        {

            Vector3 _dir = _raydirection_left[index];
            RaycastHit2D ray = Physics2D.Raycast(transform.position + lookahead_left[index], _dir, ray_distance, turningPoint);
            Debug.DrawRay(transform.position + lookahead_left[index], _dir * ray_distance);

            if (ray.collider != null && prev_pointName != ray.collider.name)
            {
                if (ray.collider.tag == "left_turning_point")
                {
                    prev_pointName = ray.collider.name;
                    ismove = false;
                    float _index = index; //1
                    index++; //2
                    StartCoroutine("Rotate_left", _index);

                }
            }
            if (ismove)
            {
                transform.Translate(velocity * Vector3.left * Time.deltaTime);
            }
        }
        
        

       

       

           
        

    }

    
}
