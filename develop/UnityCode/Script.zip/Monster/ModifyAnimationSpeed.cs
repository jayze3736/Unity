using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModifyAnimationSpeed : MonoBehaviour
{

    Animator anim;
    [Header("The name of float parameter that determines animation speed")]
    public string Playspeed = "Playspeed";

    [System.Serializable]
    public class AnimationSpeed
    {

        [Header("determines animation speed from median + 0 to median + 1")]
        public float median = 0.5f;

        [Header("enable random animation speed")]
        public bool is_randomspeed = true;

        public float random_speed;



        public void init()
        {
            if (is_randomspeed)
            {
                random_speed = Random.value + median;
            }
            else
            {
                random_speed = 1.0f;
            }
        }

    }

    [SerializeField]
    AnimationSpeed animspd = new AnimationSpeed();

    private void Awake()
    {
        anim = GetComponent<Animator>();
        animspd.init();
    }

    // Start is called before the first frame update
    void Start()
    {
        anim.SetFloat(Playspeed, animspd.random_speed);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
