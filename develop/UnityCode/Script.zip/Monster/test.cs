using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class test : MonoBehaviour
{

    [SerializeField]
    Button testbutton;

    // Start is called before the first frame update
    void Start()
    {
        testbutton.onClick.AddListener(SceneManagerScript.LoadNextScene);
        SceneManager.sceneLoaded += delegate { Debug.Log("SceneManager event raised"); };
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    

   
}
