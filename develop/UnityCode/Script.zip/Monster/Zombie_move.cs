using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie_move : MonoBehaviour
{
    
    public float search_distance;
    public float search_radius;

    public LayerMask target_layer;
    public Vector3 lookahead;
    public float ray_distance;
    public float searchingPeriod = 0.5f;
    public int damage = 1;

    public LayerMask end_points;
    
    Vector3 _localscale;
    Enemy enemy;

    private void OnTriggerStay2D(Collider2D collision)
    {
        Player p = collision.GetComponent<Player>();
        bool detected_boxcollider = (collision.GetType() == typeof(BoxCollider2D)) ? true : false;

        if (p != null && detected_boxcollider)
        {
            enemy.GiveDamage(damage);
        }
    }

    private void Awake()
    {
        enemy = GetComponent<Enemy>();
    }


    // Start is called before the first frame update
    void Start()
    {
        _localscale = transform.localScale;
        StartCoroutine("SearchPlayer");

        if (enemy == null)
        {
            Debug.Log("No enemy script");

        }
    }

    // Update is called once per frame
    void Update()
    {
        
        GameMaster.gm.DontFall(transform, ref lookahead, ray_distance, end_points);

    }

    IEnumerator SearchPlayer()
    {

        Collider2D player = Physics2D.OverlapCircle(transform.position, search_radius, target_layer);
        Debug.DrawRay(transform.position, Vector3.right * search_radius);
        

        if(player != null)
        {
           if(transform.position.x  - player.transform.position.x > 0)    //zombie�� Player�� �����ʿ� ����
            {
                transform.localScale = new Vector3(-_localscale.x, _localscale.y, _localscale.z);
            }
            else
            {
                transform.localScale = _localscale;
            }

        }


        yield return new WaitForSeconds(searchingPeriod);
        StartCoroutine("SearchPlayer");

       
    }
}
