using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slime_movement : MonoBehaviour
{
    
    ///////
    Rigidbody2D rb; // rb
    Animator anim;

    [SerializeField]
    bool isfall;

    
    ///////


    [SerializeField]
    Transform groundPoint;

    [SerializeField]
    float radius = 1.0f;

    [SerializeField]
    LayerMask groundLayer;

    [SerializeField]
    LayerMask playerLayer;

    [SerializeField]
    float radius_searchPlayer = 10.0f;

    float moveanim_dur = 1.14f;
    float idleanim_dur = 2.0f;
    public int damage = 1;
    Enemy enemy;


    // check is grounded
    // if grounded move anim played, if not grounded fall anim played
    // fall anim gives slime force downward
    // 


    // Start is called before the first frame update


    private void OnCollisionEnter2D(Collision2D collision)
    {

        
        Player _p = collision.collider.GetComponent<Player>();
        bool detected_boxcollider = (collision.collider.GetType() == typeof(BoxCollider2D)) ? true : false;
        bool detected_circlecollider = (collision.collider.GetType() == typeof(CircleCollider2D)) ? true : false;
        if (_p != null && detected_boxcollider)
        {
            enemy.GiveDamage(damage);
        }
        else if (_p != null && detected_circlecollider)
        {
            enemy.GiveDamage(damage);
        }

    }


    void Awake()
    {
        rb = this.GetComponent<Rigidbody2D>();
        anim = this.GetComponent<Animator>();
        enemy = GetComponent<Enemy>();
    }

    private void Start()
    {
        if(rb == null)
        {
            Debug.LogError("There is no rb in: " + transform.name);
        }
        if(anim == null)
        {
            Debug.LogError("There is no anim in: " + transform.name);
        }
        if(groundPoint == null)
        {
            Debug.LogError("There is no groundPoint in: " + transform.name);
        }
        if (enemy == null)
        {
            Debug.Log("No enemy script");

        }


        StartCoroutine("findPlayer");
    }

    // Update is called once per frame
    void Update()
    {
        Fall();
        Debug.DrawLine(transform.position, radius_searchPlayer * Vector3.right + transform.position);
    }

    private void FixedUpdate()
    {
        
    }

    private void Idle()
    {
        anim.SetBool("ismove", false);
    }

    private void Move()
    {
        anim.SetBool("ismove", true);
    }

   /* IEnumerator MoveIdle()
    {
        for(int i = 0; i < 3; i++)
        {
            
            Move();
            yield return new WaitForSeconds(moveanim_dur);
        }

        Idle();
        yield return new WaitForSeconds(idleanim_dur);

        StartCoroutine("MoveIdle");


    }*/

    private void Fall()
    {
        GameMaster.gm.GroundCheckForYvalue(groundPoint.position, radius, groundLayer, anim, "isgrounded");

        if (isfall)
        {
            anim.SetBool("isfall", true);
        }
        else
        {
            anim.SetBool("isfall", false);
        }
       

       
        // raycast downward, there is no ground -> isfall to be true, or not is fall to be false
    }

    IEnumerator findPlayer()
    {
        Collider2D c = Physics2D.OverlapCircle(transform.position, radius_searchPlayer, playerLayer);
       


        if(c != null)
        {
            
            if(transform.position.x - c.transform.position.x > 0) // slime.x - character.x > 0 
            {
                transform.localScale = new Vector3(-1.0f,1.0f,1.0f); //Warning!! Hardcoded here
            }
            else
            {
                transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            }

            Move();
            yield return new WaitForSeconds(moveanim_dur);

        }
        else
        {
            Idle();
            yield return new WaitForSeconds(idleanim_dur);
        }

        StartCoroutine("findPlayer");
    }

    
}
