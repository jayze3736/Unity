using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Enemy : MonoBehaviour
{
    [System.Serializable]
    public class EnemyStats
    {
        public float  maxHP;
        private float _HP;
        
        public float HP
        {
            get { return _HP; }
            set
            { _HP = Mathf.Clamp(value, 0.0f, maxHP); }
        }
        public void init(float _atk, float _def, float _speed, bool _isrivival)
        {
            HP = maxHP;
            ATK = _atk;
            DEF = _def;
            Speed = _speed;
            isrivival = _isrivival;
        }

        float ATK;
        float DEF;
        float Speed;
        bool isrivival;
    }

    public EnemyStats enemystats = new EnemyStats();
    public float timer = 0;
    public void GiveDamage(int damage)
    {

        float period = 1.0f;

        // damage should be 0~5
        //if (!Player.player.playerstats.isinvincible)
        //{

        //    Player.player.DamagePlayer(damage);
        //    Debug.Log("Enemy gave " + damage + "to player");
        //}
       
        if (RunTimer(period))
        {
            Player.player.DamagePlayer(damage);
            Debug.Log("Enemy gave " + damage + "to player");
        }
        

    }

    public void Rivival()
    {

    }

    public void Start()
    {
        //just for debug
        enemystats.init(0f,0f,0f,false);
    }

    public bool RunTimer(float period)
    {
        if(timer == 0)  //�� ó�� ȣ��� ���� ����
        {
            timer += Time.deltaTime;    //���� �������Ѿ� 0���� �ӹ��� ��������
            return true;    // ���� ���� ���
        }

        timer += Time.deltaTime;    //�� ����


        if(timer >= period) //�ð����� �ֱ⿡ �ٴٸ��� �ٽ� timer �ʱ�ȭ
        {
            timer = 0;
            
        }

        return false;   // ���� ���� �ź�

        



    }


}
