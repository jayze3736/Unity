﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cobra_anim : MonoBehaviour
{
    [SerializeField]
    Transform attackPoint;

    [SerializeField]
    LayerMask whatToHit;

    [SerializeField]
    LayerMask playerLayer;

    [SerializeField]
    float radius_searchPlayer = 15.0f;

    [SerializeField]
    float attack_speed = 0.5f;

    

    Animator animator;
    bool isfindplayer = false;

    public float waitForanim = 1.3f;
    public float attack_searchsight = 1.5f;
    public int damage = 1;
    public float attackdelay;


    
    float moveanim_dur = 1.18f;
    float idleanim_dur = 1.29f;
    Enemy enemy;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Player _p = collision.collider.GetComponent<Player>();
        bool detected_boxcollider = (collision.collider.GetType() == typeof(BoxCollider2D)) ? true : false;
        bool detected_circlecollider = (collision.collider.GetType() == typeof(CircleCollider2D)) ? true : false;

        if (_p != null && detected_boxcollider)
        {
            enemy.GiveDamage(damage);
        }
        else if(_p != null && detected_circlecollider)
        {
            enemy.GiveDamage(damage);
        }

       
    }


    private void Awake()
    {
        animator = GetComponent<Animator>();
        enemy = GetComponent<Enemy>();
        
        
    }

    // Start is called before the first frame update
    void Start()
    {
        if(animator == null)
        {
            Debug.Log("No animator");
            
        }
        if (enemy == null)
        {
            Debug.Log("No enemy script");

        }

        //determine whether animation plays normal speed or random speed
        

        
        StartCoroutine("findPlayer");
        StartCoroutine("attack");
        
    }

    // Update is called once per frame
    void Update()
    {
        
        

    }

     

    IEnumerator attack()
    {
        
        RaycastHit2D hit;

        if(transform.localScale.x < 0)
        {
            hit = Physics2D.Raycast(attackPoint.position, Vector3.left, attack_searchsight, whatToHit);
            

        }
        else
        {
            hit = Physics2D.Raycast(attackPoint.position, Vector3.right, attack_searchsight, whatToHit);
            Debug.DrawLine(attackPoint.position, attackPoint.position + attack_searchsight * Vector3.right, Color.white);
        }
        


        if (hit.collider != null)
        {
            animator.SetBool("attackplayer", true);
            isfindplayer = true;


            /////////////////////////// Give damage to player
            Player _p = hit.transform.GetComponent<Player>();
            if(_p != null)
            {
                yield return new WaitForSeconds(attackdelay);
                enemy.GiveDamage(damage);
                
                
            }
            else
            {
                yield return new WaitForEndOfFrame();
            }
            
            ///////////////////////////
        }
        else
        {
            animator.SetBool("attackplayer", false);
            isfindplayer = false;
            yield return new WaitForEndOfFrame();

        }

        StartCoroutine("attack");
      
    }

   

    void moveAround()
    {
        if (!isfindplayer)
        {
            
            float leftOrRight = Random.value; // 0~1까지의 난수

            if (leftOrRight >= 0.5)
            {
                transform.localScale = new Vector3(-1 * transform.localScale.x, transform.localScale.y, transform.localScale.z);

            }
            animator. SetBool("moveCobra", true);
        }
       
    }

    void moveToPlayer()
    {
        if (!isfindplayer)
        {
         animator.SetBool("movefaster", true);
         animator.SetBool("moveCobra", false);
        }
       
    }

    void Idle()
    {
        animator.SetBool("moveCobra", false);
        animator.SetBool("movefaster", false);
    }

    IEnumerator findPlayer()
    {
        Collider2D c = Physics2D.OverlapCircle(transform.position, radius_searchPlayer, playerLayer);



        if (c != null)  //Player를 찾았을때
        {

            if (transform.position.x - c.transform.position.x > 0) // slime.x - character.x > 0 
            {
                transform.localScale = new Vector3(-1.0f, 1.0f, 1.0f); //Warning!! Hardcoded here
            }
            else
            {
                transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            }

            moveToPlayer();
            yield return new WaitForSeconds(moveanim_dur);
            

        }
        else    //Player를 찾지 못했을때
        {
            Idle();
            yield return new WaitForSeconds(idleanim_dur);

            moveAround();
            yield return new WaitForSeconds(moveanim_dur);

        }

        StartCoroutine("findPlayer");
    }


}



