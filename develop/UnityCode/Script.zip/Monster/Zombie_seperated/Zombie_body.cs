using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie_body : MonoBehaviour
{

    Enemy enemy;
    public int damage = 1;
    

   
    private void OnTriggerStay2D(Collider2D collision)
    {
        Player p = collision.GetComponent<Player>();
        bool detected_boxcollider = (collision.GetType() == typeof(BoxCollider2D)) ? true : false;

        if (p != null && detected_boxcollider)
        {
            enemy.GiveDamage(damage);
        }
    }

    private void Awake()
    {
        enemy = GetComponent<Enemy>();
        
        
    }

    // Start is called before the first frame update
    void Start()
    {
        //determine whether animation plays normal speed or random speed
       

       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
