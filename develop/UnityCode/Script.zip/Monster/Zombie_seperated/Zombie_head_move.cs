using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie_head_move : MonoBehaviour
{
    
    public float search_radius;

    public LayerMask target_layer;
    public Vector3 lookahead;
    public float ray_distance;

    public LayerMask end_points;
    Vector3 _localscale;
    Animator anim;
    public bool ismove;

    [Header("How fast head changes routes toward player")]
    public float searchingPeriod = 0.5f;

    public int damage = 1;
    Enemy enemy;

   

    

    private void OnTriggerStay2D(Collider2D collision)
    {

        Player p = collision.GetComponent<Player>();
        bool detected_boxcollider = (collision.GetType() == typeof(BoxCollider2D)) ? true : false;

        if (p != null && detected_boxcollider)
        {
            enemy.GiveDamage(damage);
        }
    }

    private void Awake()
    {
        anim = GetComponent<Animator>();
        enemy = GetComponent<Enemy>();
    }


    // Start is called before the first frame update
    void Start()
    {

        
        
        _localscale = transform.localScale;
        StartCoroutine("SearchPlayer");
    }

    // Update is called once per frame
    void Update()
    {
        anim.SetBool("ismove", ismove);
        GameMaster.gm.DontFall(transform, ref lookahead, ray_distance, end_points);


    }

    IEnumerator SearchPlayer()
    {

        Collider2D player = Physics2D.OverlapCircle(transform.position, search_radius, target_layer);
        Debug.DrawRay(transform.position, Vector3.right * search_radius);


        if (player != null)
        {
            if (transform.position.x - player.transform.position.x > 0)    //zombie�� Player�� �����ʿ� ����
            {
                transform.localScale = new Vector3(-_localscale.x, _localscale.y, _localscale.z);
            }
            else
            {
                transform.localScale = _localscale;
            }

        }


        yield return new WaitForSeconds(searchingPeriod);
        StartCoroutine("SearchPlayer");


    }
}

   

