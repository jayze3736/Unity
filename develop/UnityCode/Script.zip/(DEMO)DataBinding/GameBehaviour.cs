using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameBehaviour : MonoBehaviour
{

    public GameLogic GameLogic
    {
        get; set;
    }

    // Start is called before the first frame update
    void Start()
    {
        GameLogic = new GameLogic();

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
