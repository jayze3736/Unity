using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPBarView : MonoBehaviour
{
    public GameLogic gameLogic;


    [SerializeField]
    HPBarElementView element;

    [Header("default value is 244f, -90f, 0f")]
    [SerializeField]
    Vector2 startpos;

    [Header("default value is 146f")]
    [SerializeField]
    float distanceX;

    Vector3 _cachedStartpos = new Vector3(244f, -90f, 0f);
    float _cachedDistanceX = 146f;


    [SerializeField] Sprite fullState;
    [SerializeField] Sprite halfState;
    [SerializeField] Sprite emptyState;

    Image src;
    int maxhp;

    //List<HPBarElement> hpBar = new List<HPBarElement>();
    HPBarContext hpBarContext;

    // Start is called before the first frame update
    void Start()
    {
        //game logic���κ��� �ʱ�ȭ �۾�
        //gameLogic.PlayerStat.HPChanged += OnHPChanged;

        hpBarContext = new HPBarContext();
        maxhp = (int)hpBarContext.MaxHP;
        for (int i = 0; i < maxhp; i++)
        {
            hpBarContext.HPBar.Add(new HPBarElementContext()
            {
                FullState = fullState,
                HalfState = halfState,
                EmptyState = emptyState,
                Src = src

            });
            
        }
        
        //hpBarContext.HPBar = new List<HPBarElement>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public HPBarContext GetHPBarContext()
    {
        return hpBarContext;
    }

    void CreateHPBar()
    {
        Vector2 startpos = this.startpos;

        for (int i = 0; i < maxhp; i++)
        {
            HPBarElement e = Instantiate(element, this.transform).GetComponent<HPBarElement>();
            if (!ReferenceEquals(e, null))
            {
                e.SetRectTrans(startpos);
                //hpBar.Add(e);
            }
            startpos.x += distanceX;
        }
    }



    public void OnHPChanged(float hp)
    {
        HPBarContext context = GetHPBarContext();
        List<HPBarElementContext> hpBar = context.HPBar;

        int num_fullState = (int)hp; //full state�� element ���� = hp�� ���� �κ�
        float mod = hp - num_fullState; //������
        int index;
        //List<HPBarElement> hpBar = hpBarContext.HPBar;

        if (num_fullState > hpBar.Count)
        {
            num_fullState = hpBar.Count;
        }


        for (index = 0; index < num_fullState; index++)
        {
            hpBar[index].ChangeState(HPBarElementState.FULL);
        }

        index = num_fullState;

        if (mod >= 0.5f && mod < 1.0f)
        {
            hpBar[index].ChangeState(HPBarElementState.HALF);
            index++;
        }



        for (; index < hpBar.Count; index++)
        {
            hpBar[index].ChangeState(HPBarElementState.EMPTY);
        }




    }

}
