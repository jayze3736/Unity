using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPBarElementImageContext
{

    Property<Image> imageProperty = new Property<Image>();
    //Property<Sprite> spriteProperty = new Property<Sprite>();

    public Image Image
    {
        get { return imageProperty.Value; }
        set { imageProperty.Value = value; }
    }

    public Sprite Sprite
    {
        get { return Image.sprite; }
        set { Image.sprite = value; }
    }



}
