using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;





public class HPBarElementContext //: MonoBehaviour
{

   
    public HPBarElementContext()
    {
       
    }


    public enum State
    {
        FULL, HALF, EMPTY
    }

    public State curState;


    private readonly Property<Sprite> fullstate;
    private readonly Property<Sprite> halfstate;
    private readonly Property<Sprite> emptystate;

    private readonly Property<Image> src;


    public Sprite FullState
    {
        get { return fullstate.Value; }
        set { fullstate.Value = value; }
    
    }

    public Sprite HalfState
    {
        get { return halfstate.Value; }
        set { halfstate.Value = value; }

    }
    public Sprite EmptyState
    {
        get { return emptystate.Value; }
        set { emptystate.Value = value; }

    }

    //public HPBarElementImageContext Src
    //{
    //    get { return src.Value; }
    //    set { src.Value = value; }
    //}

    public Image Src
    {
        get { return src.Value; }
        set { src.Value = value; }
    }

    public Sprite Sprite
    {
        get { return Src.sprite; }
        set { Src.sprite = value; }
    }

    public void ChangeState(HPBarElementState state)
    {

        if (state == HPBarElementState.FULL)
        {
            Sprite = FullState;
        }
        else if (state == HPBarElementState.HALF)
        {
            Sprite = HalfState;
        }
        else if (state == HPBarElementState.EMPTY)
        {
            Sprite = EmptyState;
        }

    }




    //Image src;

    RectTransform rect;

    //private void Awake()
    //{
    //    if ((object)fullState == null)
    //    {
    //        Debug.LogError("'fullState' is missing");
    //    }

    //    if ((object)halfState == null)
    //    {
    //        Debug.LogError("'halfState' is missing");
    //    }


    //    if ((object)emptyState == null)
    //    {
    //        Debug.LogError("'emptyState' is missing");
    //    }

    //    //src = GetComponent<Image>();
    //    //rect = GetComponent<RectTransform>();

    //}




    //private void Start()
    //{

    //    Src.sprite = fullState;
    //    curState = State.FULL;

    //}

    //public void ChangeState(State state)
    //{

    //    if (state == State.FULL)
    //    {
    //        Src.sprite = fullState;
    //    }
    //    else if (state == State.HALF)
    //    {
    //        Src.sprite = halfState;
    //    }
    //    else if (state == State.EMPTY)
    //    {
    //        Src.sprite = emptyState;
    //    }

    //}

    //public bool DecreaseHP()
    //{

    //    // ���̻� ���� �� ������ false�� ��ȯ
    //    if (curState == State.EMPTY)
    //    {
    //        return false;
    //    }
    //    else
    //    {
    //        ++curState;
    //        ChangeState(curState);
    //        return true;
    //    }

    //}

    //public bool IncreaseHP()
    //{

    //    //���̻� �ø� �� ������ false�� ��ȯ
    //    if (curState == State.FULL)
    //    {
    //        return false;
    //    }
    //    else
    //    {
    //        --curState;
    //        ChangeState(curState);
    //        return true;
    //    }

    //}

    //public void SetRectTrans(Vector2 pos)
    //{
    //    rect.anchoredPosition = pos;

    //}
}
