using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPBarElementView : MonoBehaviour
{



    [SerializeField] Sprite fullState;
    [SerializeField] Sprite halfState;
    [SerializeField] Sprite emptyState;

    HPBarElementContext HPBarElementContext { get; set; }
    public HPBarElementState CurState { get; set; }


    // Start is called before the first frame update
    void Start()
    {
        HPBarElementContext = new HPBarElementContext();
        //HPBarElementContext.Src = new HPBarElementImageContext();
        //HPBarElementContext.Src.Image = GetComponent<Image>();
        HPBarElementContext.FullState = fullState;
        HPBarElementContext.HalfState = halfState;
        HPBarElementContext.EmptyState = emptyState;
        
        CurState = HPBarElementState.FULL;

        

    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private void Awake()
    {
        if ((object)fullState == null)
        {
            Debug.LogError("'fullState' is missing");
        }

        if ((object)halfState == null)
        {
            Debug.LogError("'halfState' is missing");
        }


        if ((object)emptyState == null)
        {
            Debug.LogError("'emptyState' is missing");
        }

        //src = GetComponent<Image>();
        //rect = GetComponent<RectTransform>();

    }




    //private void Start()
    //{

    //    Src.sprite = fullState;
    //    curState = State.FULL;

    //}

    

    //public bool DecreaseHP()
    //{

    //    // ���̻� ���� �� ������ false�� ��ȯ
    //    if (curState == State.EMPTY)
    //    {
    //        return false;
    //    }
    //    else
    //    {
    //        ++curState;
    //        ChangeState(curState);
    //        return true;
    //    }

    //}

    //public bool IncreaseHP()
    //{

    //    //���̻� �ø� �� ������ false�� ��ȯ
    //    if (curState == State.FULL)
    //    {
    //        return false;
    //    }
    //    else
    //    {
    //        --curState;
    //        ChangeState(curState);
    //        return true;
    //    }

    //}

    //public void SetRectTrans(Vector2 pos)
    //{
    //    rect.anchoredPosition = pos;

    //}
}
