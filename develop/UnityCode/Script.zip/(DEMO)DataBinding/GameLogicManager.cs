using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameLogicManager : MonoBehaviour
{
    public static GameLogicManager manager;

    PlayerStatus playerStatus;



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GetLogicInstance<T>()
    {


    }

    public void AddLogicData(object data)
    {
        //logiclist.Add(data);
    }


}
