using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShowSpriteRect : MonoBehaviour
{
   
    RectTransform recttrans;
    private void OnDrawGizmos()
    {

        if (this.enabled)
        {
            recttrans = GetComponent<RectTransform>();
            //var rect = recttrans.sizeDelta;
            //var rect = recttrans.sizeDelta;
            //Vector3 v = new Vector3(rect.x, rect.y, 0);
            //Rect rect = sprite.rect;
            //Gizmos.DrawWireCube(Vector3.zero, rect);
            DebugUtils.DrawLocalRectOnGizmos(recttrans, recttrans.rect);
        }
        

        //
    }

    // Start is called before the first frame update
    void Start()
    {
        recttrans = GetComponent<RectTransform>();
        
    }

    // Update is called once per frame
    void Update()
    {

        //Vector2 size = recttrans.sizeDelta;
        //DebugUtils.DrawBorderRect(transform, size, Color.red);
        
    }
}
