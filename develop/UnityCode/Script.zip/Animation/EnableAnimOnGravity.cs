using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnableAnimOnGravity : MonoBehaviour
{
    Rigidbody2D rb;
    Animator am;

    private void OnAnimatorMove()
    {
        rb.velocity = am.deltaPosition / Time.deltaTime;
    }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        am = GetComponent<Animator>();

        if(rb == null)
        {
            Debug.LogError("No rigidbody2D in this object: " + transform.name);
        }

        if(am == null)
        {
            Debug.LogError("No rigidbody2D in this object: " + transform.name);
        }
    }
    public void Start()
    {
        
    }

    public void Update()
    {
        
    }

}
