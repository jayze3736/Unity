using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public abstract class TestBindingView<TContext> : MonoBehaviour where TContext : class
{

    
    public TContext context;
    public string bindingPath;
    public string id;

    private void Init(TContext newContext, bool isUnique)
    {
        var result = GameLogicTree.tree.GetContextFromView<TContext>(bindingPath, id);
        //result.
        //if (status == null)
        //{
        //    status = new TestPlayerStatus(bindingPath);
        //}
        switch (result.State)
        {
            case ContextState.CanUse:
                Debug.Log("Can use");
                id = result.Id;
                context = result.Value;
                break;
            case ContextState.Empty:
                Debug.Log("CanUpdateContext");
                context = newContext;
                GameLogicTree.tree.UpdateContext(bindingPath, context, isUnique);
                
                //status = new TestPlayerStatus();
                //GameLogicTree.tree.AddContext(bindingPath, status);
                //SetContext
                break;
            case ContextState.Null:
                Debug.Log("CanCreateContext");
                context = newContext;
                var contextInfo = GameLogicTree.tree.AddNewContext<TContext>(bindingPath, context, isUnique);
                id = contextInfo.Id;
                
                break;
            case ContextState.CantUse:
                Debug.Log("CantUse");
                id = result.Id; //string.Empty
                context = null;
                break;
            case ContextState.TypeCastError:
                Debug.Log("TypeCastError");
                id = result.Id;
                context = null;
                break;
        }
    }
    public void InitUniqueInstance(TContext newContext)
    {
        Init(newContext, true);
    }

    public void InitNonUniqueInstance(TContext newContext)
    {
        Init(newContext, false);
    }


    public void InitElement(TContext newContext, int index)
    {
        var result = GameLogicTree.tree.GetContextElementByIndex<TContext>(bindingPath, index ,id);
        //result.
        //if (status == null)
        //{
        //    status = new TestPlayerStatus(bindingPath);
        //}
        switch (result.State)
        {
            case ContextState.CanUse:
                Debug.Log("Can use");
                id = result.Id;
                context = result.Value;
                break;
            case ContextState.Empty:
                Debug.Log("CanUpdateContext");
                context = newContext;
                GameLogicTree.tree.UpdateContext(bindingPath, context, true);

                //status = new TestPlayerStatus();
                //GameLogicTree.tree.AddContext(bindingPath, status);
                //SetContext
                break;
            case ContextState.Null:
                Debug.Log("CanCreateContext");
                context = newContext;
                //var contextInfo = GameLogicTree.tree.AddContext<TContext>(bindingPath, context, true);
                var contextInfo = GameLogicTree.tree.AddNewContextElementByIndex<TContext>(bindingPath, context, index, true);
                id = contextInfo.Id;

                break;
            case ContextState.CantUse:
                Debug.Log("CantUse");
                id = result.Id; //string.Empty
                context = null;
                break;
            case ContextState.TypeCastError:
                Debug.Log("TypeCastError");
                id = result.Id;
                context = null;
                break;
        }
    }



    protected void OnDestroy()
    {
        GameLogicTree.tree.DisposeNode(bindingPath, id);
    }

    
}




public class TestPlayerPrefab : TestBindingView<TestPlayerStatus>
{
    public int index;
    /// <summary>
    /// 1. �� PlayerPrefab���� PlayerStatus�� �ʱ�ȭ�� �� �ֵ��� �������
    /// </summary>


    TestPlayerStatus status;

    ////���⼭ OnDestroy�� �����ϰ� �ִ� Context�� �������(�ݳ�)
    //public TestPlayerStatus status;
    //public string bindingPath;
    //public string id;
    // Start is called before the first frame update
    void Start()
    {
        index = transform.GetSiblingIndex();
        InitElement(new TestPlayerStatus(), index);
        status = context;
        var node = GameLogicTree.tree.FindContextElementNode(bindingPath, index);
        Debug.Log(node.BindingPath);

        //context.onHPChanged += OnHPChanged;
        //context.onLevelChanged += OnLevelChanged;
        //context.onMaxSTMChanged += OnMaxSTMChanged;
        //context.onNickNameChanged += OnNickNameChanged;
        //context.onMaxHPChanged += OnMaxHPChanged;

        //status.TestLifeDecrease();
        //status.TestMaxHPDecrease();
        //status.TestMaxSTMDecrease();
        //status.TestNickNameChange();
        

        ////status = GameLogicTree.tree.TryGetContextAndCreateNewContext(new TestPlayerStatus(bindingPath), bindingPath);

        ////status = GameLogicTree.tree.GetContext<TestPlayerStatus>(bindingPath, id);
        //var result = GameLogicTree.tree.GetContext<TestPlayerStatus>(bindingPath, id);
        ////result.
        ////if (status == null)
        ////{
        ////    status = new TestPlayerStatus(bindingPath);
        ////}
        //switch (result.State)
        //{
        //    case ContextState.CanUse:
        //        id = result.Id;
        //        status = result.Value;
        //        break;
        //    case ContextState.CanUpdateContext:
        //        status = new TestPlayerStatus();
        //        GameLogicTree.tree.AddContext(bindingPath, status);
        //        //status = new TestPlayerStatus();
        //        //GameLogicTree.tree.AddContext(bindingPath, status);
        //        //SetContext
        //        break;
        //    case ContextState.CanCreateContext:
        //        status = new TestPlayerStatus();
        //        GameLogicTree.tree.AddContext(bindingPath, status);
        //        break;
        //    case ContextState.CantUse:
        //        id = result.Id; //string.Empty
        //        break;
        //    case ContextState.TypeCastError:
        //        id = result.Id;
        //        break;


        }



        //status = GameLogicTree.tree.GetContext<TestPlayerStatus>("TestPlayerStatus");

        //var logic = GameLogicTree.tree.TryGetContextAndCreateInstance("TestPlayerStatus", new TestPlayerStatus());
        //status = logic.Value;
        //Debug.Log(status.HP);
        //status.TestLifeDecrease();
    
    public void OnHPChanged(int hp)
    {
        Debug.Log("OnHPChanged" + hp);
    }

    public void OnMaxHPChanged(int maxhp)
    {
        Debug.Log("OnMaxHPChanged" + maxhp);
    }
   

    public void OnMaxSTMChanged(float stm)
    {
        Debug.Log("OnSTMChanged" + stm);
    }

    

    public void OnNickNameChanged(string nickname)
    {
        Debug.Log("OnNickNameChanged" + nickname);
    }

    public void OnLevelChanged(int lv)
    {
        Debug.Log("OnLevelChanged" + lv);
    }


    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.O))
        {
            status.TestLifeDecrease();
        }

        if (Input.GetKeyDown(KeyCode.I))
        {
            status.TestLifeIncrease();
        }





    }

  
}
