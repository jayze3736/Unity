using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 
/// </summary>
public class GameLogicContextNode
{
    
    object context;
    string id;
    bool isUnique;
    private string name;
    private string bindingPath;

    
    GameLogicContextNode parent;
    
    private Dictionary<string, GameLogicContextNode> children;

    public GameLogicContextNode Parent { get { return parent; } }

    public string Name { get => name; }
    public string BindingPath { get => bindingPath; }

    public object Context { get => context;  set { this.context = value; } }
    public string Id { get => id; set { this.id = value; } }

    /// <summary>
    /// ������ �ϳ��� ��ü�� ������ �����ؾ��ϴ� ��� true�� set
    /// </summary>
    public bool IsUnique { get => isUnique; set { isUnique = value; } }
    

    public GameLogicContextNode(string name, string bindingPath, object context ,GameLogicContextNode parent, bool isUnique = false)
    {
        this.name = name;
        this.parent = parent;
        children = new Dictionary<string, GameLogicContextNode>();
        this.bindingPath = bindingPath;
        this.id = string.Empty;
        this.isUnique = isUnique;
        this.context = context;
    }

    public GameLogicContextNode(string name, string bindingPath, GameLogicContextNode parent, bool isUnique = false)
    {
        this.name = name;
        this.parent = parent;
        children = new Dictionary<string, GameLogicContextNode>();
        this.bindingPath = bindingPath;
        this.id = string.Empty;
        this.isUnique = isUnique;
    }

    
    public GameLogicContextNode()
    {
        children = new Dictionary<string, GameLogicContextNode>();
        this.id = string.Empty;
        this.isUnique = false;
    }



    public bool IsChildExist(string bindingpath)
    {
        try
        {
            GameLogicContextNode node = children[bindingpath];
        }
        catch (KeyNotFoundException)
        {
            return false;
        }
        
        return true;

    }

    public GameLogicContextNode GetChildContext(string bindingpath, bool isUnique = false)
    {
        GameLogicContextNode node;
        try
        {
            node = children[bindingpath];
        }
        catch (KeyNotFoundException)
        {
            return null;
        }
        return node;
    }

    

    public bool RemoveChildContext(string bindingpath)
    {

        return children.Remove(bindingpath);

    }

    
    public bool CheckId(string id)
    {
        return (id == this.id) && IsUsing();
    }

    public bool IsUsing()
    {
        return !string.IsNullOrEmpty(id);
    }

    public void DisposeID()
    {
        id = string.Empty;
    }


    public void UpdateChildContext(object context)
    {
        this.context = context;
    }


    public void AddChildContext(string bindingpath, GameLogicContextNode child)
    {
        children.Add(bindingpath, child);
    }

   


    public bool IsEmpty()
    {
        return (context == null);
    }

    
  
    

    /// <summary>
    /// �� ��尡 �ڽ� ��带 ������ �ִ°�
    /// </summary>
    /// <returns></returns>
    public bool Haschildren()
    {
        return (children.Count != 0) && (children != null);
    }




}
