using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace jsh.hello
{
    public class TestPrefab : MonoBehaviour
    {

        public test tst;

        // Start is called before the first frame update
        void Start()
        {
            tst = new test();
            tst.PrintHi();
            ITest it = tst;
            it.PrintHi();

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}

