using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Context�� �ʱ�ȭ �ϰų� LogicTree���� Context�� �����ͼ� ��ӹ޴� Ŭ�������� ����� �� �ֵ��� �Ѵ�.
/// </summary>
/// <typeparam name="TContext"></typeparam>
public abstract class View<TContext> : MonoBehaviour where TContext : class
{
    public TContext context;
    [SerializeField]
    protected string bindingPath; 

    protected string id;


    

    private void Init(TContext newContext, bool isUnique)
    {
        var result = GameLogicTree.tree.GetContextFromView<TContext>(bindingPath, id);
        //result.
        //if (status == null)
        //{
        //    status = new TestPlayerStatus(bindingPath);
        //}
        switch (result.State)
        {
            case ContextState.CanUse:
                Debug.Log("Can use");
                id = result.Id;
                context = result.Value;
                break;
            case ContextState.Empty:
                Debug.Log("CanUpdateContext");
                context = newContext;
                GameLogicTree.tree.UpdateContext(bindingPath, context, isUnique);

                //status = new TestPlayerStatus();
                //GameLogicTree.tree.AddContext(bindingPath, status);
                //SetContext
                break;
            case ContextState.Null:
                Debug.Log("CanCreateContext");
                context = newContext;
                var contextInfo = GameLogicTree.tree.AddNewContext<TContext>(bindingPath, context, isUnique);
                id = contextInfo.Id;

                break;
            case ContextState.CantUse:
                Debug.Log("CantUse");
                id = result.Id; //string.Empty
                context = null;
                break;
            case ContextState.TypeCastError:
                Debug.Log("TypeCastError");
                id = result.Id;
                context = null;
                break;
        }
    }

    

    public void InitUniqueInstance(TContext newContext)
    {
        Init(newContext, true);
    }

    public void InitNonUniqueInstance(TContext newContext)
    {
        Init(newContext, false);
    }


    public void InitElement(TContext newContext, int index)
    {
        var result = GameLogicTree.tree.GetContextElementByIndex<TContext>(bindingPath, index, id);
        //result.
        //if (status == null)
        //{
        //    status = new TestPlayerStatus(bindingPath);
        //}
        switch (result.State)
        {
            case ContextState.CanUse:
                Debug.Log("Can use");
                id = result.Id;
                context = result.Value;
                break;
            case ContextState.Empty:
                Debug.Log("CanUpdateContext");
                context = newContext;
                GameLogicTree.tree.UpdateContext(bindingPath, context, true);

                //status = new TestPlayerStatus();
                //GameLogicTree.tree.AddContext(bindingPath, status);
                //SetContext
                break;
            case ContextState.Null:
                Debug.Log("CanCreateContext");
                context = newContext;
                //var contextInfo = GameLogicTree.tree.AddContext<TContext>(bindingPath, context, true);
                var contextInfo = GameLogicTree.tree.AddNewContextElementByIndex<TContext>(bindingPath, context, index, true);
                id = contextInfo.Id;

                break;
            case ContextState.CantUse:
                Debug.Log("CantUse");
                id = result.Id; //string.Empty
                context = null;
                break;
            case ContextState.TypeCastError:
                Debug.Log("TypeCastError");
                id = result.Id;
                context = null;
                break;
        }
    }

    protected void OnDestroy()
    {
        UnRegisterLogicChangedEvent();
        GameLogicTree.tree.DisposeNode(bindingPath, id);
       
    }

    
    protected abstract void RegisterLogicChangedEvent();
    protected abstract void UnRegisterLogicChangedEvent();




}
