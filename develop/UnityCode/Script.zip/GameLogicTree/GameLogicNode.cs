using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class GameLogicNode
{

    private Type type;
    

    private string name;
    private string bindingPath;

    private object value;
    private Dictionary<string, ILogic> logics;
    //private Dictionary<string, Logic<>>
    private List<GameLogicNode> children;
    

    public string Name { get => name; }
    public string BindingPath { get => bindingPath; }
    public object Value {

        get
        {
            return value;
        }
        
        
        set
        {
            if (Equals(this.value, value))
            {
                return;
            }

            
            
            this.value = value;
            OnValueChanged(this.value);
            //OnValueChanged()

        }
    

    
    }

    public Type Type { get => type; }
    public List<GameLogicNode> Children { get => children; }

    //public List<SerializedProperty> properties;

    
    private void OnValueChanged(object value)
    {
        if (value != null)
        {
            this.type = value.GetType();
        }

    }



    public GameLogicNode(string name, object value, string bindingPath)
    {
        this.name = name;
        this.value = value;
        this.type = (value == null) ? null : value.GetType();
        children = new List<GameLogicNode>();
        
        this.bindingPath = bindingPath;

    }

    public GameLogicNode(string name, object value)
    {
        this.name = name;
        this.value = value;
        this.type = (value == null) ? null : value.GetType();
        children = new List<GameLogicNode>();


    }

    public GameLogicNode(string name)
    {
        this.name = name;
        children = new List<GameLogicNode>();


    }
    public GameLogicNode()
    {
        children = new List<GameLogicNode>();


    }

    public bool IsChildExist(string name)
    {
        foreach (GameLogicNode child in children)
        {
            if (child.Name == name)
            {
                return true;
            }
        }
        return false;

    }

    public GameLogicNode FindChildNode(string name)
    {
        foreach (GameLogicNode child in children)
        {
            if (child.Name == name)
            {
                return child;
            }
        }
        return null;
    }


    public void DeleteChild(string name)
    {
        var node = FindChildNode(name);
        if(node == null)
        {
            Debug.Log("Delete Failed. There is no node named " + name);
        }
        children.Remove(node);
    }

    //public bool IsTypeEqual(Type type)
    //{
    //    return (type == this.type) || (type == null);
    //}
    

    public void AddChildren(GameLogicNode child)
    {
        children.Add(child);
    }

    /// <summary>
    /// �� ��尡 Property�� �����ϰ��ִ°� 
    /// </summary>
    /// <returns></returns>
    public bool IsEmpty()
    {
        return (value == null);
    }

    /// <summary>
    /// �� ��尡 �ڽ� ��带 ������ �ִ°�
    /// </summary>
    /// <returns></returns>
    public bool Haschildren()
    {
        return (children.Count != 0) && (children != null);
    }

   

}
