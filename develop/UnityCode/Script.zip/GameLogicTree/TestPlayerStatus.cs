using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;







[System.Serializable]
public class TestPlayerStatus
{

    

    #region Serialized Field
    [SerializeField] Logic<int> maxhp;

    [SerializeField] Logic<float> max_stamina;
    [SerializeField] Logic<int> hp;

    [SerializeField] Logic<string> nickname ; //TestPlayerStatus.nickname
    [SerializeField] Logic<int> level;// = new Logic<int>();
    #endregion

    public TestPlayerStatus(int maxhp, float max_stamina, int hp, string nickname, int level)
    {
        this.maxhp = new Logic<int>(maxhp);
        this.max_stamina = new Logic<float>(max_stamina);
        this.hp = new Logic<int>(hp);
        this.nickname = new Logic<string>(nickname);
        this.level = new Logic<int>(level);
       
    }

    public TestPlayerStatus()
    {
        maxhp = new Logic<int>();
        max_stamina = new Logic<float>();
        hp = new Logic<int>();
        nickname = new Logic<string>();
        level = new Logic<int>();
    }










    //Need
    public event Action<int> onMaxHPChanged
    {
         add { maxhp.onValueChanged += value; }
         remove { maxhp.onValueChanged -= value; }
    }

    public event Action<float> onMaxSTMChanged
    {
        add { max_stamina.onValueChanged += value; }
        remove { max_stamina.onValueChanged -= value; }
    }

    public event Action<int> onHPChanged
    {
        add { hp.onValueChanged += value; }
        remove { hp.onValueChanged -= value; }
    }

    public event Action<string> onNickNameChanged
    {
        add { nickname.onValueChanged += value; }
        remove { nickname.onValueChanged -= value; }
    }

    public event Action<int> onLevelChanged
    {
        add { level.onValueChanged += value; }
        remove { level.onValueChanged -= value; }
    }
    //#NeedEnd



    //Need
    public int MaxHP
    {
        get => maxhp.Value;
        set { maxhp.Value = value; }
    }
    public int HP
    {
        get => hp.Value;
        set { hp.Value = value;  }
    }
    public float MaxSTM
    {
        get => max_stamina.Value;
        set { max_stamina.Value = value; }
    }
    public string NickName
    {
        get => nickname.Value;
        set { nickname.Value = value; }
    }
    public int LV
    {
        get => level.Value;
        set { level.Value = value; }
    }
   //#Need

    public void Init()
    {
        HP = MaxHP;
       
    }
    
    public void TestLifeDecrease()
    {
        HP--;
        Debug.Log("status.HP:" + HP);
    }

    public void TestLifeIncrease()
    {
        HP++;
        Debug.Log("status.HP:" + HP);
    }
    
    public void TestMaxSTMDecrease()
    {
        MaxSTM -= 10.0f;
        Debug.Log("status.MaxSTM:" + MaxSTM);
    }
    public void TestMaxHPDecrease()
    {
        MaxHP--;
        Debug.Log("status.MaxHP:" + MaxHP);
    }
    public void TestNickNameChange()
    {
        NickName = string.Empty;
        Debug.Log("status.nickname:" + NickName);
    }






    #region Non-Serialized Field

    private bool isinvincible = false;
    float stamina;

    float atk;
    float def;
    float sp;

    /// <summary>
    /// �ʴ� ���¹̳� ȸ����(Vitality)
    /// </summary>
    float vit_stm_per_sec;

    [System.NonSerialized]
    public GameObject curweapon;

    /// <summary>
    /// hp�� �ּ� ������, �� ������ �������� ������ �ش� �������� ����� �������� ���� ����� ������ �������� ȯ��ȴ�. 
    /// </summary>
    /// ���� ������� hp element�� full(1), half(0.5), empty(0) ������ ���¸� ����ϱ⶧���� unit_hp�� 0.5�����Ѵ�.
    [System.NonSerialized]
    float unit_hp = 0.5f;


    #endregion


    #region EventHandler

    public Action<float> PlayerDamaged;
    public Action<float> PlayerHealed;
    public Action<float> StaminaChanged;
    public Action NotEnoughStaminaUsed;
    public Action<int> MaxHPIncreased;
    public Action<int> MaxHPDecreased;

    #endregion






    
}
