using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestPlayerSpawner : MonoBehaviour
{
    public TestPlayerPrefab prefab;
    public Stack<TestPlayerPrefab> players = new Stack<TestPlayerPrefab>();

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            players.Push(Instantiate(prefab, this.transform));
        }
        if (Input.GetKeyDown(KeyCode.D))
        { 
            Destroy(players.Pop().gameObject);
        }
        
    }
}
