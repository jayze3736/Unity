using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public enum ContextState
{
    Null, Empty, CantUse, CanUse, TypeCastError
}

public class ContextResult<T>
{
    private ContextState state;
    private string id;
    private T value;

    public ContextState State { get => state; }
    public string Id { get => id; }
    public T Value { get => value; }

    public ContextResult(ContextState state, string id, T value)
    {
        this.state = state;
        this.id = id;
        this.value = value;
    }


    
}




public class GameLogicTree
{
    public static GameLogicTree tree = new GameLogicTree();

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void init()
    {
        Debug.Log("Reset");
        tree = new GameLogicTree();
    }

    


    public GameLogicContextNode root;
    public char pathSeperator;
    //tree�� ����� node�� ���� 
    int nodecount = 0;
   
    public int NodeCount { get { return nodecount; } }
   



    public GameLogicTree()
    {
        root = new GameLogicContextNode();
        pathSeperator = '.';
    }
    public GameLogicTree(char seperator)
    {
        root = new GameLogicContextNode();
        if(seperator == '[' || seperator == ']')
        {
            Debug.LogError("Invalid seperator: '[' or ']' not be allowed");
            return;
        }
        this.pathSeperator = seperator;
    }

    

   

    /// <summary>
    /// �ܺο��� Context�� �������� ���� ���������ʴ� Context�� ��� Tree�� �߰�
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="path"></param>
    /// <param name="value"></param>
    /// <returns></returns>
   

    



    
    //public T TryGetContextAndCreateNewContext<T>(T context, string path)
    //{

    //    var node = FindContextNode(path);
    //    if(node == null)
    //    {
    //        Debug.Log("Node is null, I will create new context node at path: " + path);
    //        var newnode = AddContext(path);
    //        newnode.Context = context;
            
    //    }
    //    else if (node.IsEmpty())
    //    {
    //        node.Context = context;
    //    }

    //    try
    //    {
    //        return (T)node.Context;
    //    }
    //    catch (InvalidCastException)
    //    {
    //        Debug.LogError("Invalid Cast Exception");
    //        return default(T);
    //    }
        



    //}

    
  



    public string GetRandomHashId()
    {
        return Guid.NewGuid().ToString();
    }



    public ContextResult<T> GetContextFromView<T>(string path, string id)
    {
        var node = FindContextNode(path);

        try
        {
            ContextResult<T> result;
            if (node == null)
            {
                string hash = GetRandomHashId();
                result = new ContextResult<T>(ContextState.Null, hash, default(T));
                return result;
            }


            if (node.IsEmpty())
            {
                Debug.Log("Node is Empty at: " + path);
                result = new ContextResult<T>(ContextState.Empty, string.Empty, default(T));
                return result;
            }



            if (node.IsUnique) //�������� ��ü�� ������ ������ �� ����
            {
                if (!node.IsUsing()) // ��������� ������
                {
                    string hash = GetRandomHashId();
                    result = new ContextResult<T>(ContextState.CanUse, hash, (T)node.Context);
                    Debug.Log(hash);
                    
                    node.Id = hash;
                    Debug.Log("Node is Using:" + node.IsUsing().ToString());
                    return result;
                    //id �߱�, �׸��� context ��ȯ
                }
                else // ������϶�
                {
                    if (!node.CheckId(id)) //���� id�� node�� ���̵�� �������� ��
                    {
                        Debug.Log("Current node is using");
                        result = new ContextResult<T>(ContextState.CantUse, string.Empty, default(T));
                        return result;
                    }

                }

            }
            else //unique�����ʰ� 
            {
                if (!node.IsUsing()) //�ƹ��� ������� �ʴ� ���¿��� ��û�� �������� 
                {
                    node.Id = GetRandomHashId(); //node�� id �ʱ�ȭ(���� �ǹ̾��� �׳� ������� ���¸� �ٲ�)
                }
            }

            result = new ContextResult<T>(ContextState.CanUse, node.Id, (T)node.Context);
            return result; //�������� ��ü�� ������ ������ �� ������ �Ǵ� ������ id�� ���� ��ü�� context�� ��䱸������ Context�� ��ȯ


        }
        catch (InvalidCastException)
        {
            var result = new ContextResult<T>(ContextState.TypeCastError, string.Empty, default(T));
            Debug.LogError("Given type cannot cast context");
            return result;
        }


    }

    

    public ContextResult<T> GetContextElementByIndex<T>(string path, int index ,string id)
    {
        var node = FindContextElementNode(path, index);

        try
        {
            ContextResult<T> result;
            if (node == null)
            {
                string hash = GetRandomHashId();
                result = new ContextResult<T>(ContextState.Null, hash, default(T));
                return result;
            }


            if (node.IsEmpty())
            {
                Debug.Log("Node is Empty at: " + path);
                result = new ContextResult<T>(ContextState.Empty, string.Empty, default(T));
                return result;
            }



            if (node.IsUnique) //�������� ��ü�� ������ ������ �� ����
            {
                if (!node.IsUsing()) // ��������� ������
                {
                    string hash = GetRandomHashId();
                    result = new ContextResult<T>(ContextState.CanUse, hash, (T)node.Context);
                    Debug.Log(hash);

                    node.Id = hash;
                    Debug.Log("Node is Using:" + node.IsUsing().ToString());
                    return result;
                    //id �߱�, �׸��� context ��ȯ
                }
                else // ������϶�
                {
                    if (!node.CheckId(id)) //���� id�� node�� ���̵�� �������� ��
                    {
                        Debug.Log("Current node is using");
                        result = new ContextResult<T>(ContextState.CantUse, string.Empty, default(T));
                        return result;
                    }

                }

            }
            else //unique�����ʰ� 
            {
                if (!node.IsUsing()) //�ƹ��� ������� �ʴ� ���¿��� ��û�� �������� 
                {
                    node.Id = GetRandomHashId();
                }
            }

            result = new ContextResult<T>(ContextState.CanUse, node.Id, (T)node.Context);
            return result; //�������� ��ü�� ������ ������ �� ������ �Ǵ� ������ id�� ���� ��ü�� context�� ��䱸������ Context�� ��ȯ


        }
        catch (InvalidCastException)
        {
            var result = new ContextResult<T>(ContextState.TypeCastError, string.Empty, default(T));
            Debug.LogError("Given type cannot cast context");
            return result;
        }


    }




    //public T GetContext<T>(string path, string id)
    //{
    //    var node = FindContextNode(path);

    //    try
    //    {
    //        if(node == null)
    //        {
    //            return default(T);
    //        }


    //        if (node.IsEmpty())
    //        {
    //            Debug.Log("Node is Empty at: " + path);
    //            return default(T);
    //        }



    //        if (node.IsUnique) //�������� ��ü�� ������ ������ �� ����
    //        {
    //            if (!node.IsUsing()) // ��������� ������
    //            {
    //                return (T)node.Context;
    //                //id �߱�, �׸��� context ��ȯ
    //            }
    //            else // ������϶�
    //            {
    //                if (!node.CheckId(id)) //���� id�� node�� ���̵�� �������� ��
    //                {
    //                    Debug.Log("Current node is using");
    //                    return default(T);
    //                }

    //            }

    //        }

    //         return (T)node.Context; //�������� ��ü�� ������ ������ �� ������ �Ǵ� ������ id�� ���� ��ü�� context�� ��䱸������ Context�� ��ȯ


    //    }
    //    catch(InvalidCastException)
    //    {
    //        Debug.LogError("Given type cannot cast context");
    //        return default(T);
    //    }


    //}

    public bool DeleteContext(string path)
    {
        var node = FindContextNode(path);
        var parent = node.Parent;
        return parent.RemoveChildContext(path);


    }

    public bool DisposeNode(string path, string id)
    {
        var node = FindContextNode(path);
       
        if(node == null)
        {
            return false;
        }
        else if (node.CheckId(id))
        {
            node.DisposeID();
            return true;
        }
        return false;

    }


    public GameLogicContextNode FindContextNode(string path)
    {
        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        Queue<string> queue = new Queue<string>();
        string[] keywords = path.Split(pathSeperator);
        foreach (var keyword in keywords)
        {
            queue.Enqueue(keyword);
        }
        GameLogicContextNode node = FindNodeFromRoot(queue, pathSeperator, root, string.Empty);

        return node;
    }

    public GameLogicContextNode FindContextElementNode(string path, int index)
    {
        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        string elementPath = GetElementPath(path, index);
        GameLogicContextNode node = FindContextNode(elementPath); //FindNodeFromRoot(elementPath.ToString(), pathSeperator, root, string.Empty);
        return node;
    }


    private GameLogicContextNode FindNodeFromRoot(Queue<string> queue, char seperator, GameLogicContextNode node, string path)
    {

        string substr = queue.Dequeue();
        StringBuilder currentPath = new StringBuilder(path);
        currentPath.Append(substr);


        string bindingPath = currentPath.ToString();


        GameLogicContextNode result = node.GetChildContext(bindingPath);



        if (queue.Count == 0)   //���̻� �и��� �� ������
        {
            if (result == null)
            {
                StringBuilder logMessage = new StringBuilder("Couldn't find any node at path: ");
                logMessage.Append(currentPath.ToString());
                Debug.Log(logMessage);
            }
            return result;
            //������ ��尡 ���� branch�� �����ϴ��� Ȯ���ؾ��� = parent�� childlist�� �ش� ��尡 �ִ��� Ȯ���ؾ���
        }

        if (result != null)
        {
            result = FindNodeFromRoot(queue, seperator, result, currentPath.Append(seperator).ToString());
        }
        else
        {
            StringBuilder logMessage = new StringBuilder("Node doesn't exist at path: ");
            logMessage.Append(currentPath.ToString());
            Debug.Log(logMessage);

        }

      


        return result;



    }

    

    //public GameLogicContextNode AddContextElementByIndex(string path, int index, bool isUnique = false)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    StringBuilder elementPath = new StringBuilder(path);
    //    elementPath.Append("[").Append(index.ToString()).Append("]");
    //    return AddContext(elementPath.ToString(), isUnique);
    //}

    //public ContextResult<T> AddContextElementByIndex<T>(string path, object context ,int index, bool isUnique = false)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    StringBuilder elementPath = new StringBuilder(path);
    //    elementPath.Append("[").Append(index.ToString()).Append("]");
    //    return AddContext<T>(elementPath.ToString(), context, isUnique);
    //}


    //public GameLogicContextNode AddContext(string path, bool isUnique = false)
    //{

    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    Queue<string> queue = new Queue<string>();
    //    string[] keywords = path.Split(pathSeperator);
    //    foreach (var keyword in keywords)
    //    {
    //        queue.Enqueue(keyword);
    //    }
    //    return AddNodeFromRoot(queue, root, pathSeperator, string.Empty, isUnique);

    //}

    private string GetElementPath(string originPath, int index)
    {
        StringBuilder p = new StringBuilder(originPath);
        p.Append("[").Append(index.ToString()).Append("]");
        string elementPath = p.ToString();
        return elementPath;
    }
    public ContextResult<T> AddNewContextElementByIndex<T>(string path, object context, int index, bool isUnique = false)
    {

        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        string p = GetElementPath(path, index);

        Queue<string> queue = new Queue<string>();
        string[] keywords = p.Split(pathSeperator);
        foreach (var keyword in keywords)
        {
            queue.Enqueue(keyword);
        }
        



        var node = AddNodeFromRoot(queue, context, root, pathSeperator, string.Empty, isUnique);
        if (node == null)
        {
            return null;
        }
        else
        {
            string hash = GetRandomHashId();
            node.Id = hash;
            var result = new ContextResult<T>(ContextState.CanUse, hash, (T)node.Context);
            return result;
        }



    }


    /// <summary>
    /// ���ο� Context�� �߰��Ѵ�. Context�� �ʱ�ȭ �� �� Context�� ����������� �̻� �б⸸ �����ϴ�.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="path"></param>
    /// <param name="context"></param>
    /// <param name="isUnique"></param>
    /// <returns></returns>
    public ContextResult<T> AddNewContext<T>(string path, object context, bool isUnique = false)
    {

        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        Queue<string> queue = new Queue<string>();
        string[] keywords = path.Split(pathSeperator);
        foreach (var keyword in keywords)
        {
            queue.Enqueue(keyword);
        }



        var node = AddNodeFromRoot(queue, context, root, pathSeperator, string.Empty, isUnique);
        if (node == null)
        {
            return null;
        }
        else
        {
            string hash = GetRandomHashId();
            node.Id = hash;
            var result = new ContextResult<T>(ContextState.CanUse, hash, (T)node.Context);
            return result;
        }
        
       

    }


    /// <summary>
    /// not used
    /// </summary>
    /// <param name="path"></param>
    /// <param name="context"></param>
    /// <param name="isUnique"></param>
    /// <returns></returns>
    public GameLogicContextNode UpdateContext(string path, object context, bool isUnique = false)
    {
        
        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        Queue<string> queue = new Queue<string>();
        string[] keywords = path.Split(pathSeperator);
        foreach (var keyword in keywords)
        {
            queue.Enqueue(keyword);
        }
        
        
        var node = AddNodeFromRoot(queue, context ,root, pathSeperator, string.Empty, isUnique);
        return node;

    }


    private GameLogicContextNode UpdateContextElement(string path, object context, int index ,bool isUnique = false)
    {

        if (string.IsNullOrEmpty(path))
        {
            return null;
        }

        string elementPath = GetElementPath(path, index);

        Queue<string> queue = new Queue<string>();
        string[] keywords = elementPath.Split(pathSeperator);
        foreach (var keyword in keywords)
        {
            queue.Enqueue(keyword);
        }


        var node = AddNodeFromRoot(queue, context, root, pathSeperator, string.Empty, isUnique);
        return node;

    }



    private GameLogicContextNode AddNodeFromRoot(Queue<string> queue, object context ,GameLogicContextNode node, char seperator, string path, bool isUnique)
    {


        if (queue.Count == 0)
        {
            return null;
        }


        string substr = queue.Dequeue();
        StringBuilder currentPath = new StringBuilder(path);
        currentPath.Append(substr);





        GameLogicContextNode nextnode = null;
        string bindingPath = currentPath.ToString();
        GameLogicContextNode childnode = node.GetChildContext(bindingPath);




        if (node.Haschildren() && childnode != null) //��尡 �̹� ������ ���
        {
            nextnode = childnode;
        }
        else //���� ��λ� ��尡 ���� ���
        {
            GameLogicContextNode newnode = new GameLogicContextNode(substr, currentPath.ToString(), node); //���带 �߰�
            //{
            //    Name = substr,
            //    value = null,
            //    bindingPath = currentPath.ToString()

            //};

            node.AddChildContext(bindingPath, newnode); //�θ� ����� ��ųʸ��� ���ε� ��θ� key�� ���ο� ��带 �߰��Ѵ�.(Tree�� Context �߰�)
            nodecount++;
            nextnode = newnode;
        }

        if (queue.Count == 0)   //���̻� �и��� �� ������, �� ������ ��� ����϶� ���޹��� context�� ����
        {

            if (nextnode.IsEmpty()) //���� ����������� context �߰� ����, ó�� �ʱ�ȭ�� context�� ��� ������ �ٲ� �� ����(Read-Only)
            {
                nextnode.Context = context;
            }
            //nextnode.Context = context; //������ context ���� ä������ �Ǵ� �̹� �����ϰ��ִ� ����� context�� ���� update��
            nextnode.IsUnique = isUnique;
            //���� id���� ��ȯ����
            //child�� value�� ������Ʈ, 
            //nextnode.Value = value; Context ���� value�� �����������ʰ� logic���� ������ �ֱ⶧���� ���̻� Value��� ������ ���������ʴ´�.
            return nextnode;
            //������ ��尡 ���� branch�� �����ϴ��� Ȯ���ؾ��� = parent�� childlist�� �ش� ��尡 �ִ��� Ȯ���ؾ���
        }

        nextnode = AddNodeFromRoot(queue, context ,nextnode, seperator, currentPath.Append(seperator).ToString(), isUnique);
        return nextnode;







    }



    //private GameLogicContextNode AddNodeFromRoot(Queue<string> queue, GameLogicContextNode node, char seperator, string path, bool isUnique)
    //{


    //    if (queue.Count == 0)
    //    {
    //        return null;
    //    }


    //    string substr = queue.Dequeue();
    //    StringBuilder currentPath = new StringBuilder(path);
    //    currentPath.Append(substr);





    //    GameLogicContextNode nextnode = null;
    //    string bindingPath = currentPath.ToString();
    //    GameLogicContextNode child = node.GetChildContext(bindingPath);
    //    if (node.Haschildren() && child != null) 
    //    {
    //        nextnode = child;
    //    }
    //    else //children�� ���ų� child == null�� ���(substr �̸��� child�� ���� ���)
    //    {
    //        GameLogicContextNode newnode = new GameLogicContextNode(substr, currentPath.ToString(), node); //���带 �߰�
    //        //{
    //        //    Name = substr,
    //        //    value = null,
    //        //    bindingPath = currentPath.ToString()

    //        //};

    //        node.AddChildContext(bindingPath, newnode); //�θ� ����� ��ųʸ��� ���ε� ��θ� key�� ���ο� ��带 �߰��Ѵ�.(Tree�� Context �߰�)
    //        nodecount++;
    //        nextnode = newnode;
    //    }

    //    if (queue.Count == 0)   //���̻� �и��� �� ������
    //    {


    //        nextnode.IsUnique = isUnique;
    //        //child�� value�� ������Ʈ, 
    //        //nextnode.Value = value; Context ���� value�� �����������ʰ� logic���� ������ �ֱ⶧���� ���̻� Value��� ������ ���������ʴ´�.
    //        return nextnode;
    //        //������ ��尡 ���� branch�� �����ϴ��� Ȯ���ؾ��� = parent�� childlist�� �ش� ��尡 �ִ��� Ȯ���ؾ���
    //    }

    //    nextnode = AddNodeFromRoot(queue, nextnode, seperator, currentPath.Append(seperator).ToString(), isUnique);
    //    return nextnode;







    //}
    #region Temp
    /// <summary>
    /// rootProperty�� �о Tree�� �ʱ�ȭ�Ѵ�.
    /// </summary>
    /// <param name="rootProperty"></param>



    //public void InitTree(SerializedProperty prop)
    //{
    //    if (prop.isArray)
    //    {
    //        foreach (SerializedProperty element in prop)
    //        {
    //            SerializedProperty category = element.FindPropertyRelative("category");
    //            string path = category.stringValue;

    //            this.AddNode(path, root, element);


    //        }
    //    }

    //}


    //public void DFS(GameLogicNode root)
    //{

    //    if (root.Haschildren())
    //    {
    //        foreach(var child in root.Children)
    //        {
    //            Debug.Log(child.BindingPath);
    //            DFS(child);
    //        }
    //    }
    //    else
    //    {
    //        return;
    //    }




    //}

    //public void RegisterLogicEvent<T>(Action<T> action, Logic<T> logic)
    //{
    //    //logic�� �˾Ƴ��ų� �ܺο��� logic�� ��������� - Node�� ã�Ƴ���. �׸��� Logic�� �����´�.

    //    //logic.onvalueChanged += action;

    //}


    //public Logic<T> TryGetLogicDataAndCreateInstance<T>(string path, T value) where T : class
    //{
    //    Logic<T> v = GetLogicDataValue<T>(path);
    //    if(v == null)
    //    {
    //        Logic<T> newlogic = new Logic<T>(value);
    //        RegisterGameLogic(path, newlogic);
    //        return newlogic;
    //    }
    //    return v;


    //}

    //public void DeleteNode(string path)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return;
    //    }

    //    Queue<string> queue = new Queue<string>();
    //    string[] keywords = path.Split(pathSeperator);
    //    string lastword = keywords[keywords.Length - 1];
    //    foreach (var keyword in keywords)
    //    {
    //        if(keyword != lastword)
    //            queue.Enqueue(keyword);
    //    }

    //    if(queue.Count == 0) //path�� ���� �ܾ�� �̷�������� ���
    //    {
    //        root.DeleteChild(lastword);
    //    }
    //    else
    //    {
    //        GameLogicNode parent = FindNodeFromRoot(queue, pathSeperator, root, string.Empty);
    //        parent.DeleteChild(lastword);
    //    }



    //}



    //public void SetNodeValue(string path, object value)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return;
    //    }

    //    GameLogicNode node = FindNode(path);
    //    if(node.Type == value.GetType())
    //    {
    //        FindNode(path).Value = value;
    //    }
    //    else
    //    {
    //        Debug.Log("Argument value type is different from origin data");
    //    }

    //}

    //public void SetElementNodeValue(string path, object value, int index)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return;
    //    }

    //    try
    //    {
    //        GameLogicNode node = FindArrayElementNode(path, index);
    //        if (node.Type == value.GetType())
    //        {
    //            node.Value = value;
    //        }
    //        else
    //        {
    //            Debug.Log("Argument value type is different from origin data");
    //        }

    //    }
    //    catch
    //    {
    //        Debug.LogError("Type cast error");

    //    }


    //}
    //public Logic<T> GetLogicDataValue<T>(string path) where T : class
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    Logic<T> v;
    //    try
    //    {
    //        var node = FindNode(path);
    //        if (node == null)
    //        {
    //            return null;
    //        }
    //        v = (Logic<T>)node.Value;
    //    }
    //    catch
    //    {
    //        Debug.LogError("Type cast error");
    //        return null;
    //    }
    //    return v;
    //}




    //public T GetDataValue<T>(string path) where T: class
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    T v;
    //    try
    //    {
    //        var node = FindNode(path);
    //        if(node == null)
    //        {
    //            return null;
    //        }
    //        v = (T)node.Value;
    //    }
    //    catch
    //    {
    //        Debug.LogError("Type cast error");
    //        return null;
    //    }
    //    return v;
    //}

    //public T GetElementLogicDataValue<T>(string path, int index) where T : class
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    T v;
    //    try
    //    {
    //        var node = FindArrayElementNode(path, index);
    //        if (node == null)
    //        {
    //            return null;
    //        }
    //        v = (T)node.Value;
    //    }
    //    catch
    //    {
    //        Debug.LogError("Type cast error");
    //        return null;
    //    }
    //    return v;
    //}

    //public GameLogicNode FindNode(string path)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    Queue<string> queue = new Queue<string>();
    //    string[] keywords = path.Split(pathSeperator);
    //    foreach (var keyword in keywords)
    //    {
    //        queue.Enqueue(keyword);
    //    }
    //    GameLogicNode node = FindNodeFromRoot(queue, pathSeperator, root, string.Empty);

    //    return node;
    //}

    //public GameLogicNode FindArrayElementNode(string path, int index)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return null;
    //    }

    //    StringBuilder elementPath = new StringBuilder(path);
    //    elementPath.Append("[").Append(index.ToString()).Append("]");
    //    GameLogicNode node = FindNode(elementPath.ToString()); //FindNodeFromRoot(elementPath.ToString(), pathSeperator, root, string.Empty);
    //    return node;
    //}


    //private GameLogicNode FindNodeFromRoot(Queue<string> queue, char seperator, GameLogicNode node, string path)
    //{

    //    string substr = queue.Dequeue();


    //    StringBuilder currentPath = new StringBuilder(path);
    //    currentPath.Append(substr);


    //    GameLogicNode result = node.FindChildNode(substr);



    //    if (queue.Count == 0)   //���̻� �и��� �� ������
    //    {
    //        if(result == null)
    //        {
    //            StringBuilder logMessage = new StringBuilder("Couldn't find any node at path: ");
    //            logMessage.Append(currentPath.ToString());
    //            Debug.Log(logMessage);
    //        }
    //        return result;
    //        //������ ��尡 ���� branch�� �����ϴ��� Ȯ���ؾ��� = parent�� childlist�� �ش� ��尡 �ִ��� Ȯ���ؾ���
    //    }

    //    if (result != null)
    //    {
    //        result = FindNodeFromRoot(queue, seperator, result, currentPath.Append(".").ToString());
    //    }
    //    else
    //    {
    //        StringBuilder logMessage = new StringBuilder("Node doesn't exist at path: ");
    //        logMessage.Append(currentPath.ToString());
    //        Debug.Log(logMessage);

    //    }

    //    //else
    //    //{
    //    //    FindNodeFromRoot(subpath, seperator, )
    //    //}



    //    return result;



    //}

    ////public void AddNode(string path, object value)
    ////{
    ////    AddNodeFromRoot(path, value, root, pathSeperator, string.Empty);
    ////}

    //public void RegisterGameLogicByElementIndex(string path, object value, int index)
    //{
    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return;
    //    }

    //    StringBuilder elementPath = new StringBuilder(path);
    //    elementPath.Append("[").Append(index.ToString()).Append("]");
    //    RegisterGameLogic(elementPath.ToString(),value);
    //}



    //public void RegisterGameLogic(string path, object value)
    //{

    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return;
    //    }

    //    Queue<string> queue = new Queue<string>();
    //    string[] keywords = path.Split(pathSeperator);
    //    foreach (var keyword in keywords)
    //    {
    //        queue.Enqueue(keyword);
    //    }
    //    AddNodeFromRoot(queue, value, root, pathSeperator, string.Empty);

    //}





    //private void AddNodeFromRoot(Queue<string> queue, object value, GameLogicNode node, char seperator, string path)
    //{


    //    if (queue.Count == 0)
    //    {
    //        return;
    //    }


    //    string substr = queue.Dequeue();


    //    StringBuilder currentPath = new StringBuilder(path);
    //    currentPath.Append(substr);





    //    GameLogicNode nextnode = null;
    //    GameLogicNode child = node.FindChildNode(substr);
    //    if (node.Haschildren() && child != null)
    //    {
    //        nextnode = child;
    //    }
    //    else //children�� ���ų� child == null�� ���(substr �̸��� child�� ���� ���)
    //    {
    //        GameLogicNode newnode = new GameLogicNode(substr, null, currentPath.ToString()); //���带 �߰�
    //        //{
    //        //    Name = substr,
    //        //    value = null,
    //        //    bindingPath = currentPath.ToString()

    //        //};

    //        node.AddChildren(newnode); //path�� �������������("") �ش� �̸��� ���� ��带 ã�� ���ϸ� �θ��� children���� �߰��Ѵ�.
    //        nodecount++;
    //        nextnode = newnode;
    //    }

    //    if (queue.Count == 0)   //���̻� �и��� �� ������
    //    {

    //        //child�� value�� ������Ʈ, 
    //        nextnode.Value = value;
    //        return;
    //        //������ ��尡 ���� branch�� �����ϴ��� Ȯ���ؾ��� = parent�� childlist�� �ش� ��尡 �ִ��� Ȯ���ؾ���
    //    }

    //    AddNodeFromRoot(queue, value, nextnode, seperator, currentPath.Append(".").ToString());








    //}







    //private void AddNodeFromRoot(string path, object value, GameLogicNode node, char seperator, string currentpath)
    //{


    //    if (string.IsNullOrEmpty(path))
    //    {
    //        return;
    //    }


    //    //ex: path = a/b/c ���࿡ path�� empty���?
    //    int pos = path.IndexOf(seperator);
    //    string substr;  //a
    //    string subpath; //b/c
    //    if (pos >= 0)
    //    {
    //        substr = path.Substring(0, pos);  //a
    //        subpath = path.Substring((pos + 1)); //b/c
    //    }
    //    else
    //    {
    //        substr = path; //c �״��
    //        subpath = path; //c �״��
    //    }




    //    StringBuilder currentPath = new StringBuilder(currentpath);
    //    currentPath.Append(substr);
    //    Debug.Log(currentPath.ToString());




    //    GameLogicNode nextnode = null;
    //    GameLogicNode child = node.FindChildNode(substr);
    //    if (node.Haschildren() && child != null)
    //    {
    //        nextnode = child;
    //    }
    //    else //children�� ���ų� child == null�� ���(substr �̸��� child�� ���� ���)
    //    {
    //        GameLogicNode newnode = new GameLogicNode() //���带 �߰�
    //        {
    //            Name = substr,
    //            value = null,
    //            bindingPath = currentPath.ToString()

    //        };

    //        node.AddChildren(newnode); //path�� �������������("") �ش� �̸��� ���� ��带 ã�� ���ϸ� �θ��� children���� �߰��Ѵ�.
    //        nodecount++;
    //        nextnode = newnode;
    //    }

    //    if (substr == subpath || string.IsNullOrEmpty(substr))   //���̻� �и��� �� ������
    //    {

    //        //child�� value�� ������Ʈ, 
    //        nextnode.value = value;



    //        return;
    //        //������ ��尡 ���� branch�� �����ϴ��� Ȯ���ؾ��� = parent�� childlist�� �ش� ��尡 �ִ��� Ȯ���ؾ���
    //    }

    //    AddNodeFromRoot(subpath, value, nextnode, seperator, currentPath.Append(".").ToString());








    //}
    #endregion
}
