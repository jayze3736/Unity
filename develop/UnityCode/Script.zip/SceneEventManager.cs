using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;

public class SceneEventManager : MonoBehaviour, ISceneLoadEvent
{
    public static SceneEventManager eventmanager = null;

    
    //public event Action<Scene, LoadSceneMode> EventHandler;

    //public event Action<Scene, LoadSceneMode> onSceneLoaded;

    public delegate void EventHandler();



    // Start is called before the first frame update
    void Start()
    {
        if(eventmanager == null)
        {
            eventmanager = this;
        }
        else if(eventmanager != this)
        {
            Destroy(this.gameObject);
        }
       
        DontDestroyOnLoad(this.gameObject);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //void OnSceneLoaded()
    //{
    //       GameMaster.gm.SpawnPlayer(GameMaster.gm.GetSpawnPoint().position);
    //       SceneManager.sceneLoaded -= delegate { OnSceneLoaded(); };
    //}



   
    public void LoadNextScene(bool isPlayerspawn = false, bool isadditive = false)
    {
        StartCoroutine(_LoadNextScene(isPlayerspawn, isadditive));
    }

    public IEnumerator _LoadNextScene(bool isPlayerspawn = false, bool isadditive = false)
    {

        if (isPlayerspawn) SceneManager.sceneLoaded += OnSceneLoaded;  // �Ű� ���� �����ϰ� �̺�Ʈ ����


                AsyncOperation op = 
        SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex + 1, isadditive ? LoadSceneMode.Additive : LoadSceneMode.Single);
        


        while (!op.isDone)
        {
            

            //Scene Load Progress
            yield return null;

        }
        // �̺�Ʈ - ���� �ε� �̺�Ʈ
        Debug.Log("test");


        // if (isPlayerspawn) SceneManager.sceneLoaded -= delegate { OnSceneLoaded(); };
        Debug.Log("next Scene Loaded");


    }

    public IEnumerator StartGame(string scenename)
    {
        AsyncOperation op = SceneManager.LoadSceneAsync(scenename);
        while (!op.isDone) { yield return null; }
        //OnGameStart(Savedata data)


    }




    void Delay()
    {
        StartCoroutine("_Delay");

    }

    IEnumerator _Delay()
    {
        yield return new WaitForEndOfFrame();

    }

    

    public void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        GameMaster.gm.SpawnPlayer(GameMaster.gm.GetSpawnPoint().position);
        SceneManager.sceneLoaded -= OnSceneLoaded;

    }

    //public override void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    //{

    //}
}
