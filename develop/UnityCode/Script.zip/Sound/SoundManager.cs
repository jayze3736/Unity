using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager soundmanager = null;
    AudioSource audio;

    [SerializeField]
    AudioClip [] audioclip;
    



    private void Awake()
    {
        audio = GetComponent<AudioSource>();
        
    }

    // Start is called before the first frame update
    void Start()
    {
        if(soundmanager == null)
        {
            soundmanager = this;
        }
        else if(soundmanager != this)
        {
            Destroy(this);
        }
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void ChangeSound(float volume)
    {
        if (volume <= 1 && volume >= 0)
            audio.volume = volume;
        else
            Debug.Log("volume value is not in range 0 to 1");

    }

    

    public void Play(string name)
    {
        foreach(AudioClip clip in audioclip)
        {
            //clip.name returns clip file name
            if(clip.name == name)
            {
                
                audio.clip = clip;
                audio.Play();

                return;
            }

        }

        return;


    }




}
