using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Quit : MonoBehaviour
{
    [SerializeField]
    Button yesbutton;

    [SerializeField]
    Button nobutton;


    // Start is called before the first frame update
    void Start()
    {
        yesbutton.onClick.AddListener(quit);
        nobutton.onClick.AddListener(cancel);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void quit()
    {
        Application.Quit();

    }

    void cancel()
    {
        MenuUIController.Hide(MenuUISender.sender.menu_quit);
    }
}
