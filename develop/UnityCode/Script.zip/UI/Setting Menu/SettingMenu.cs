using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingMenu : MonoBehaviour
{
    [SerializeField]
    Toggle isfullscreen;

    [SerializeField]
    Slider volumecontrolbar;

    private void Awake()
    {
        if(isfullscreen == null)
        isfullscreen = MenuUISender.sender.FindMenuChild(MenuUISender.sender.menu_setting, "board/Canvas/Togggle_Fullscreen")
            .GetComponent<Toggle>();

        if (volumecontrolbar == null)
            volumecontrolbar = MenuUISender.sender.FindMenuChild(MenuUISender.sender.menu_setting, "board/Canvas/volume_slider")
                .GetComponent<Slider>();

    }

    // Start is called before the first frame update
    void Start()
    {
        //SoundManager.soundmanager.Play("xDeviruchi - 01 Title Theme");
        isfullscreen.onValueChanged.AddListener(delegate { Togglefullscreen(); });
        volumecontrolbar.onValueChanged.AddListener(delegate { SoundManager.soundmanager.ChangeSound(volumecontrolbar.value); });


        
    }

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetKeyDown(KeyCode.E))
        //{
        //    SoundManager.soundmanager.Play("xDeviruchi - 02 And The Journey Begins!");
        //}
        
    }

    void Togglefullscreen()
    {
        if (isfullscreen.isOn)
        {
            Screen.fullScreenMode = FullScreenMode.ExclusiveFullScreen;
            Debug.Log("Full screen mode");
        }
        else
        {
            Screen.fullScreenMode = FullScreenMode.Windowed;
            Debug.Log("window screen mode");
        }
    }
}
