using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EM_OpenState : MonoBehaviour
{
    Animator anim;
    Transform parent;

    [Header("Path starts under menu_equipment")]
    [SerializeField]
    string Path_closeEquipmentMenu = "EquipmentMenu/ClosedState";

    [SerializeField]
    string Path_inventoryUI = "EquipmentMenu/OpenState/inventory_UI";

    [SerializeField]
    string Path_bookmarkbutton = "EquipmentMenu/OpenState/OpenInventoryButtonCanvas/bookmarkButton";

    [SerializeField]
    string path_exitmenubutton = "EquipmentMenu/OpenState/ExitButtonCanvas/ExitMenuButton";

    [Header("Path starts under inventoryUI")]
    [SerializeField]
    string Path_closeinventorybutton = "inventory/CloseInventoryButtonCanvas/CloseInventoryButton";




    private
    Transform InventoryUI;
    private
    Transform closedEquipmentMenu;    //equipmentMenu�� prefab���� ����Ǿ������ʾƵ� prefab���¿��� reference�� �ָ� �״�� �����ϴ��� Ȯ��
    private
    Button bookmarkButton;
    private
    Button closeinventoryButton;
    private
    Button exitmenuButton;
    


    public void Start()
    {
        Reference();
        Init();
        bookmarkButton.onClick.AddListener(OpenInventoryUI);
        closeinventoryButton.onClick.AddListener(CloseInventoryUI);
        exitmenuButton.onClick.AddListener(ExitMenu);

    }



    // Start is called before the first frame update


    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ExitMenu();
        }

    }



    void Init()
    {
        anim = InventoryUI.GetComponent<Animator>();
        anim.updateMode = AnimatorUpdateMode.UnscaledTime;
    }

    void Reference()
    {
        MenuUISender _sender = MenuUISender.sender;
        Transform menu_equipment = _sender.menu_equipment;

        if (closedEquipmentMenu == null)
        {
            closedEquipmentMenu = _sender.FindMenuChild(menu_equipment, Path_closeEquipmentMenu);
        }

        if (InventoryUI == null)
        {
            InventoryUI = _sender.FindMenuChild(menu_equipment, Path_inventoryUI);
        }

        if (bookmarkButton == null)
        {
            Transform _bookmarkbutton = _sender.FindMenuChild(menu_equipment, Path_bookmarkbutton);
            bookmarkButton = _bookmarkbutton.GetComponent<Button>();
            Debug.Log(bookmarkButton.name);
        }

        if (closeinventoryButton == null)
        {
            Transform closedbutton = _sender.FindMenuChild(InventoryUI, Path_closeinventorybutton);
            closeinventoryButton = closedbutton.GetComponent<Button>();

        }

        if(exitmenuButton == null)
        {
            Transform result = _sender.FindMenuChild(menu_equipment, path_exitmenubutton);
            exitmenuButton = result.GetComponent<Button>();
        }



    }


    public void OpenInventoryUI()
    {
        anim.SetBool("Hide", false);
    }

    public void CloseInventoryUI()
    {
        anim.SetBool("Hide", true);
    }

    public void ExitMenu()
    {
        closedEquipmentMenu.gameObject.SetActive(true);
        gameObject.SetActive(false);
    }
}

