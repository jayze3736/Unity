using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OpenedEquipmentMenu : MonoBehaviour
{
    //    Animator anim;
    //    Transform parent;

    //    [SerializeField]
    //    string Path_closeEquipmentMenu = "menu_equipment/Canvas/EquipmentMenu/EquipmentMenu_close";

    //    [SerializeField]
    //    string Path_inventoryUI = "menu_equipment/Canvas/EquipmentMenu/EquipmentMenu_open/inventory_UI";

    //    [SerializeField]
    //    string Path_bookmarkbutton = "menu_equipment/Canvas/EquipmentMenu/EquipmentMenu_open/ButtonCanvas/bookmarkButton";



    //    [SerializeField]
    //    Transform InventoryUI;

    //    [SerializeField]
    //    Transform closedEquipmentMenu;    //equipmentMenu�� prefab���� ����Ǿ������ʾƵ� prefab���¿��� reference�� �ָ� �״�� �����ϴ��� Ȯ��
    //    [SerializeField]
    //    Button bookmarkButton;



    //    public Button closeInventoryButton;

    //    public void Start()
    //    {
    //        Reference();
    //        Init();
    //        bookmarkButton.onClick.AddListener(OpenInventoryUI);
    //        closeInventoryButton.onClick.AddListener(CloseInventoryUI);


    //    }



    //    // Start is called before the first frame update


    //    // Update is called once per frame
    //    void Update()
    //    {

    //    }



    //    void Init()
    //    {
    //        anim = InventoryUI.GetComponent<Animator>();
    //        anim.updateMode = AnimatorUpdateMode.UnscaledTime;
    //    }

    //    void Reference()
    //    {
    //        MenuUISender _sender = MenuUISender.sender;
    //        Transform menu = _sender.transform;

    //        if (closedEquipmentMenu == null)
    //        {
    //            closedEquipmentMenu = _sender.SetMenuChild(menu, Path_closeEquipmentMenu);
    //        }

    //        if (InventoryUI == null)
    //        {
    //            InventoryUI = _sender.SetMenuChild(menu, Path_inventoryUI);
    //        }

    //        if (bookmarkButton == null)
    //        {
    //            Transform _bookmarkbutton = _sender.SetMenuChild(menu ,Path_bookmarkbutton);
    //            bookmarkButton = _bookmarkbutton.GetComponent<Button>();
    //            Debug.Log(bookmarkButton.name);
    //        }

    //        if (closeInventoryButton == null)
    //        {
    //            Transform closedbutton = _sender.SetMenuChild(InventoryUI, "inventory/ButtonCanvas/Button_exit");
    //            closeInventoryButton = closedbutton.GetComponent<Button>();

    //        }




    //    }


    //    public void OpenInventoryUI()
    //    {
    //        anim.SetBool("Hide", false);
    //    }

    //    public void CloseInventoryUI()
    //    {
    //        anim.SetBool("Hide", true);
    //    }
    //}
}