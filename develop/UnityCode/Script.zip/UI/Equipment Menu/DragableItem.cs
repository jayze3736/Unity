using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class DragableItem : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
{


    private Transform prevslot;
    private Camera cam;
    private Canvas rootCanvas; //for finding camera using by root canvas
    private RectTransform parentRectTrans;  //
    private Canvas parentCanvas;
    private Vector2 localpoint;
    private RectTransform thisRectTrans;
    
    private Transform curslot;
    private Transform nextslot;
    private ItemManager itemManager;
    

    [SerializeField]
    LayerMask slotLayermask;

    private bool ignoreOnetime = true;

    


    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    if(collision.GetComponent<InventorySlot>() != null)
    //    {
    //        nextslot = collision.transform;
            
    //    }


    //}

  


    void Awake()
    {
        rootCanvas = GetComponentInParent<Canvas>().rootCanvas;
        parentCanvas = GetComponentInParent<Canvas>();
        thisRectTrans = GetComponent<RectTransform>();
        
        
    }

    void Start()
    {
        parentRectTrans = parentCanvas.GetComponent<RectTransform>();
        RectTransform rootRectTrans = rootCanvas.GetComponent<RectTransform>();

        parentRectTrans.sizeDelta = new Vector2(rootRectTrans.rect.width, rootRectTrans.rect.height);   // initializing child canvas width and height
        cam = rootCanvas.worldCamera;

        curslot = transform.parent;
        nextslot = curslot;
        prevslot = null;

        itemManager = ItemManager.instance;

        if (parentRectTrans == null) Debug.LogError("reference missing");
        if (cam == null) Debug.LogError("cam missing");
    }

    //Onpointer down�� item�� �������� �����ϴ� �Լ�, eventData�� Ŭ��(�̺�Ʈ)�� �Ͼ���� �ش� �̺�Ʈ�� ���� ������ ����������
    public void OnPointerDown(PointerEventData eventData)
    {
        

        /* parentRectTrans ������ �߻��� ���콺 Ŭ�� �̺�Ʈ�� �����ϰ� Ŭ�� ��ǥ�� local������ ��ȯ�Ѵ�.
        * �̶� localpoint�� canvas �ٷ� �Ʒ� child object �������� localposition�� �����ϹǷ� grandchild�� �� ���� �״�� ������ �ȵǹǷ�
         ��� �ű涧�� canvas child�� �����ϴٰ�, �ű��Ŀ��� �ٽ� slot�� child�� ����ȴ�. */
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(parentRectTrans, eventData.position,
            (rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay) ? null : cam,
            out localpoint))
        {

            this.transform.SetParent(parentCanvas.transform);
           // ChangeShadowsAlpha(0.3f);
            
        }
    }

    //Onpointer up�� item�� �������� �����ϴ� �Լ�, after moving item
    public void OnPointerUp(PointerEventData eventData)
    {
        Debug.Log(nextslot.name + curslot.name + "is these two same");
       
        if(nextslot != curslot && itemManager.IsSlotEmpty(nextslot.gameObject))
        {
            Debug.Log("Pointer UP!");
            //find slot

            transform.SetParent(nextslot);
            transform.localPosition = Vector3.zero;
            curslot = nextslot;
            //Set parent -> Slot
        }
        else
        {
            this.transform.SetParent(curslot);
            this.transform.localPosition = Vector3.zero;
            //back to previous pos
        }

        ChangeShadowsAlpha(nextslot, 0f);
        ChangeShadowsAlpha(curslot, 0f);

    }

    //drag ���϶� ȣ��Ǵ� �Լ� 
    public void OnDrag(PointerEventData eventData)
    {
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(parentRectTrans, eventData.position, cam, out localpoint))
        {
            thisRectTrans.localPosition = localpoint;  
            Collider2D slot = Physics2D.OverlapPoint(transform.position, slotLayermask);  //�����ϰ� layermask ����
            

            if(slot != null)
            {
                
                if (slot.GetComponent<InventorySlot>() != null)
                {
                    nextslot = slot.transform;

                    if (prevslot != slot)    //�ٸ� slot���� Ŀ���� �̵��� ���, ���� slot�� alpha���� Ȯ���ϰ� 0���� set
                    {
                        ChangeShadowsAlpha(prevslot, 0f);
                    }
                    prevslot = slot.transform;
                    ChangeShadowsAlpha(slot.transform, 0.3f);

                }
                
            }
            else
            {
                Debug.Log("slot is null");
                ChangeShadowsAlpha(prevslot, 0f);
            }






        }
    }


    
    



    // Start is called before the first frame update


    // Update is called once per frame
    void Update()
    {
        //input e key
            //find empty slot - bool type
                // if it's true change scale relative to inventory slot size and set parent as the slot and make alpha of shadow 0
                    //if user moves item to other slot, make alpha 0.3 and make alpha 0 after moving item 




    }

    void ChangeShadowsAlpha(Transform _slot, float _alpha)
    {
        if(_slot != null)
        {
            Debug.Log("slot is not null");
            Transform shadow = _slot.transform.Find("inventoryslot_shadow");
            SpriteRenderer sp = shadow.GetComponent<SpriteRenderer>();
            Color _color = sp.color;
            sp.color = new Color(_color.r, _color.g, _color.b, _alpha);

        }
        

        //InventorySlot nextIVslot = nextslot.GetComponent<InventorySlot>();
        //SpriteRenderer nextSpriteRend = nextIVslot.spriteRend;

        //if(nextSpriteRend == null)
        //{
        //    Debug.LogError("null exception error");
        //}
        //Color color = nextSpriteRend.color;

        //nextSpriteRend.color = new Color(color.r, color.g, color.b, _a);

    }

}
