using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ClosedEquipmentMenu : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
    Animator anim;
    [SerializeField]
    Transform equipmentMenu;

    public void OnPointerUp(PointerEventData eventData)
    {
        anim.SetBool("Pressed", false);
        equipmentMenu.gameObject.SetActive(true);
        gameObject.SetActive(false);
        
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        anim.SetBool("Highlighted", true);
    }


    public void OnPointerExit(PointerEventData eventData)
    {
        anim.SetBool("Highlighted", false);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        anim.SetBool("Pressed", true);
    }

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        
    }

    // Update is called once per frame
    void Update()
    {

    }

  
    


}
