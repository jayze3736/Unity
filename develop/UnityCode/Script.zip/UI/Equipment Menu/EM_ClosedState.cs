using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class EM_ClosedState : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
    Animator anim;
    [SerializeField]
    Transform OpenState;
    private Transform menu_equipment;

    public void OnPointerUp(PointerEventData eventData)
    {
        anim.SetBool("Pressed", false);
        OpenState.gameObject.SetActive(true);
        gameObject.SetActive(false);

    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        anim.SetBool("Highlighted", true);
    }


    public void OnPointerExit(PointerEventData eventData)
    {
        anim.SetBool("Highlighted", false);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        anim.SetBool("Pressed", true);
    }

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        menu_equipment = MenuUISender.sender.menu_equipment;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ResumeGame();
            menu_equipment.gameObject.SetActive(false);

            
        }
    }


    void ResumeGame()
    {
        Time.timeScale = 1;
    }


}
