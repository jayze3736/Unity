using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MoveableUI : MonoBehaviour, IDragHandler, IPointerDownHandler, IPointerUpHandler
{
    Vector2 offset;
    Canvas parentCanvas;
    RectTransform parentRect;
    RectTransform thisRect;
    Transform parent;
    Vector2 localpoint;
    Camera cam;

    public void OnPointerDown(PointerEventData eventData)
    {
        transform.SetParent(parentCanvas.transform);
        
        if(RectTransformUtility.ScreenPointToLocalPointInRectangle(parentRect, eventData.position, cam, out localpoint))
        {
            //��õ��� parent canvas�� child�� �ǹǷ� localposition���� parent child�� relative�� ���� �ǰ�
            //localpoint�� ���� parentCanvas�� rect�� ���� pos���̹Ƿ� ���� ���ؿ��� ���� ����� �����ϴ�.
            offset = localpoint - (Vector2)transform.localPosition;
        }
        
        
    }


    public void OnDrag(PointerEventData eventData)
    {
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(parentRect, eventData.position, cam,out localpoint))
        {
            //Vector2 rectOffset;
            //RectTransformUtility.ScreenPointToLocalPointInRectangle(parentRect, offset, cam, out rectOffset);
            thisRect.localPosition = localpoint - offset;
        }


    }

    public void OnPointerUp(PointerEventData eventData)
    {
        transform.SetParent(parent);

    }


    // Start is called before the first frame update
    void Start()
    {
        parentCanvas = GetComponentInParent<Canvas>();
        if(parentCanvas != null)
        {
            parentRect = parentCanvas.GetComponent<RectTransform>();
        }
        
        cam = parentCanvas.rootCanvas.worldCamera;
        parent = transform.parent;
        thisRect = GetComponent<RectTransform>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
