using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class STMBarModule : MonoBehaviour
{

    [SerializeField]
    float shakemagnitude;

    [SerializeField]
    float shakeduration;

   
    

    // Start is called before the first frame update
    void Start()
    {
        Player.GetPlayerStatus().NotEnoughStaminaUsed += OnCantUseStamina; //Dependency
        
    }

    // Update is called once per frame
    public void Update()
    {
        
        
    }

    public void OnCantUseStamina()
    {
        AnimationUtils utils = new AnimationUtils();

        //utils.Shake(STM,shakemagnitude,shakeduration);
        StartCoroutine(utils.Shake(transform, shakemagnitude, shakeduration));
    }
}
