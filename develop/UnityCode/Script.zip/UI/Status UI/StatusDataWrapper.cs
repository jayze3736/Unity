using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StatusDataWrapper<T>
{
    

    object _value;
    public T Value { 
        get { return (T)_value; }
        set { _value = value; }
    }

    public Action<T> onValueChanged;

    public StatusDataWrapper(object value)
    {
        _value = value;
    }
    public StatusDataWrapper() { 
    
    }

    public void OnValueChange(T value)
    {
        var handler = onValueChanged;
        if(handler != null)
        {
            handler(value);
        }
    }


}
