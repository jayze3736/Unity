using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStatusUIManager : MonoBehaviour
{

    [SerializeField]
    HPBar hpbar;

    [SerializeField]
    StaminaBar STMbar;


    void Create()
    {
        Instantiate(hpbar, transform);
        Instantiate(STMbar, transform);

    }



    // Start is called before the first frame update
    void Start()
    {
        //GameMaster.gm.playerRespawned += Create;



    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
