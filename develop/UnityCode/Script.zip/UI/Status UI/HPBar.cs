using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HPBar : MonoBehaviour
{
    [SerializeField]
    GameObject element;

    [Header("default value is 244f, 155f, 0f")]
    [SerializeField]
    Vector2 spawnPos;

    [Header("default value is 146f")]
    [SerializeField]
    float distanceX;


    [Header("Object Shake Effect Parameter")]
    [SerializeField]
    float shake_magnitude;

    [SerializeField]
    float shake_duration;



    Vector3 _cachedStartpos = new Vector3(244f, 155f, 0f);
    float _cachedDistanceX = 146f;
    


    List<HPBarElement> hpBar = new List<HPBarElement>();

    public int LastIndex { get { return hpBar.Count - 1; } }    
    int index;

    private void Awake()
    {
        
    }

    private void Start()
    {
        CreateHPBar(Player.GetPlayerStatus());
        //��ü ������
        RegisterEvent();
        



    }

    public void RegisterEvent()
    {
        Player.GetPlayerStatus().PlayerDamaged += OnDamagePlayer; //Dependency
        Player.GetPlayerStatus().PlayerHealed += OnHealPlayer; //Dependency
        Player.GetPlayerStatus().MaxHPIncreased += OnMaxHPIncreased;
        Player.GetPlayerStatus().MaxHPDecreased += OnMaxHPDecreased;
        GameMaster.gm.playerRespawned += ResetHPBar; //Dependency
    }

    public void RemoveEvent()
    {

        Player.GetPlayerStatus().PlayerDamaged -= OnDamagePlayer; //Dependency
        Player.GetPlayerStatus().PlayerHealed -= OnHealPlayer; //Dependency
        Player.GetPlayerStatus().MaxHPIncreased -= OnMaxHPIncreased;
        Player.GetPlayerStatus().MaxHPDecreased -= OnMaxHPDecreased;
        GameMaster.gm.playerRespawned -= ResetHPBar; //Dependency
    }

   
    

    
    void AddEmptyHPBarElement(int count)
    {
        Vector2 spawnPos = this.spawnPos;

        for (int i = 0; i < count; i++)
        {
            HPBarElement e = Instantiate(element, this.transform).GetComponent<HPBarElement>();
            if (!ReferenceEquals(e, null))
            {
                e.SetRectTrans(spawnPos);
                e.ChangeState(HPBarElement.State.EMPTY);
                hpBar.Add(e);
            }
            spawnPos.x += distanceX;
        }
        this.spawnPos = spawnPos;
    }

    void AddHPBarElement(int count)
    {
        Vector2 spawnPos = this.spawnPos;

        for (int i = 0; i < count; i++)
        {
            HPBarElement e = Instantiate(element, this.transform).GetComponent<HPBarElement>();
            if (!ReferenceEquals(e, null))
            {
                e.SetRectTrans(spawnPos);
                hpBar.Add(e);
            }
            spawnPos.x += distanceX;
        }
        this.spawnPos = spawnPos;
    }

    void RemoveHPBarElement(int count)
    {
        Vector2 spawnPos = this.spawnPos;
        int lastindex = LastIndex;
        for (int i = 0; i < count; i++)
        {
            //hpbar�� gameobject�� ����, ���� hpbar���� ���� �������� Destroy�� Destroy�ϰ� hpbar���� �����ϸ� ���� �ٸ���
            GameObject obj = hpBar[lastindex].gameObject;
            hpBar.RemoveAt(lastindex);
            Destroy(obj);
            lastindex--;
            spawnPos.x -= distanceX;
        }
        this.spawnPos = spawnPos;
       
    }

    /// <summary>
    /// Player�� ������Ǿ����� ȣ���� �Լ�
    /// </summary>
    void ResetHPBar(PlayerStatus status)
    {
        
        RemoveEvent();

        CreateHPBar(status);

        RegisterEvent();
        
    }

   



    void DestroyHPBar()
    {
        
        int count = hpBar.Count;
        RemoveHPBarElement(count);
    }

   


    public void OnDamagePlayer(float damage)
    {

        OnDecreaseHP(damage);

        AnimationUtils utils = new AnimationUtils();
        StartCoroutine(utils.Shake(transform, shake_magnitude, shake_duration));

    }

    public void OnHealPlayer(float heal)
    {
        OnIncreaseHP(heal);
        Debug.Log("Heal");
    }




    public void OnDecreaseHP(float damage)
    {

        if (damage < 0)
        {
            Debug.LogError("Damage must be postive value");
            return;
        }

        int times = (int)(damage / 0.5f);

        for (int i = 0; i < times; i++)
        {
            //���� ���� HP ĭ�� ���°� ���̻� HP�� ���� �� ���� ��� index�� ��ĭ �ű�
            if (!hpBar[index].DecreaseHP())
            {

                if (index <= 0)
                {
                    Debug.Log("Dead");

                    return;
                }
                --index;
                //���� index ��ġ�� element�� ���Ͽ� HP�� ����
                //hpBar[index].DecreaseHP();
            }
        }


    }

    public void OnIncreaseHP(float heal)
    {
        
        if (heal < 0)
        {
            Debug.LogError("Heal must be postive value");
            return;
        }

        int times = (int)(heal / 0.5f);
        for (int i = 0; i < times; i++)
        {

            //���� ���� HP ĭ�� ���°� ���̻� HP�� �ø� �� ���� ��� index�� ��ĭ �ű�
            if (!hpBar[index].IncreaseHP())
            {

                if (index >= LastIndex)
                {
                    Debug.Log("Full health");
                    return;
                }

                ++index;
                //���� index ��ġ�� element�� ���Ͽ� HP�� �ø�
                hpBar[index].IncreaseHP();
            }
        }
    }


    public void OnMaxHPIncreased(int up)
    {
        AddEmptyHPBarElement(up);
        OnIncreaseHP(up);
    }

    public void OnMaxHPDecreased(int down)
    {
        if (!IsExistEmptyHPBarElement(index))
        {
            OnDecreaseHP(down);
        }
        RemoveHPBarElement(down);
    }


    public void OnDecreaseHP()
    {


        //���� ���� HP ĭ�� ���°� ���̻� HP�� ���� �� ���� ��� index�� ��ĭ �ű�
        if (!hpBar[index].DecreaseHP())
        {

            if (index <= 0)
            {
                Debug.Log("Dead");

                return;
            }
            --index;
            //���� index ��ġ�� element�� ���Ͽ� HP�� ����
            hpBar[index].DecreaseHP();
        }
        AnimationUtils utils = new AnimationUtils();
        StartCoroutine(utils.Shake(transform, shake_magnitude, shake_duration));

    }

    public void OnIncreaseHP()
    {
        //���� ���� HP ĭ�� ���°� ���̻� HP�� �ø� �� ���� ��� index�� ��ĭ �ű�
        if (!hpBar[index].IncreaseHP())
        {

            if (index >= LastIndex)
            {
                Debug.Log("Full health");
                return;
            }

            ++index;
            //���� index ��ġ�� element�� ���Ͽ� HP�� �ø�
            hpBar[index].IncreaseHP();
        }
    }

    /// <summary>
    /// �� HP ĭ(1ĭ not ��ĭ)�� �ִ��� Ȯ��
    /// </summary>
    /// <param name="index"></param>
    /// <returns></returns>
    public bool IsExistEmptyHPBarElement(int index)
    {

        if(index == LastIndex)
        {
            //�ڱ� �ڽ��� �������� ��ġ�Ұ�� �ڽ��� EMPTY�̸� true
            if (hpBar[index].CurState == HPBarElement.State.EMPTY)
            {
                return true;
            }
            
            
        }
        else
        {
            // �ڱ� �ڽ��� �������� �ƴѵ�, �տ� ��ġ�� ĭ�� EMTPY�� ��� true
            if (hpBar[index + 1].CurState == HPBarElement.State.EMPTY)
            {
                return true;
            }
            
        }

        return false;


       
    }

    /// <summary>
    /// HP bar�� �����Ѵ�. �ʱ�ȭ �۾�
    /// </summary>
    /// <param name="status"></param>
    void CreateHPBar(PlayerStatus status)
    {
        int count = status.MaxHP; //Dependency
        float hp = status.HP;
        DestroyHPBar();
        AddEmptyHPBarElement(count);
        index = 0;
        OnIncreaseHP(hp);

    }

    /// <summary>
    /// Max HP�� ����Ǿ����� ȣ���� �ݹ� �Լ�
    /// </summary>
    private void OnMaxHPChanged(int change)
    {
        //int newHpBarElementCount = change;
        //int elementCount =  newHpBarElementCount - HpBarElementCount; 
        int newElementCount = change;
        if (newElementCount == 0)
        {
            return;
        }
       
        //Hp bar element �߰�
        if(newElementCount > 0)
        {
            //for(int i = 0; i < elementCount; i++)
            //{

            //    //����ִ� ������ HP bar element�� �ϳ�����
            //    HPBarElement e = Instantiate(element, this.transform).GetComponent<HPBarElement>();
            //    e.curState = HPBarElement.State.EMPTY;
            //    hpBar.Add(e);
            //}

            AddEmptyHPBarElement(newElementCount);
           
        }

        //Hp bar element ����
        if(newElementCount < 0)
        {
            //int lastindex = hpBar.Count - 1; 
            //for (int i = 0; i < Mathf.Abs(elementCount); i++)
            //{



            //    //hpbar�� gameobject�� ����, ���� hpbar���� ���� �������� Destroy�� Destroy�ϰ� hpbar���� �����ϸ� ���� �ٸ���
            //    GameObject obj = hpBar[lastindex].gameObject;
            //    hpBar.RemoveAt(lastindex);
            //    Destroy(obj);
            //    lastindex--;

            //}
            int count = -newElementCount;
            RemoveHPBarElement(count);
        }

        

    }



    /// <summary>
    /// HP�� ����Ǿ����� ȣ���� �ݹ��Լ�, View Update
    /// </summary>
    /// <param name="hp"></param>
    /// <param name="unit_hp"></param>
    private void OnHPChanged(float hp)
    {
        
        int num_fullState = (int)hp; //full state�� element ���� = hp�� ���� �κ�
        float mod = hp - num_fullState; //������
        int index;

        if(num_fullState > hpBar.Count)
        {
            num_fullState = hpBar.Count;
        }


        for(index = 0; index < num_fullState; index++)
        {
            hpBar[index].ChangeState(HPBarElement.State.FULL);
        }

        index = num_fullState;

        if(mod >= 0.5f && mod < 1.0f)
        {
            hpBar[index].ChangeState(HPBarElement.State.HALF);
            index++;
        }

        

        for(;index < hpBar.Count; index++)
        {
            hpBar[index].ChangeState(HPBarElement.State.EMPTY);
        }




    }


}
