using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// HP ���� ������ ��Ÿ���� ���� ������Ʈ 
/// </summary>
public class HPBarElement : MonoBehaviour
{
    public enum State
    {
        FULL, HALF, EMPTY
    }

    State curState;

    public State CurState { get { return curState; } }


    Image src;

    [SerializeField]
    Sprite fullState;

    [SerializeField]
    Sprite halfState;

    [SerializeField]
    Sprite emptyState;

    RectTransform rect;

    private void Awake()
    {
        if ((object)fullState == null)
        {
            Debug.LogError("'fullState' is missing");
        }

        if ((object)halfState == null)
        {
            Debug.LogError("'halfState' is missing");
        }


        if ((object)emptyState == null)
        {
            Debug.LogError("'emptyState' is missing");
        }

        src = GetComponent<Image>();
        rect = GetComponent<RectTransform>();

        src.sprite = emptyState;
        curState = State.EMPTY;

    }

   


    private void Start()
    {

        

    }

    public void ChangeState(State state)
    {

        if(state == State.FULL)
        {
            src.sprite = fullState;
        }
        else if(state == State.HALF)
        {
            src.sprite = halfState;
        }
        else if(state == State.EMPTY)
        {
            src.sprite = emptyState;
        }
        else
        {
            return;
        }
        curState = state;

    }

    public bool DecreaseHP()
    {
        curState++;
        ChangeState(curState);

        if (curState == State.EMPTY)
        {
            return false;
        }
        else
        {
            return true;
        }

        
        // ���̻� ���� �� ������ false�� ��ȯ
        //if (curState == State.EMPTY)
        //{
        //    return false;
        //}
        //else
        //{
        //    ++curState;
        //    ChangeState(curState);
        //    return true;
        //}
           
    }

    public bool IncreaseHP()
    {
       
        //���̻� �ø� �� ������ false�� ��ȯ
        if (curState == State.FULL)
        {
            return false;
        }
        else
        {
            --curState;
            ChangeState(curState);
            return true;
        }
       
    }

    public void SetRectTrans(Vector2 pos)
    {
        rect.anchoredPosition = pos;

    }



}
