using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UITest_anim : MonoBehaviour
{
    [SerializeField]
   Animator animator;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(2))
        {
            animator.SetBool("fold", true);
        }

        if (Input.GetMouseButtonDown(1))
        {
            animator.SetBool("fold", false);
        }

    }
}
