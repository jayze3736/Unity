using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class MenuUISender : MonoBehaviour
{
    public static MenuUISender sender = null;


    public Transform menu_playerinfo;
    public Transform menu_equipment;
    public Transform menu_quit;
    public Transform menu_saveload;
    public Transform menu_setting;

    



    // Start is called before the first frame update
    void Awake()
    {
       if(sender == null)
        {
            sender = this;
        }
        else if(sender != this)
        {
            Destroy(gameObject);
        }
        if(menu_playerinfo == null)
        {
            menu_playerinfo = GameObject.Find("menu_playerinfo").transform;
        }
        else if(menu_equipment == null)
        {
            menu_equipment = GameObject.Find("menu_equipment").transform;

        }
        else if (menu_quit == null)
        {
            menu_quit = GameObject.Find("menu_quit").transform;
        }
        else if(menu_saveload == null)
        {
           menu_saveload = GameObject.Find("menu_saveload").transform;
        }
        else if(menu_setting == null)
        {
           menu_setting = GameObject.Find("menu_setting").transform;
        }
        


    }

    private void Start()
    {
       



    }

    // Update is called once per frame
    void Update()
    {
        
    }


    
    

    public Transform FindMenuChild(Transform root , string searchPath)
    {

        Transform result = null;
        string[] substr = searchPath.Split('/');         //devide object path into object name and assign it
        string nextpath = "";

        
        //Process 1: make nextpath
        for(int i = 1; i < substr.Length; i++)
        {
            nextpath += substr[i];

            if(!(i == (substr.Length - 1))) //add '/' to right side of object name except last object name
                nextpath += '/';
            
            //nextpath has string except substr[0]
        }

        List<Transform> child = new List<Transform>();  //child saves root's children

        //Process 2: save children of root
        for(int i = 0; i < root.childCount; i++)
        {
            child.Add(root.GetChild(i));       //remember all child of root transform   
        }


        //Process 3: Checks if current process is under hierachy of target child's parent
        if (substr[0] == searchPath)    //when this is true, substr[0] is target object
        {
            
            for (int i = 0; i < child.Count; i++)   //find object that has target name
            {
                if (child[i].name == substr[0])
                {
                    
                    return child[i];    //return target
                }

            }

        }
       

        //Process 4: make recursive call from root to target's parent
        for (int i = 0; i < child.Count; i++)
        {
            if (child[i].name == substr[0])
            {
                bool isactive = child[i].gameObject.activeSelf; //remember state is whether active or inactive
                child[i].gameObject.SetActive(true);
                result = FindMenuChild(child[i], nextpath);
                child[i].gameObject.SetActive(isactive);
            }

        }

        
        return result;  // if target were not found then return null
        

        


        //ex) obj search history: A/B/C/D = Str
        //1. string [] substr = Str.Split("/");
        //2. getchild�� active�� ������� ���������� child�� ������ �� ����
    }


}
