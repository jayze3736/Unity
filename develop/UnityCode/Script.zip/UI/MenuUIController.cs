using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuUIController : MonoBehaviour
{
    public enum enumMenu
    {
        PLAYERINFO, EQUIPMENT, SAVELOAD, QUIT, SETTING

    };

    public enum enumButton {
        PLAYERINFO, EQUIPMENT, SAVELOAD, QUIT, SETTING, SPREAD, FOLD

    };




    private Transform[] menu = new Transform[System.Enum.GetValues(typeof(enumMenu)).Length];
    private Button[] buttons = new Button[System.Enum.GetValues(typeof(enumButton)).Length];


    private Transform menu_playerinfo;
    private Transform menu_equipment;
    private Transform menu_saveload;
    private Transform menu_quit;
    private Transform menu_setting;


    [SerializeField]
    Button button_playerinfo;

    [SerializeField]
    Button button_equipment;

    [SerializeField]
    Button button_setting;

    [SerializeField]
    Button button_saveload;

    [SerializeField]
    Button button_quit;

    [SerializeField]
    Button spreadbutton;

    [SerializeField]
    Button foldbutton;

    [SerializeField]
    Animator animator;


    private void Awake()
    {
        animator = GetComponent<Animator>();
        RefMenuInit();
        
    }

    // Start is called before the first frame update
    void Start()
    {
        if (animator == null || spreadbutton == null)
        {
            Debug.LogError("Reference missing");

        }

        spreadbutton.onClick.AddListener(SpreadMenu);
        foldbutton.onClick.AddListener(FoldMenu);
        button_equipment.onClick.AddListener(() => ShowEquipmentUI(menu[(int)enumMenu.EQUIPMENT]));
        button_setting.onClick.AddListener(() => Show(menu[(int)enumMenu.SETTING]));
        button_quit.onClick.AddListener(() => Show(menu[(int)enumMenu.QUIT]));
        button_saveload.onClick.AddListener(() => Show(menu[(int)enumMenu.SAVELOAD]));
        button_playerinfo.onClick.AddListener(() => Show(menu[(int)enumMenu.PLAYERINFO]));

        HideAllUI();

    }

    // Update is called once per frame
    void Update()
    {



    }

    void SpreadMenu()
    {
        animator.SetBool("spread", true);

    }

    void FoldMenu()
    {
        animator.SetBool("spread", false);
    }

    void PauseGame()
    {
        Time.timeScale = 0;
    }

    static void ResumeGame()
    {
        Time.timeScale = 1;
    }



    void Show(Transform UI)
    {
        UI.gameObject.SetActive(true);
        PauseGame();
    }

    public static void Hide(Transform UI)
    {
        UI.gameObject.SetActive(false);
        ResumeGame();
    }



    void ShowEquipmentUI(Transform UI)
    {

        UI.gameObject.SetActive(true);
        //InventoryUI ivUI = EquipmentMenu.GetComponentInChildren<InventoryUI>();
        ItemManager.instance.ViewItemOnUI();
        PauseGame();
    }

    void RefMenuInit()
    {
        MenuUISender menuSender = GameObject.Find("Root Canvas").transform.Find("menu").GetComponent<MenuUISender>();
        if (menuSender != null)
        {
            menu_equipment = menuSender.menu_equipment;
            menu_playerinfo = menuSender.menu_playerinfo;
            menu_quit = menuSender.menu_quit;
            menu_saveload = menuSender.menu_saveload;
            menu_setting = menuSender.menu_setting;
        }


        //menu_inventory = _menu.Find("menu_inventory");
        //menu_playerinfo = _menu.Find("menu_playerinfo");
        //menu_quit = _menu.Find("menu_quit");
        //menu_saveload = _menu.Find("menu_saveload");
        //menu_setting = _menu.Find("menu_setting");

        MergeMenuRefInAry();

    }

    void RefButtonInit()
    {
        if (!HasButtonRefYet())
        {

        }
        else
        {
            MergeButtonRefInAry();
        }
        
        

    }

    bool HasButtonRefYet()
    {
        for (int i = 0; i < System.Enum.GetValues(typeof(enumButton)).Length - 1 ; i++)
        {
            if (buttons[i] == null)
                return true;

        }
        return false;
    }

    void MergeMenuRefInAry()
    {
        menu[(int)enumMenu.PLAYERINFO] = menu_playerinfo;
        menu[(int)enumMenu.EQUIPMENT] = menu_equipment;
        menu[(int)enumMenu.QUIT] = menu_quit;
        menu[(int)enumMenu.SAVELOAD] = menu_saveload;
        menu[(int)enumMenu.SETTING] = menu_setting;



    }

    void MergeButtonRefInAry()
    {
        buttons[(int)enumButton.EQUIPMENT] = button_equipment;
        buttons[(int)enumButton.PLAYERINFO] = button_playerinfo;
        buttons[(int)enumButton.QUIT] = button_quit;
        buttons[(int)enumButton.SETTING] = button_setting;
        buttons[(int)enumButton.SAVELOAD] = button_saveload;
        buttons[(int)enumButton.SPREAD] = spreadbutton;
        buttons[(int)enumButton.FOLD] = foldbutton;

    }

    void HideAllUI()
    {
        for (int i = 0; i < System.Enum.GetValues(typeof(enumMenu)).Length; i++)
        {
            menu[i].gameObject.SetActive(false);
        }

    }

    void Init()
    {

    }
}
