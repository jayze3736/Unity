using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// Pointer�� Raycast ������ ������� Wrapper Ŭ����
/// </summary>
public class CustomInputModule : StandaloneInputModule
{
    private static CustomInputModule _instance;

    /// <summary>
    /// �������� PointerEventData�� ��ȯ
    /// </summary>
    /// <param name="pointerId"></param>
    /// <returns></returns>
    public static PointerEventData GetPointerEventData(int pointerId = -1)
    {
        PointerEventData eventData;
        _instance.GetPointerData(pointerId, out eventData, true);
        return eventData;
    }
    
    /// <summary>
    /// ���� ������� Raycaster�� ��ȯ
    /// </summary>
    /// <param name="pointerId"></param>
    /// <returns></returns>
    public static BaseRaycaster GetCurrentGraphicRaycaster(int pointerId = -1)
    {
        PointerEventData eventData;
        _instance.GetPointerData(pointerId, out eventData, true);
        return eventData.pointerCurrentRaycast.module;

    }

    

    protected override void Awake()
    {
        base.Awake();
        _instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
