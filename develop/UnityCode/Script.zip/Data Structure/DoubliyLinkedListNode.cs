using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoubliyLinkedListNode<T>
{

    private T value;
   
    public DoubliyLinkedListNode<T> next;
    public DoubliyLinkedListNode<T> prev;
    public T Value { get { return value; } }
    public DoubliyLinkedListNode()
    {
      
        next = null;
        prev = null;
    }

    public DoubliyLinkedListNode(T value)
    {
        this.value = value;
        
        next = null;
        prev = null;

    }

    
   

}
    
