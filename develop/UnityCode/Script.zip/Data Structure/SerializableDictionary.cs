using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SerializableDictionary<TKey, TValue>: Dictionary<TKey, TValue> , ISerializationCallbackReceiver
{
    [SerializeField]
    private List<TKey> keys;

    [SerializeField]
    private List<TValue> values;


    public void OnAfterDeserialize()
    {
        this.Clear();

        if(keys.Count != values.Count) {
            Debug.LogError("keys size and values size are not the same");
        }

        for(int i = 0; i < keys.Count; i++)
        {
            this.Add(keys[i], values[i]);
        }
       
      
    }


    /// <summary>
    /// ����ȭ�� �Ǳ����� value���� key���� ����Ʈ�� ����, Dictionary ��ü�δ� ����ȭ�� �Ұ����ϱ� �����̴�.
    /// </summary>
    /// <exception cref="System.NotImplementedException"></exception>
    public void OnBeforeSerialize()
    {
        keys.Clear();
        values.Clear();

        foreach(KeyValuePair<TKey, TValue> kvp in this)
        {
            keys.Add(kvp.Key);
            values.Add(kvp.Value);
        }
    }

    
}
