using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoublyLinkedList<T> : IEnumerable where T : class
{
    DoubliyLinkedListNode<T> head = null;
    DoubliyLinkedListNode<T> rear = null;
    private int count = 0;
    public int Count { get { return count; } }
    public DoubliyLinkedListNode<T> First { get { return head.next; } }
    public DoublyLinkedList()
    {
        head = new DoubliyLinkedListNode<T>();
        rear = new DoubliyLinkedListNode<T>();
        head.next = rear;
        rear.prev = head;
    }

    /// <summary>
    /// �ش� value�� ���� ���� first node�� ��ġ�� ��ȯ�Ѵ�.
    /// </summary>
    public void SwapFirst(T value)
    {
        DoubliyLinkedListNode<T> node = GetDoublyLinkedListNode(value);
       
        //������ node�� first�� �̿��Ұ��
        if (node.prev == head.next)
        {
            head.next.next = node.next;
            head.next.prev = node;
            node.next.prev = head.next;

            node.next = head.next;
            node.prev = head;
            //���� ���߿� head.next�� �ٲ���
            head.next = node;
           

        }
        else
        {
            // ���� ���� c4 -> c5 -> c2 -> c1 �λ�Ȳ���� c5�� ������ ��ġ��Ű�� ���
            DoubliyLinkedListNode<T> temp = head.next.next;

            head.next.next = node.next;
            head.next.prev = node.prev;
            node.prev.next = head.next;
            node.next.prev = head.next;

            head.next = node;
            node.prev = head;
            node.next = temp;
            temp.prev = node;

        }
        


    }

    /// <summary>
    /// value�� ���� ��带 �Ǿտ� ��ġ��Ű�� ��� ���� ���⿡ �ִ� ������ ����(next ����)���� ��ĭ�� �̵�
    /// </summary>
    public void JumpToFirst(T value)
    {
        DoubliyLinkedListNode<T> node = GetDoublyLinkedListNode(value);
        
        //���� first�� ��ġ�� ���
        if(node == head.next)
        {
            return;
        }
        else if(node.prev == head.next)
        {
            head.next.next = node.next;
            head.next.prev = node;
            node.next.prev = head.next;

            node.next = head.next;
            node.prev = head;
            //���� ���߿� head.next�� �ٲ���
            head.next = node;
        }
        else
        {
            node.next.prev = node.prev;
            node.prev.next = node.next;
            head.next.prev = node;
            node.prev = head;
            node.next = head.next;
            head.next = node;
        }

    }

    

    /// <summary>
    /// head �տ� value �߰�
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    /// <exception cref="System.Exception"></exception>
    public DoubliyLinkedListNode<T> AddFirst(T value)
    {
        //value�� null�� ��� ���� ó��
        if(value == null)
        {
            throw new System.Exception();
        }

        DoubliyLinkedListNode<T> node = new DoubliyLinkedListNode<T>(value);
        if(head.next == rear)
        {
           
            head.next = node;
            rear.prev = node;
            node.prev = head;
            node.next = rear;
        }
        else
        {
            node.next = head.next;
            head.next.prev = node;
            node.prev = head;
            head.next = node;
        }

        count++;
        return node;

    }

    /// <summary>
    /// head�� ����Ű�� �ִ� ������ ����
    /// </summary>
    public void RemoveFirst()
    {
        if(head != null)
        {
            
            //0���� ��Ȳ
            if (head.next == null)
            {
                return;
            }
            //1���� ��Ȳ
            else if(head.next.next == null)
            {
                head.next = null;
                --count;
                return;
            }
            //2�� �̻��� ��Ȳ
            else
            {
                head.next.next.prev = head;
                head.next = head.next.next;
                --count;

            }
            
            //�ƹ��͵� ���� ��� return
            //�Ѱ��ִ� ��� head.next = null
            //2���̻� �ִ� ��� head.next.next.prev = head, head.next = head.next.next 
        }
    }

    /// <summary>
    /// ��� ����Ʈ ��� ����
    /// </summary>
    public void RemoveAll()
    {
        head.next = rear;
        rear.prev = head;
    }

    /// <summary>
    /// Test
    /// </summary>
    /// <param name="index"></param>
    /// <returns></returns>
    public T GetNodeValueByIndex(int index)
    {
        int iteration;
        DoubliyLinkedListNode<T> node;

        if(index > (count - 1))
        {
            return null;
        }

        
        if (index <= (count / 2))
        {
            iteration = index;
            node = head.next;
            while (iteration != 0)
            {
                node = node.next;
                iteration--;

            }
        }
        else
        {
            iteration = count - (index + 1);
            node = rear.prev;
            while (iteration != 0)
            {
                node = node.prev;
                iteration--;

            }
        }

        return node.Value;
        
       


    }

   
    /// <summary>
    /// �ش� value�� List�� ���ԵǾ��ִ��� Ȯ��
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public bool Contains(T value)
    {
        DoubliyLinkedListNode<T> nextnode = head.next;
        while (nextnode != rear)
        {
            if (nextnode.Value == value)
                return true;

            nextnode = nextnode.next;
        }
        return false;
    }
    
    /// <summary>
    /// value���� ������ node�� ��ȯ
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    private DoubliyLinkedListNode<T> GetDoublyLinkedListNode(T value) 
    {
        DoubliyLinkedListNode<T> nextnode = head.next;
        while(nextnode != rear)
        {
            if (nextnode.Value == value)
                return nextnode;

            nextnode = nextnode.next;
        }
        return null;

    }

    public IEnumerator GetEnumerator()
    {
        DoubliyLinkedListNode<T> node = head.next;
        while(node != rear)
        {
            yield return node.Value;
            node = node.next;
        }

    }
}
