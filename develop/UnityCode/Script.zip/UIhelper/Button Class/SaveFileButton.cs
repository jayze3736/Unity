using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveFileButton : PointableButton
{
    public override bool canHaveChildren { get => true; }

    public override bool canGetNextparagraph { get => true; }

    public override KeyCode inputMovenext => KeyCode.DownArrow;

    public override KeyCode inputMoveprev => KeyCode.UpArrow;

    public float period = 1f;
    public float frameRate = 60.0f;
    public float targetalpha = 0.5f;



    public override void SetDefaultState()
    {
        StopBlink();
    }

    public override void SetGuideState()
    {
        Blink(period, frameRate, targetalpha, true);
    }

    // Start is called before the first frame update
    void Start()
    {
       
        Button.onClick.AddListener(RaiseEvent);
        SetButtonColorTintTransition(Color.white, Color.red, 0.1f);
    }

    // Update is called once per frame
    void Update()
    {

    }
}
