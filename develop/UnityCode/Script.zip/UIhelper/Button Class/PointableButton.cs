using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
[RequireComponent(typeof(Button))]
public abstract class PointableButton : HelperPointable
{


    #region Fields
    //����
    private Button button;
    private Image img;
    private TextMeshProUGUI [] childtexts;
    #endregion

    #region Property
    public Button Button { get { return button; } }
    public TextMeshProUGUI[] ChildTexts { get { return childtexts; } }
    
   
    #endregion



    /// <summary>
    /// Color Tint�� Transition�� ����
    /// </summary>
    /// <param name="defaultColor"> �⺻ ������ ��ư ��</param>
    /// <param name="pressedColor"> �������� ��ư ��</param>
    /// <param name="fadeDuration"> transition�� �����Ǵ� �ð�</param>
    protected void SetButtonColorTintTransition(Color defaultColor, Color pressedColor, float fadeDuration)
    {
        ColorBlock cb = button.colors;
        button.transition = Selectable.Transition.ColorTint;
        cb.normalColor = defaultColor;
        cb.pressedColor = pressedColor;
        cb.fadeDuration = fadeDuration;

        // set all not used Color transition to white
        cb.highlightedColor = Color.white;
        cb.disabledColor = Color.white;
        cb.selectedColor = Color.white;
        button.colors = cb;

    }

    protected void SetButtonAnimationTransition(string assetControllerpath)
    {
        
        button.transition = Selectable.Transition.Animation;
        if(this.transform.GetComponent<Animator>() == null)
        {
            Animator ani = this.gameObject.AddComponent<Animator>();
            // Find Asset by assetControllerpath
            // ani.runtimeAnimatorController = FindAss;
        }

        


    }

    /// <summary>
    /// ��ư�� �����̴� ȿ�� Ȱ��ȭ
    /// </summary>
    /// <param name="period">��ư�� �����̴� �ֱ�</param>
    /// <param name="frameRate">ȿ���� �������� ������ ��</param>
    /// <param name="targetAlpha">��ǥ ���İ�</param>
    protected void Blink(float period, float frameRate, float targetAlpha, bool istextblink)
    {
        StartCoroutine(BlinkEffect(period, frameRate, targetAlpha, istextblink));
    }

    /// <summary>
    /// ��ư�� �����̴� ȿ�� ��Ȱ��ȭ, �̶� StopAllCoroutines()�� ȣ��ǹǷ� ��� �ڷ�ƾ�� �����.
    /// </summary>
    protected void StopBlink()
    {
        StopAllCoroutines();

        //set back to origin alpha
        Color color = img.color;
        color.a = 1.0f;
        img.color = color;
        foreach (TextMeshProUGUI text in childtexts)
        {
            float alpha = color.a;
            Color c = text.color;
            c.a = 1.0f;
            text.color = c;
        }

    }

    /// <summary>
    /// ��ư�� �����̴� ȿ��
    /// </summary>
    /// <param name="period">��ư�� �����̴� �ֱ�</param>
    /// <param name="frameRate">ȿ���� �������� ������ ��</param>
    /// <param name="targetAlpha">��ǥ ���İ�</param>
    /// <param name="istextblink">button�� text�� ���������� ����</param>
    /// <returns></returns>
    private IEnumerator BlinkEffect(float period ,float frameRate, float targetAlpha, bool istextblink)
    {
        if(targetAlpha < 0.0f && targetAlpha > 1.0f)
        {
            Debug.LogError("targetAlpha must have value between 0 and 1");
            throw new System.Exception();
        
        }
        Color color = img.color;
        float fps = period / frameRate;
        float Maxalpha = 1.0f;
        color.a = Maxalpha;
        

        for (int i = 0; i < frameRate * 2.0f; i++)
        {
            float a = color.a;
            if (i < frameRate)
            {
                a -= ((Maxalpha - targetAlpha) / frameRate);
            }
            else
            {
                a += ((Maxalpha - targetAlpha) / frameRate);
            }

            color.a = Mathf.Clamp(a, 0.0f, 1.0f);

            img.color = color;
            if (istextblink)
            {
                foreach (TextMeshProUGUI text in childtexts)
                {
                    float alpha = color.a;
                    Color c = text.color;
                    c.a = alpha;
                    text.color = c;
                }
            }
            
            yield return new WaitForSeconds(fps / 2.0f);
        }

       
        StartCoroutine(BlinkEffect(period, frameRate, targetAlpha, istextblink));
    }


    /// <summary>
    /// ��ư�� �������� 
    /// </summary>
   

    public override void RaiseEvent()
    {
       
        UIhelper.helper.UIhelperMoveTo(this);

        if (this.canGetNextparagraph)
        {
            UIhelper.helper.UIhelperShowNextParagraph();
        }
    }

   
    public override void OnCloseParagraph()
    {
        button.interactable = false;
    }
    public override void OnOpenParagraph()
    {
        button.interactable = true;
    }


    private void Awake()
    {
        button = GetComponent<Button>();
        img = GetComponent<Image>();
        childtexts = GetComponentsInChildren<TextMeshProUGUI>();
        button.interactable = false;

    }

    

}
