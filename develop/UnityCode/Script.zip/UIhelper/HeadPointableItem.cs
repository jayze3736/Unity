using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeadPointableItem : IHelperPointable
{
    public bool canHaveChildren => throw new System.NotImplementedException();

    public bool canGetNextparagraph => throw new System.NotImplementedException();

    public KeyCode inputMovenext => throw new System.NotImplementedException();

    public KeyCode inputMoveprev => throw new System.NotImplementedException();

    public IHelperPointable Parent { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }

    

    public Transform GetTransform()
    {
        throw new System.NotImplementedException();
    }

    public bool IsActive()
    {
        throw new System.NotImplementedException();
    }

    public void OnCloseParagraph()
    {
        throw new System.NotImplementedException();
    }

    public void OnOpenParagraph()
    {
        throw new System.NotImplementedException();
    }

    public void RaiseEvent()
    {
        throw new System.NotImplementedException();
    }

    public void SetDefaultState()
    {
        throw new System.NotImplementedException();
    }

    public void SetGuideState()
    {
        throw new System.NotImplementedException();
    }
}
