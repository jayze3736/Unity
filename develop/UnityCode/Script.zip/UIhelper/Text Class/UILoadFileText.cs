using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UILoadFileText : PointableText
{
    #region Field
    public GameProgressContainer container;

    #region Inherited


    protected override Color defaultTextColor => Color.black;

    protected override Color guideTextColor => Color.red;

    public override bool canHaveChildren => throw new System.NotImplementedException();

    public override bool canGetNextparagraph { get => false; }
    public override KeyCode inputMovenext { get => KeyCode.RightArrow; }
    public override KeyCode inputMoveprev { get => KeyCode.LeftArrow; }

    public override InputButtonFlags Inputbuttonflags { get => InputButtonFlags.Left; }

    //public override Text Text => throw new System.NotImplementedException();



    #endregion

    #region Defined
    Button button;
    #endregion

    #endregion

    public override void SetGuideState()
    {
        //�ڽ��� �θ� button�� ���콺 �Է��� ��������
        button.interactable = false;
        base.SetGuideState();
    }

    public override void SetDefaultState()
    {
        //UI helper�� �ٸ� ���������� �̵��Ұ�� ���콺 �Է��� �޵��� ����

        base.SetDefaultState();
        button.interactable = true;

    }

    // Start is called before the first frame update
    void Start()
    {

        button = transform.parent.GetComponent<Button>();
        container = transform.parent.GetComponent<GameProgressContainer>();
        if (button == null)
        {
            Debug.LogError("text has no button");
        }
        if (container != null)
        {
            events.AddListener(container.Load);
        }

    }

    // Update is called once per frame
    void Update()
    {

    }

}
