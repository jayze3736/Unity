using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;



public class UINormalText : PointableText
{
    [SerializeField]
    bool CanReceiveNextparagraph = false;

    protected override Color defaultTextColor { get { return Color.black; } }

    protected override Color guideTextColor { get { return Color.red; } }

    public override bool canHaveChildren { get { return false; } }

    public override bool canGetNextparagraph { get => CanReceiveNextparagraph; }
    public override KeyCode inputMovenext { get => KeyCode.DownArrow;  }
    public override KeyCode inputMoveprev { get => KeyCode.UpArrow; }

    public override InputButtonFlags Inputbuttonflags { get => InputButtonFlags.Left | InputButtonFlags.Right; }

    //public override Text Text => throw new System.NotImplementedException();






    // Start is called before the first frame update


    // Update is called once per frame
    void Update()
    {
        
    }
}
