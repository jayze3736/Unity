using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// UIHelper�� UI�� ����Ű���ϰ� ����� �Է¿� �߻��� UI �׼��� �����ϱ����� �߻� Ŭ����
/// </summary>
public abstract class HelperPointable : MonoBehaviour , IHelperPointable
{
    private IHelperPointable parent;

    public abstract bool canHaveChildren { get; }
    public abstract bool canGetNextparagraph { get; }
    public abstract KeyCode inputMovenext { get; }
    public abstract KeyCode inputMoveprev { get; }
    public IHelperPointable Parent { get { return parent; } set { parent = value; } }

    public virtual List<IHelperPointable> GetChildren()
    {
        if (!this.canHaveChildren) return null;

        if (canGetNextparagraph)
        {
            List<IHelperPointable> children = new List<IHelperPointable>();
            for(int i = 0; i < (this.transform.childCount - 1); i++)
            {
                IHelperPointable child = transform.GetChild(i).GetComponent<IHelperPointable>();
                if (child != null)
                {
                    children.Add(child);
                }
                
            }

            return children;
        }
        return null;
    }

    public HelperPointable GetHelperPointable()
    {
        return this;
    }

    public Transform GetTransform()
    {
        return this.transform;
    }

    


    public void OnEnable()
    {
        parent = GetComponentInParent<IHelperPointable>();

    }

    public abstract void OnCloseParagraph();
    public abstract void OnOpenParagraph();
    public abstract void RaiseEvent();
    public abstract void SetDefaultState();
    public abstract void SetGuideState();

    public bool IsActive()
    {
        return gameObject.activeSelf;
    }
}
