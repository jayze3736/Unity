using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class SaveFile : MonoBehaviour
{
    //Button savefile;
    //SaveManager sm;
    //public SaveInfo saveinfo;

    //public string index;

    //private void Awake()
    //{
       
    //    savefile = GetComponent<Button>();
    //    saveinfo = new SaveInfo(transform);
    //    if (savefile == null) Debug.LogError("savefile has no button component");
        
    //}
    
    

    //private void Start()
    //{
    //    sm = SaveManager.manager;     
    //    savefile.onClick.AddListener(showpopup);

        
    //    index = transform.GetSiblingIndex().ToString();
    //    string savename = index.ToString();
    //    SaveData data = SerializationManager.Load(savename);
        
    //    saveinfo.SetSaveInfo(index.ToString());
    //     if(data != null)
    //    {
    //        // save info�� �����Ͽ� ���̺� ������ Text�� ���̺� ���� ���λ����� ǥ����
    //        //saveinfo.Copyfield(data.prevSavedfileinfo);
    //    }
        
        
    //    //�ʱ⿡ saveinfo���� load

    //}

    //void showpopup()    //�ڱ� �ڽ��� Ŭ�������� �߻��ϴ� �̺�Ʈ => Ŭ���� popup�� �����ְ� mode�� ���� showpop�� ����
    //{

    //    //string savename = index.ToString();

    //    //SaveLoadPopup slpopup = Instantiate(SaveManager.savemanager.popup).GetComponentInChildren<SaveLoadPopup>();
    //    //slpopup.Setfilecursor(this);    //�ڽ��� �������� ���� ���� Ŀ���� ���� ������ ����Ŵ�� �˸�
        


    //    //Transform popup = Instantiate(SaveManager.savemanager.popup);
    //    //SetPopupSettings(popup);    //set popup's hierachy value
    //    //QuestionPopup qp = popup.GetComponentInChildren<QuestionPopup>();

    //    //if (sm.savemode == true)
    //    //{
           
            
    //    //    qp.questionText_upper.text = "Are you sure to save";
    //    //    qp.questionText_below.text = index + "th file"; // 1st, 2nd, 3rd, 4th

    //    //    qp.yesbutton.onClick.AddListener(delegate {

    //    //        SaveData.savedata.lastSavedfileinfo = saveinfo; //���� ���� ��Ȳ�� savefile�� �����ϱ� ���� set
    //    //        saveinfo.SetSaveInfo(
    //    //            savename,
    //    //            "test1",
    //    //            "CurrentScene",
    //    //            Player.player.playerstats.lives.ToString(),
    //    //            System.DateTime.Now.ToString());  //Update savefile's information 

    //    //        SerializationManager.Save(savename, SaveData.savedata);
    //    //        Destroy(popup.gameObject);
    //    //    }); //(function f - save(i, Savedata.savedata), setactive(false))
    //    //    qp.nobutton.onClick.AddListener(delegate { Destroy(popup.gameObject); });

    //    //    sm.savemode = false; sm.loadmode = false;
    //    //}
    //    //else if (sm.loadmode == true)
    //    //{
            

    //    //    qp.questionText_upper.text = "Are you sure to load";
    //    //    qp.questionText_below.text = index + "th file"; // 1st, 2nd, 3rd, 4th

    //    //    qp.yesbutton.onClick.AddListener(delegate {
                
    //    //        //TODO: load scene and reset all data
    //    //        SaveData data = SerializationManager.Load(savename);
    //    //        if(data != null)
    //    //        {
    //    //            SceneManagerScript.LoadScene(data.lastSavedfileinfo.stagename); //load scene named stagename
    //    //            // scene load -> find spawnpoint and update -> spawn player -> set data
    //    //            SceneManager.sceneLoaded += delegate {
    //    //                SceneManagerScript.scenemanager.UpdateSpawnPoint();
    //    //                GameMaster.gm.SpawnPlayer(SceneManagerScript.scenemanager.curScenespawnpoint);
    //    //                Player.player.playerstats.setfield(data.Pstats);
    //    //            };
    //    //        }
               


    //    //        Destroy(popup.gameObject);
    //    //    }); //(function f - save(i, Savedata.savedata), setactive(false))
    //    //    qp.nobutton.onClick.AddListener(delegate { Destroy(popup.gameObject); });


    //    //    sm.savemode = false; sm.loadmode = false;
    //    //    //question popup class qpc = Instantiate(...).GetComponent<...>
    //    //    //qpc.yesbutton(function f - load(i), setactive(false))
    //    //    //qpc.nobutton(function t - setactive(false))

    //    //}



    //}


    //void SetPopupSettings(Transform _popup)
    //{
       
    //    _popup.SetParent(sm.transform);
    //    _popup.localPosition = Vector2.zero;
    //    RectTransform canvas = _popup.GetComponentInChildren<Canvas>().transform.GetComponent<RectTransform>();
    //    canvas.anchoredPosition = Vector2.zero;
    //    canvas.anchorMax = new Vector2(0.5f, 0.5f);
    //    canvas.anchorMin = new Vector2(0.5f, 0.5f);
    //}


    

    ///// <summary>
    ///// ���̺� ���Ͽ� ��ϵ� ���� ��Ȳ�� UI�� ǥ���ϱ� ���� Ŭ����
    ///// </summary>
    //[System.Serializable]
    //public class SaveInfo
    //{
    //    public SaveInfo()
    //    {
    //        _this = null;
            
    //    }

    //    public SaveInfo(Transform t)
    //    {
    //        _this = t;
    //        //SetRefAll();
    //    }

    //    [System.NonSerialized]
    //    Transform _this;

    //    //public TextMeshProUGUI savename;    //���� string���� �ٲٱ�
    //    //public TextMeshProUGUI levelname;
    //    //public TextMeshProUGUI stagename;
    //    //public TextMeshProUGUI livesname;
    //    //public TextMeshProUGUI savedate;

    //    private string _savename;
    //    private string _levelname;
    //    private string _stagename;
    //    private string _livesname;
    //    private string _savedate;
    //    public string savename 
    //    {
    //        set { _this.Find("Saveinfo_" + "savename").GetComponent<TextMeshProUGUI>().text = "Savefile " + value; _savename = value;}
    //        get { return _savename; }
    //    } 
    //    public string levelname //set player info
    //    {
    //       set { _this.Find("Saveinfo_" + "levelname").GetComponent<TextMeshProUGUI>().text = "LV: " + value; _levelname = value; }
    //        get { return _levelname; }
    //    }
    //    public string stagename //find by scene name
    //    {
    //        set { _this.Find("Saveinfo_" + "stagename").GetComponent<TextMeshProUGUI>().text = "stage: " + value; _stagename = value; }
    //        get { return _stagename; }
    //    }
    //    public string livesname //set player info
    //    {
    //        set { _this.Find("Saveinfo_" + "livesname").GetComponent<TextMeshProUGUI>().text = "lives: " + value; _livesname = value; }
    //        get { return _livesname; }
    //    }
    //    public string savedate
    //    {
    //        set { _this.Find("Saveinfo_" + "savedate").GetComponent<TextMeshProUGUI>().text = "Date: " + value; _savedate = value; }
    //        get { return _savedate; }
    //    }

        

    //    public void Copyfield(SaveInfo savedata)
    //    {
    //        savename = savedata.savename;
    //        levelname =  savedata.levelname;
    //        stagename =  savedata.stagename;
    //        livesname = savedata.livesname;
    //        savedate = savedata.savedate;
                
    //    }

    //    public void SetSaveInfo(
    //    string nthfile = " ", string lv = " ", string stage = " ", string lives = " ", string date = " ")
    //    {
    //        //saveinfo.SetText(ref _saveinfo.savename, "Savefile " + nthfile);
    //        //saveinfo.SetText(ref  _saveinfo.levelname, "LV: " + lv);
    //        //saveinfo.SetText(ref  _saveinfo.stagename, "stage: " + stage);
    //        //saveinfo.SetText(ref  _saveinfo.livesname, "lives: " + lives);
    //        //saveinfo.SetText(ref  _saveinfo.savedate, "Date: " + date);

    //        savename = nthfile;
    //        levelname = lv;
    //        stagename = stage;
    //        livesname = lives;
    //        savedate = date;
    //    }

        
    //}





}
