using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;

public class GPD_StageNameText : GameProgressObject
{


    public override void Display()
    {
        StringBuilder sb = new StringBuilder("Stage: ");
        sb.Append(container.GetStageName());
        Text.text = sb.ToString();
    }
}
