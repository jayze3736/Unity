using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;

public class GPD_SaveNameText : GameProgressObject
{
    public override void Display()
    {
        StringBuilder sb = new StringBuilder("���̺� ���� ");
        sb.Append(container.GetSaveName());
        Text.text = sb.ToString();
    }



    
}
