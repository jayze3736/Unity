using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
public class GPD_SaveDateText : GameProgressObject
{


    public override void Display()
    {
        StringBuilder sb = new StringBuilder("Date: ");
        sb.Append(container.GetSaveDate());
        Text.text = sb.ToString();
    }
}
