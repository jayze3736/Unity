using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
public class GPD_LevelText : GameProgressObject
{
    public override void Display()
    {
        StringBuilder sb = new StringBuilder("LV: ");
        sb.Append(container.GetStageLevel());
        Text.text = sb.ToString();
    }
}
