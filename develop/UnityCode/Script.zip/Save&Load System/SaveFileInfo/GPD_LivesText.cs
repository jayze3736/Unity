using System.Collections;
using System.Text;
using System.Collections.Generic;
using UnityEngine;

public class GPD_LivesText : GameProgressObject
{
    public override void Display()
    {
        StringBuilder sb = new StringBuilder("LIves: ");
        sb.Append(container.GetPlayerLives());
        Text.text = sb.ToString();
    }


}
