using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Script for popup that has Save and Load button
/// </summary>
public class SaveLoadPopup : MonoBehaviour
{

    //public delegate void FileLoadEvent(SaveData data);
    //public static event FileLoadEvent onGameStart;
    
    //public Button savebutton;
    //public Button loadbutton;
    //public Text questionText_upper;
    //public Text questionText_below;

    //private SaveFile cursavefile; //���� �����ϰ��ִ� ���̺������� �ǹ�

    ////show message for complete save
    //[SerializeField]
    //Transform taskcompleteMessage;

    //// Start is called before the first frame update
    //void Awake()
    //{
        
    //     savebutton = transform.Find("Save").GetComponent<Button>();
    //     savebutton.onClick.AddListener(Save);
        
        
    //    loadbutton = transform.Find("Load").GetComponent<Button>();
    //    loadbutton.onClick.AddListener(Load);

    //    questionText_upper = transform.Find("Text_question").GetComponent<Text>();
    //    questionText_below = transform.Find("Text_below").GetComponent<Text>();

        


    //}

    //private void Start()
    //{
    //    SetPopupSettings(this.transform);

    //}

    //// Update is called once per frame
    //void Update()
    //{
    //    if (Input.GetKeyDown(KeyCode.Escape))
    //    {
    //        Destroy(this.gameObject);
    //    }
    //}

    //private void Save()
    //{

    //    SaveFile savefile = cursavefile;
    //    SaveFile.SaveInfo saveinfo = savefile.saveinfo;
    //   // SaveData.savedata.prevSavedfileinfo = saveinfo; //���� ���� ��Ȳ�� savefile�� �����ϱ� ���� set
    //    string savename = savefile.index;

    //    //saveinfo.SetSaveInfo(
    //    //    savename,
    //    //    "test1",
    //    //    "CurrentScene",
    //    //    Player.player.playerstats.lives.ToString(),
    //    //    System.DateTime.Now.ToString());  //Update savefile's information 

    //    SerializationManager.Save(savename, SaveData.savedata);
    //    Destroy(this.gameObject);
    //}

    ///// <summary>
    ///// ������ ã�� �ش� ���Ͽ� ����� ������ �ʱ�ȭ �۾�
    ///// </summary>
    //public void Load()
    //{
    //    SaveFile savefile = cursavefile;
    //    string savename = savefile.index;
    //    SaveData data = SerializationManager.Load(savename);    // ����ȭ �� ���� �ε� TODO: SaveLoadPopUpŬ������ Load�Լ�


    //    if (data != null)
    //    {
    //        //SceneManagerScript.LoadScene(data.lastSavedfileinfo.stagename); //���Ͽ� ����� �������� ������ Scene�� �ε�
    //        // scene load -> find spawnpoint and update -> spawn player -> set data
    //        //OnGameStart(data);   //����!: ���� �ε�ǰ� ����Ǿ����ٵ�?

            

    //        //SceneManager.sceneLoaded += delegate {
    //            // SceneManagerScript.UpdateSpawnPoint(); CHANGED
    //            // GameMaster.gm.SpawnPlayer(SceneManagerScript.curScenespawnpoint); CHANGED
    //            //Player.player.playerstats.setfield(data.Pstats);
    //        //};
    //    }
    //    Destroy(this.gameObject);
    //}

    //public void Setfilecursor(SaveFile savefile)
    //{
    //    cursavefile = savefile;
    //}

    //void SetPopupSettings(Transform _popup)
    //{
    //    SaveFile savefile = cursavefile;
        
    //    questionText_upper.text = "save or load";
    //    questionText_below.text = "File num: " + savefile.saveinfo.savename + '\n'
    //            + "stage: " + savefile.saveinfo.stagename + '\n'
    //            + "save date: " + savefile.saveinfo.savedate;

    //    _popup.SetParent(SaveManager.manager.transform);
    //    _popup.localPosition = Vector2.zero;
    //    RectTransform canvas = _popup.GetComponentInChildren<Canvas>().transform.GetComponent<RectTransform>();
    //    canvas.anchoredPosition = Vector2.zero;
    //    canvas.anchorMax = new Vector2(0.5f, 0.5f);
    //    canvas.anchorMin = new Vector2(0.5f, 0.5f);
    //}

    //void OnGameStart(SaveData data)
    //{
    //    if(onGameStart != null)
    //    {
    //        var handler = onGameStart;
    //        handler(data);
    //    }
    //}

   
}
