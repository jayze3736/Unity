using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class SaveFileGameObject : MonoBehaviour
{
    //Button savefile;
    //SaveManager sm;
    //public SaveInfo saveinfo;

    

    //private void Awake()
    //{

    //    Init();

    //}



    //private void Start()
    //{
    //    sm = SaveManager.manager;
    //    savefile.onClick.AddListener(showpopup);


    //    //string fileIndex = transform.GetSiblingIndex().ToString();
    //    //string savename = fileIndex.ToString();
    //    //SaveData data = SerializationManager.Load(savename);

    //    //saveinfo.SetSaveInfo(fileIndex.ToString());
    //    //if (data != null)
    //    //{
    //    //    // save info�� �����Ͽ� ���̺� ������ Text�� ���̺� ���� ���λ����� ǥ����
    //    //    //saveinfo.Copyfield(data.lastSavedfileinfo);
    //    //}


    //    //�ʱ⿡ saveinfo���� load

    //}

    ///// <summary>
    ///// SaveFileObject Initiate
    ///// </summary>
    //void Init()
    //{
    //    // Saveinfo init
    //    savefile = GetComponent<Button>();
    //    if (savefile == null) Debug.LogError("savefile has no button component");

    //    string fileIndex = transform.GetSiblingIndex().ToString(); //get index from list of children
    //    string savename = fileIndex;
    //    SaveData data = SerializationManager.Load(savename);
    //    if(data != null)
    //    {
    //        //saveinfo = new SaveInfo(transform, data.prevSavedfileinfo);
    //    }
    //    else
    //    {
    //        //saveinfo = new SaveInfo(transform, fileIndex);
    //    }
        

    //}



    //void showpopup()    //�ڱ� �ڽ��� Ŭ�������� �߻��ϴ� �̺�Ʈ => Ŭ���� popup�� �����ְ� mode�� ���� showpop�� ����
    //{

    //    //string savename = index.ToString();

    //    //SaveLoadPopup slpopup = Instantiate(SaveManager.savemanager.popup).GetComponentInChildren<SaveLoadPopup>();
    //    //slpopup.Setfilecursor(this);    //�ڽ��� �������� ���� ���� Ŀ���� ���� ������ ����Ŵ�� �˸�



    //    //Transform popup = Instantiate(SaveManager.savemanager.popup);
    //    //SetPopupSettings(popup);    //set popup's hierachy value
    //    //QuestionPopup qp = popup.GetComponentInChildren<QuestionPopup>();

    //    //if (sm.savemode == true)
    //    //{


    //    //    qp.questionText_upper.text = "Are you sure to save";
    //    //    qp.questionText_below.text = index + "th file"; // 1st, 2nd, 3rd, 4th

    //    //    qp.yesbutton.onClick.AddListener(delegate {

    //    //        SaveData.savedata.lastSavedfileinfo = saveinfo; //���� ���� ��Ȳ�� savefile�� �����ϱ� ���� set
    //    //        saveinfo.SetSaveInfo(
    //    //            savename,
    //    //            "test1",
    //    //            "CurrentScene",
    //    //            Player.player.playerstats.lives.ToString(),
    //    //            System.DateTime.Now.ToString());  //Update savefile's information 

    //    //        SerializationManager.Save(savename, SaveData.savedata);
    //    //        Destroy(popup.gameObject);
    //    //    }); //(function f - save(i, Savedata.savedata), setactive(false))
    //    //    qp.nobutton.onClick.AddListener(delegate { Destroy(popup.gameObject); });

    //    //    sm.savemode = false; sm.loadmode = false;
    //    //}
    //    //else if (sm.loadmode == true)
    //    //{


    //    //    qp.questionText_upper.text = "Are you sure to load";
    //    //    qp.questionText_below.text = index + "th file"; // 1st, 2nd, 3rd, 4th

    //    //    qp.yesbutton.onClick.AddListener(delegate {

    //    //        //TODO: load scene and reset all data
    //    //        SaveData data = SerializationManager.Load(savename);
    //    //        if(data != null)
    //    //        {
    //    //            SceneManagerScript.LoadScene(data.lastSavedfileinfo.stagename); //load scene named stagename
    //    //            // scene load -> find spawnpoint and update -> spawn player -> set data
    //    //            SceneManager.sceneLoaded += delegate {
    //    //                SceneManagerScript.scenemanager.UpdateSpawnPoint();
    //    //                GameMaster.gm.SpawnPlayer(SceneManagerScript.scenemanager.curScenespawnpoint);
    //    //                Player.player.playerstats.setfield(data.Pstats);
    //    //            };
    //    //        }



    //    //        Destroy(popup.gameObject);
    //    //    }); //(function f - save(i, Savedata.savedata), setactive(false))
    //    //    qp.nobutton.onClick.AddListener(delegate { Destroy(popup.gameObject); });


    //    //    sm.savemode = false; sm.loadmode = false;
    //    //    //question popup class qpc = Instantiate(...).GetComponent<...>
    //    //    //qpc.yesbutton(function f - load(i), setactive(false))
    //    //    //qpc.nobutton(function t - setactive(false))

    //    //}



    //}


    //void SetPopupSettings(Transform _popup)
    //{

    //    _popup.SetParent(sm.transform);
    //    _popup.localPosition = Vector2.zero;
    //    RectTransform canvas = _popup.GetComponentInChildren<Canvas>().transform.GetComponent<RectTransform>();
    //    canvas.anchoredPosition = Vector2.zero;
    //    canvas.anchorMax = new Vector2(0.5f, 0.5f);
    //    canvas.anchorMin = new Vector2(0.5f, 0.5f);
    //}



    //#region SaveInfo
    ///// <summary>
    ///// ���̺� ���Ͽ� ��ϵ� ���� ��Ȳ�� UI�� ǥ���ϱ� ���� Ŭ����
    ///// Note: SaveFile ������Ʈ�� saveInfo �ؽ�Ʈ���� �̸��� �ٲ�� ������ �߻���
    ///// </summary>
    //[System.Serializable]
    //public class SaveInfo
    //{
    //    public SaveInfo()
    //    {
    //        savefile = null;

    //    }

    //    public SaveInfo(Transform t, string nthfile = " ", string lv = " ", string stage = " ", string lives = " ", string date = " ")
    //    {
    //        savefile = t;

    //        Savename = nthfile;
    //        Levelname = lv;
    //        Stagename = stage;
    //        Livesname = lives;
    //        Savedate = date;
    //        //SetRefAll();
    //    }

    //    public SaveInfo(Transform t, SaveInfo prevSavedInfo)
    //    {
    //        savefile = t;

    //        Savename = prevSavedInfo.Savename;
    //        Levelname = prevSavedInfo.Levelname;
    //        Stagename = prevSavedInfo.Stagename;
    //        Livesname = prevSavedInfo.Livesname;
    //        Savedate = prevSavedInfo.Savedate;
    //        //SetRefAll();
    //    }





    //    [System.NonSerialized]
    //    Transform savefile;

    //    //public TextMeshProUGUI savename;    //���� string���� �ٲٱ�
    //    //public TextMeshProUGUI levelname;
    //    //public TextMeshProUGUI stagename;
    //    //public TextMeshProUGUI livesname;
    //    //public TextMeshProUGUI savedate;

    //    private string savename;
    //    private string levelname;
    //    private string stagename;
    //    private string livesname;
    //    private string savedate;
    //    public string Savename
    //    {
    //        set { savefile.Find("Saveinfo_" + "savename").GetComponent<TextMeshProUGUI>().text = "Savefile " + value; savename = value; }
    //        get { return savename; }
    //    }
    //    public string Levelname //set player info
    //    {
    //        set { savefile.Find("Saveinfo_" + "levelname").GetComponent<TextMeshProUGUI>().text = "LV: " + value; levelname = value; }
    //        get { return levelname; }
    //    }
    //    public string Stagename //find by scene name
    //    {
    //        set { savefile.Find("Saveinfo_" + "stagename").GetComponent<TextMeshProUGUI>().text = "stage: " + value; stagename = value; }
    //        get { return stagename; }
    //    }
    //    public string Livesname //set player info
    //    {
    //        set { savefile.Find("Saveinfo_" + "livesname").GetComponent<TextMeshProUGUI>().text = "lives: " + value; livesname = value; }
    //        get { return livesname; }
    //    }
    //    public string Savedate
    //    {
    //        set { savefile.Find("Saveinfo_" + "savedate").GetComponent<TextMeshProUGUI>().text = "Date: " + value; savedate = value; }
    //        get { return savedate; }
    //    }

    //    //public static bool operator ==(SaveInfo A, SaveInfo B)
    //    //{
    //    //    if(A.savename != B.savename)
    //    //    {
    //    //        return false;
    //    //    }
    //    //    else if(A.levelname != B.levelname)
    //    //    {
    //    //        return false;
    //    //    }
    //    //    else if (A.stagename != B.stagename)
    //    //    {
    //    //        return false;
    //    //    }
    //    //    else if (A.livesname != B.livesname)
    //    //    {
    //    //        return false;
    //    //    }
    //    //    else if(A.savedate != B.savedate)
    //    //    {
    //    //        return false; 
    //    //    }
    //    //    else
    //    //    {
    //    //        return true;
    //    //    }
            

            
    //    //}
    //    //public static bool operator !=(SaveInfo A, SaveInfo B)
    //    //{



    //    //    return (A == B) ? true : false;
    //    //}



    //    public void Copyfield(SaveInfo savedata)
    //    {
    //        Savename = savedata.Savename;
    //        Levelname = savedata.Levelname;
    //        Stagename = savedata.Stagename;
    //        Livesname = savedata.Livesname;
    //        Savedate = savedata.Savedate;

    //    }

    //    public void SetSaveInfo(string nthfile = " ", string lv = " ", string stage = " ", string lives = " ", string date = " ")
    //    {
            
    //        Savename = nthfile;
    //        Levelname = lv;
    //        Stagename = stage;
    //        Livesname = lives;
    //        Savedate = date;
    //    }


    //}
    //#endregion





}
