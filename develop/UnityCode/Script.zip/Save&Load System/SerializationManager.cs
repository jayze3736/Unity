using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Binary �Ǵ� Json �������� �����͸� ����ȭ, ������ȭ �ϴ� ����� �����Ѵ�.
/// </summary>
public sealed class SerializationManager 
{
    /* Save, Load �Լ���
     * 1. Save ������ ������ ���丮�� ����� ���� ��Ʈ������ �ش� ���丮�� data ���� ����
     * 2. ������ ������ binaryformatter�� binary ���Ϸ� ��ȯ�Ѵ�.(Serialze)
     * 3. Load�Ҷ��� Deserialize�� file�� �� ���·� ����
     * 
     * 
     */

    public bool SaveJson(string filename, object serializedData, string foldername)
    {
        
        try
        {
            StringBuilder root = new StringBuilder(Application.persistentDataPath);
            
            if (!Directory.Exists(root.Append("/").Append(foldername).ToString()))
            {
                Directory.CreateDirectory(root.Append("/").Append(foldername).ToString());   //make directory
            }
            string path = root.Append("/").Append(foldername).Append("/").Append(filename).Append(".json").ToString();
            string json = JsonUtility.ToJson(serializedData, true);

            using (FileStream stream = new FileStream(path, FileMode.Create))
            {
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.Write(json);
                }
            }


            return true;

        }
        catch
        {
            Debug.LogError("Serialization To Json Failed, Are you checked your json format?");
            return false;
        }

    }


    public T LoadJson<T>(string filename, string foldername) where T : class
    {
        StringBuilder root = new StringBuilder(Application.persistentDataPath);
        string path = root.Append("/").Append(foldername).Append("/").Append(filename).Append(".json").ToString();
        T data;

        if (!File.Exists(path))
        {
            Debug.LogError("File doesn't exist on the path");
            return null;    // file doesn't exist on the path
        }


        using (FileStream stream = new FileStream(path, FileMode.Open))
        {
            using (StreamReader reader = new StreamReader(stream))
            {
                string json = reader.ReadToEnd();
                data = JsonUtility.FromJson<T>(json);
                return data;

            }
        }




    }


    public bool SaveAsJson(string savename, object savedata)
    {
        try
        {
            if (!Directory.Exists(Application.persistentDataPath + "/saves"))
            {
                Directory.CreateDirectory(Application.persistentDataPath + "/saves");   //make directory
            }
            string path = Application.persistentDataPath + "/saves/" + savename + ".saves";
            string json = JsonUtility.ToJson(savedata, true);
            
            using(FileStream stream = new FileStream(path, FileMode.Create))
            {
                using(StreamWriter writer = new StreamWriter(stream))
                {
                    writer.Write(json);
                }
            }

            
            return true;

        }
        catch
        {
            Debug.LogError("Serialization To Json Failed, Are you checked your json format?");
            return false;
        }

    }

    public SaveData LoadAsJson(string savename)
    {
        string path = Application.persistentDataPath + "/saves/" + savename + ".saves";
        SaveData savedata = null;

        if (!File.Exists(path))
        {
            return null;    // file doesn't exist on the path
        }
        
        
        using(FileStream stream = new FileStream(path, FileMode.Open))
        {
            using(StreamReader reader = new StreamReader(stream))
            {
                string loaded_data = reader.ReadToEnd();
                savedata = JsonUtility.FromJson<SaveData>(loaded_data);
                return savedata;


                //SaveData.savedata.Onload();

            }
        }

        


    }



    /// <summary>
    /// savedata�� savename�� �̸����� �����Ѵ�.
    /// </summary>
    /// <param name="savename">���� �̸�</param>
    /// <param name="savedata">���̺� ������</param>
    /// <returns></returns>
    private bool Save(string savename, object savedata)
    {

        BinaryFormatter formatter = GetbinaryFormatter();

        if(!Directory.Exists(Application.persistentDataPath + "/saves"))
        {
            Directory.CreateDirectory(Application.persistentDataPath + "/saves");   //make directory
        }

        string path = Application.persistentDataPath + "/saves/" + savename + ".saves"; //make path of binary file
        FileStream file = File.Create(path);    //filestream supports reading and writing files, and File.Create makes file on path
       
        formatter.Serialize(file, savedata);    // transform data to binary file with file stream
        file.Close();

        return true; //return bool value to know whether process is done successfully

    }

    

    /// <summary>
    /// Application.persistentDataPath/saves/ ����� savename�� �ش��ϴ� ������ �ҷ���
    /// </summary>
    /// <param name="savename"></param>
    /// <returns></returns>
    private SaveData Load(string savename)
    {
        //SerializationManager sManager = new SerializationManager();
        string path = Application.persistentDataPath + "/saves/" + savename + ".saves";
        SaveData savedata;

        if (!File.Exists(path))
        {
            return null;    // file doesn't exist on the path
        }

        BinaryFormatter formatter = GetbinaryFormatter();
        FileStream file = File.Open(path, FileMode.Open);   //File.Open: �ش� path�� ������ �аų� ��, FileMode: �ش� path�� ������ �������������� Ư�� ���� ����

        try
        {
            object savefile = formatter.Deserialize(file);
            file.Close();
            savedata = (SaveData)savefile;

        }
        catch
        {
            Debug.LogErrorFormat("Failed to load file at {0}", path);
            file.Close();
            savedata = null;

        }

        if(savedata != null)
        {
            //ResetGameProgress(savedata);
            return savedata;
        }
        else
        {
            return null;
        }

    }

    private BinaryFormatter GetbinaryFormatter()
    {
        BinaryFormatter formatter = new BinaryFormatter();

        return formatter;
    }

    

   


}
