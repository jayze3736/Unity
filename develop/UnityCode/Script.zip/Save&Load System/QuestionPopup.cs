using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestionPopup : MonoBehaviour
{
    public Button yesbutton;
    public Button nobutton;
    public Text questionText_upper;
    public Text questionText_below;

    //show message for complete save
    [SerializeField]
    Transform taskcompleteMessage;

    // Start is called before the first frame update
    void Awake()
    {
        yesbutton = transform.Find("Yes").GetComponent<Button>();
        nobutton = transform.Find("No").GetComponent<Button>();
        questionText_upper = transform.Find("Text_question").GetComponent<Text>();
        questionText_below = transform.Find("Text_below").GetComponent<Text>();


    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
