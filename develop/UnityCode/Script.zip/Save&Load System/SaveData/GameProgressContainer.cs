using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// GameProgressData�� �����ϴ� Ŭ�����̸�, ���ӳ����� ���̺� �ε� ����� �����ϴ� ������Ʈ
/// </summary>
public class GameProgressContainer : MonoBehaviour
{

    

    /// <summary>
    /// Game Progress Container�� progress �����Ͱ� ����ɰ�� ��Ƽĳ������ �̺�Ʈ ������
    /// </summary>
    public event Action onUpdateProgress;
    public GameProgressData progress;
    private string fileIndex;
   
   


    public void Save()
    {

        string stagelv = "";
        string playerlives = Player.GetPlayerStatus().HP.ToString();
        string savedate = System.DateTime.Now.ToString();
        string savename = fileIndex;
        string stagename = "";





        progress = new GameProgressData(
           stagelv, playerlives, savedate, savename, stagename
           );

        progress.RegisterSaveDataElement();

        if (SaveManager.manager.Save(fileIndex))
            UpdateContainerElement();
        

    }

    public void Save(string stagelv, string playerlives, string savedate, string savename, string stagename)
    {

        progress = new GameProgressData(
           stagelv, playerlives, savedate, savename, stagename
           );

        progress.RegisterSaveDataElement();
        if (SaveManager.manager.Save(fileIndex))
            UpdateContainerElement();


    }

    public void Init()
    {

        
        if(SaveManager.manager.Load(fileIndex, progress.MappingSaveDataElement))
            UpdateContainerElement();
        
    }

    public void Load()
    {


        if (SaveManager.manager.Load(fileIndex)) ;
           
    }

    public void UpdateContainerElement()
    {
        var handler = onUpdateProgress;
        if(handler != null)
        {
            handler();
        }
    }

    private void Awake()
    {
        // �̺�Ʈ ���� ����
        fileIndex = transform.GetSiblingIndex().ToString();

        //progress�� ����� ����ϱ����ؼ��� �����ڷ� ��ü�� �����ؾ���
        progress = new GameProgressData();
    }


    // Start is called before the first frame update
    void Start()
    {
        Init();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public string GetStageLevel()
    {
        return progress.stagelevel;
    }

    public string GetStageName()
    {
        return progress.stagename;
        //return "";
    }
    public string GetPlayerLives()
    {
        return progress.playerlives;
        //return Player.player.Status.lives.ToString();
    }
    public string GetSaveDate()
    {
        return progress.savedate;
        //return System.DateTime.Now.ToString();
    }
    public string GetSaveName()
    {
        return progress.savename;
    }

   




}
