using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;

/// <summary>
/// ������ �����Ȳ�� ��Ÿ���� ���� ������
/// </summary>
[System.Serializable]
public class GameProgressData : SaveDataElement
{
    
    [SerializeField]
    private string m_stagelevel;
    [SerializeField]
    private string m_playerlives;
    [SerializeField]
    private string m_savedate;
    [SerializeField]
    private string m_savename;
    [SerializeField]
    private string m_stagename;


    // ���� �ʵ尪�� �����ϱ⺸�� getter, setter�� �������.
    public string stagelevel { get { return m_stagelevel; } set { m_stagelevel = value; } }
    public string playerlives { get { return m_playerlives; } set { m_playerlives = value; } }
    public string savedate { get { return m_savedate; } set { m_savedate = value; } }
    public string savename { get { return m_savename; } set { m_savename = value; } }
    public string stagename { get { return m_stagename; } set { m_stagename = value; } }

    public GameProgressData()
    {
        
    }

    public GameProgressData(string stagelevel, string playerlives, string savedate, string savename, string stagename)
    {
        this.stagelevel = stagelevel;
        this.playerlives = playerlives;
        this.savedate = savedate;
        this.savename = savename;
        this.stagename = stagename;
        

    }

   

    

    public override void MappingSaveDataElement()
    {
        GameProgressData progress = SaveManager.GetSaveData().progress;
        this.stagelevel = progress.stagelevel;
        this.playerlives = progress.playerlives;
        this.savedate = progress.savedate;
        this.savename = progress.savename;
        this.stagename = stagename;
    }

    public override void RegisterSaveDataElement()
    {
        SaveManager.GetSaveData().progress = this;
    }






}
