using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface INonConsumableItem : ItemMeta
{


    void Equip();



}
