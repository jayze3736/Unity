using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;



public interface IConsumableItem<T> : ItemMeta
{
    public UnityEvent<T> EffectListener { get; }


}
