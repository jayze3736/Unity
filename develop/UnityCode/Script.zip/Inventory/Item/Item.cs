using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public interface ItemMeta 
{
   public int Id { get; }
   public string Name { get; }
   public string Description { get;}
   public Sprite Src { get; }

   public Animator Animator { get;}

   public ItemType Type { get;}


    //public void UseItem();


   





}
