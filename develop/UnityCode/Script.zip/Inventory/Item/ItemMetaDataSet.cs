using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "ItemMetaDataSet", menuName = "ScriptableObjects/Create Item Data Set")]
public class ItemMetaDataSet : ScriptableObject
{
    [SerializeField]
    List<ItemMetaData> dataSet;

    public List<ItemMetaData> Set
    {
        get { return dataSet; }
    }
    

}
