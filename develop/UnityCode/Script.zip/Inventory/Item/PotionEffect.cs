using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PotionEffect : MonoBehaviour
{
    public void S_HPPotionEffect(PlayerStatus status)
    {
        Debug.Log("HP recovered");
        status.HealHP();
    }

    public  void S_MPPotionEffect(PlayerStatus status)
    {
        Debug.Log("MP recovered");
        //status.();
    }

    public  void S_STMPotionEffect(PlayerStatus status)
    {
        Debug.Log("STM recovered");
        //status.RecoverStamina();
    }

    


}
