using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewItemMetaDataSet", menuName = "ScriptableObjects/Create New Item Data Set")]
public class CustomItemMetaDataSet : ScriptableObject
{
    [SerializeField]
    List<ItemMetaData> dataSet;

    public List<ItemMetaData> DataSet
    {
        get { return dataSet; }
    }
}
