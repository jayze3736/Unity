using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    public string bindingPath;

    // Start is called before the first frame update
    void Start()
    {
        //Initiate Inventory Logic
        Init();




    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Init()
    {
        //var result = GameLogicTree.tree.GetContextFromView<Inventory>(bindingPath, string.Empty);
        var result = GameLogicTree.tree.AddNewContext<Inventory>(bindingPath, new Inventory(), false);
        switch (result.State)
        {
            case ContextState.CanUse:
                Debug.Log("Successfully Added Context");
                break;

            default:
                Debug.Log("Adding Context Failed");
                break;

        }
        

    }
}
